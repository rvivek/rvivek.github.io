FractalDemo written by Slava Akhmechet (coffeemug@gmail.com)

SUMMARY:
	The demo is not interactive, so sit back, relax and enjoy.

MINIMUM REQUIREMENTS:
	- The demo was tested on numerous systems with GeForce2 MX. It should run on any card that supports 2 texture units and has 16 MB onboard memory (although it was only tested on boards with 32 MB).
	- DirectX 8.1
	- 128 MB of RAM.
	- 750 Mhz processor. The demo was tested on AMD 750Mhz and was quiet slow (about 30 FPS). It's pretty processor intensive so the faster the processor, the better.

CREDITS:
There are quiet a bit of libraries and resources used in the demo. The list below is complete as far as I know, but if I am using someone's work and it's not listed in the credits I apologize in advance. Please send me an e-mail and I will correct the problem immediatly.
	- NVidia Texture Pack
	- Golgotha textures and sounds (crack.com)
	- Water cubemap and heightmap from GLVelocity terrain demo
	- Hermes format conversion library
	- Bass sound library
	- Thanks to NeHE tutorials for getting me started with 3D
	- Thanks to everyone on GameDev boards for helping me out with problems.
	- Special thanks to Yann L for his explanations in the Advanced Sky Rendering Techniques thread.
