
#ifndef _PROGRESSBAR_IMPL_H_
#define _PROGRESSBAR_IMPL_H_

#include "progressbar.h"

class CProgressBar : public IProgressBar
{
public:
	CProgressBar();
	virtual ~CProgressBar();

	// Initialization / destruction
	virtual BOOL			Create(const VIDEODEVICE &Device, IAttributeStack *Stack);
	virtual BOOL			Destroy();

	// These functions can only be called before initialization
	virtual BOOL			SetSize(FLOAT Width, FLOAT Height);
	virtual BOOL			SetPosition(FLOAT X, FLOAT Y);
	virtual BOOL			SetColor(DWORD Color);

	// These functions can be called at any time
	virtual BOOL			SetMinMax(FLOAT Min, FLOAT Max);
	virtual BOOL			SetValue(FLOAT Value);

	// Action functions
	virtual BOOL			Render();

private:
	VIDEODEVICE				m_Device;
	IAttributeStack			*m_pStack;

	FLOAT					m_Width, m_Height;
	FLOAT					m_x, m_y;
	FLOAT					m_Min, m_Max;
	FLOAT					m_Value;
	DWORD					m_Color;
};

#endif // _PROGRESSBAR_IMPL_H_
