
#include "fractal_errors.h"
#include "skydome_impl.h"
#include "noise.h"
#include "scom.h"

struct SKYDOMEVERTEX
{
    D3DXVECTOR3 pos;	// The position for the vertex.
    DWORD color;        // The vertex color.
	FLOAT tu, tv;		// Texture map
	FLOAT tu1, tv1;		// Second texture
};
#define FVF_SKYDOME (D3DFVF_XYZ | D3DFVF_DIFFUSE | D3DFVF_TEX2)

#define SQR(x)		x * x

CSkydome::CSkydome()
{
	m_Device.API = NULL;
	m_Device.Device = NULL;

	m_pIB = NULL;
	m_pVB = NULL;
	m_pCloudsTex = NULL;
	m_Gradient = NULL;
	m_pSun = NULL;
	m_GradientName = NULL;
	m_SunName = NULL;
	
	m_NumVertices = 0;
	m_NumIndices = 0;
	m_SkyCounter = 0;
	
	m_ARadius = SKYDOME_DEFAULT_ARADIUS;
	m_HRadius = SKYDOME_DEFAULT_HRADIUS;

	m_Height = SKYDOME_DEFAULT_HEIGHT;
	m_TextureSize = SKYDOME_DEFAULT_TEXTURE_SIZE;
	m_SkydomeTesselation = SKYDOME_DEFAULT_DIVISIONS;
	m_Wind.x = 0;
	m_Wind.y = 0;
	m_CloudColor1 = D3DXCOLOR(1, 1, 1, 1);
	m_CloudColor2 = D3DXCOLOR(1, 1, 1, 1);
	m_Density = SKYDOME_DEFAULT_DENSITY;
	m_Fluffiness = SKYDOME_DEFAULT_FLUFFINESS;

	m_utran = m_vtran = 0;
	
	m_CloudFreq = 14;
	m_CloudOctaves = 4;
	m_ShadingFreq = 18;
	m_ShadingOctaves = 1;
	m_Modification = 0.005f;

	m_TimeDimension = 0.0f;

	m_pBillboard = NULL;
	m_pStack = NULL;

	m_SunColor = D3DCOLOR_ARGB(255, 255, 255, 255);
	m_SunDiameter = 160;
	m_SunPosition = D3DXVECTOR3(20, 2, 0);
}

CSkydome::~CSkydome()
{
	Destroy();
}

BOOL CSkydome::Create(const VIDEODEVICE &Device, IAttributeStack *Stack)
{
	m_Device = Device;
	m_pStack = Stack;

	// Calculate the number of vertices and indices
	m_NumIndices = (m_SkydomeTesselation * m_SkydomeTesselation) * 2 * 3;
	m_NumVertices = (m_SkydomeTesselation + 1) * (m_SkydomeTesselation + 1);

	// Create the index buffer
	if(FAILED(m_Device.Device -> CreateIndexBuffer(
		m_NumIndices * sizeof(WORD),
		D3DUSAGE_WRITEONLY,
		D3DFMT_INDEX16,
		D3DPOOL_MANAGED,
		&m_pIB
		)))
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not create index buffer.");
		return FALSE;
	}

	// Create the vertex buffer
	if(FAILED(m_Device.Device -> CreateVertexBuffer(
		m_NumVertices * sizeof(SKYDOMEVERTEX),
		0,
		FVF_SKYDOME,
		D3DPOOL_MANAGED,
		&m_pVB
		)))
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not create vertex buffer.");
		return FALSE;
	}

	// Load the billboard class
	m_pBillboard = (IBillboard*)scCreateComponent("Billboard");
	m_pBillboard -> Create(m_Device);

	// Create the texture
	m_pCloudsTex = (ITexture*)scCreateComponent("Texture");
	m_pCloudsTex -> SetSize(m_TextureSize, m_TextureSize);
	m_pCloudsTex -> SetFormat(D3DFMT_A8R8G8B8);
	m_pCloudsTex -> Create(m_Device, m_pStack);

	// Load the gradient texture
	if(m_GradientName != NULL)
	{
		if(FAILED(D3DXCreateTextureFromFile(
			m_Device.Device,
			m_GradientName,
			&m_Gradient
			)))
		{
			FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not load the texture from file.");
			return FALSE;
		}
	}

	if(m_SunName != NULL)
	{
		if(FAILED(D3DXCreateTextureFromFile(
			m_Device.Device,
			m_SunName,
			&m_pSun
			)))
		{
			FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not load the texture from file.");
			return FALSE;
		}
	}

	// Generate the skydome
	if(!GenerateSkydome())
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not generate the skydome.");
		return FALSE;
	}

	UpdateCloudTexture(0);

	return TRUE;
}

BOOL CSkydome::Destroy()
{
	if(m_pIB != NULL)
	{
		m_pIB -> Release();
		m_pIB = NULL;
		m_pVB -> Release();
		m_pVB = NULL;
		m_Device.API = NULL;
		m_Device.Device = NULL;
		if(m_Gradient != NULL)
		{
			m_Gradient -> Release();
			m_Gradient = NULL;
		}
		free((void*)m_SunName);
		m_SunName = NULL;
		free((void*)m_GradientName);
		m_GradientName = NULL;
		if(m_pSun != NULL)
		{
			m_pSun -> Release();
			m_pSun = NULL;
		}
		m_pBillboard -> Destroy();
		scDeleteComponent(m_pBillboard);
		m_pBillboard = NULL;

		scDeleteComponent(m_pCloudsTex);
		m_pCloudsTex = NULL;
	}
	else
	{
		FRACTAL_WARNING(FRACTAL_NOT_INITIALIZED, "FRACTAL_NOT_INITIALIZED");
		return FALSE;
	}

	return TRUE;
}

BOOL CSkydome::SetHeight(FLOAT Height)
{
	m_Height = Height;

	return TRUE;
}

BOOL CSkydome::SetRadius(FLOAT ARadius, FLOAT HRadius)
{
	if(m_pVB != NULL)
	{
		FRACTAL_ERROR(FRACTAL_ALREADY_INITIALIZED, "FRACTAL_ALREADY_INITIALIZED");
		return FALSE;
	}

	m_ARadius = ARadius;
	m_HRadius = HRadius;

	return TRUE;
}

BOOL CSkydome::SetCloudsTextureSize(UINT Size)
{
	m_TextureSize = Size;

	return TRUE;
}

BOOL CSkydome::SetSkydomeTesselation(UINT Tesselation)
{
	m_SkydomeTesselation = Tesselation;

	return TRUE;
}

BOOL CSkydome::SetGradientTexture(LPCSTR Texture)
{
	m_GradientName = (char*)malloc(255);
	strcpy(m_GradientName, Texture);

	return TRUE;
}

BOOL CSkydome::SetSunTexture(LPCSTR Texture)
{
	m_SunName = (char*)malloc(255);
	strcpy(m_SunName, Texture);

	return TRUE;
}

BOOL CSkydome::SetWindVelocity(FLOAT dx, FLOAT dy)
{
	m_Wind.x = dx;
	m_Wind.y = dy;

	return TRUE;
}

BOOL CSkydome::SetCloudColors(DWORD Color1, DWORD Color2)
{
	m_CloudColor1 = D3DXCOLOR(Color1);
	m_CloudColor2 = D3DXCOLOR(Color2);

	return TRUE;
}

BOOL CSkydome::SetCloudDensity(BYTE Density, FLOAT Fluffiness)
{
	m_Density = Density;
	m_Fluffiness = Fluffiness;

	return TRUE;
}

BOOL CSkydome::SetCloudFrequency(FLOAT Freq, UINT Octaves)
{
	m_CloudFreq = Freq;
	m_CloudOctaves = Octaves;

	return TRUE;
}

BOOL CSkydome::SetShadingFrequency(FLOAT Freq, UINT Octaves)
{
	m_ShadingFreq = Freq;
	m_ShadingOctaves = Octaves;

	return TRUE;
}

BOOL CSkydome::SetModificationConstant(FLOAT Modification)
{
	m_Modification = Modification;

	return TRUE;
}

BOOL CSkydome::SetSunColor(DWORD Color)
{
	m_SunColor = Color;

	return TRUE;
}

BOOL CSkydome::SetSunDiameter(FLOAT Diameter)
{
	m_SunDiameter = Diameter;

	return TRUE;
}
BOOL CSkydome::SetSunPosition(FLOAT Position[])
{
	m_SunPosition = D3DXVECTOR3(Position);

	return TRUE;
}

BOOL CSkydome::Tick(FLOAT Timeslice)
{
	// update the time dimension
	m_TimeDimension += m_Modification * Timeslice;

	// update the translation (wind)
	m_utran += m_Wind.x * Timeslice;
	m_vtran += m_Wind.y * Timeslice;

	if(m_SkyCounter >= 0.1f)
	{
		m_SkyCounter = m_SkyCounter - 0.1f;

		if(!UpdateCloudTexture(Timeslice))
		{
			FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not update the cloud texture.");
			return FALSE;
		}
	}
	else
		m_SkyCounter += Timeslice;

	return TRUE;
}

BOOL CSkydome::Render()
{
	if(m_pVB == NULL)
	{
		FRACTAL_ERROR(FRACTAL_NOT_INITIALIZED, "FRACTAL_NOT_INITIALIZED");
		return FALSE;
	}

	// Push the attributes on the stack
	m_pStack -> Push();

	// Set the states
	m_Device.Device -> SetTexture(0, m_Gradient);
	TEXTURE tex;
	m_pCloudsTex -> GetTextureObject(tex);
	m_Device.Device -> SetTexture(1, tex.Texture);
	m_Device.Device -> SetRenderState(D3DRS_CULLMODE, D3DCULL_CW);
	m_Device.Device -> SetRenderState(D3DRS_ZWRITEENABLE, FALSE);

	// Set the texture stages
	m_Device.Device -> SetTextureStageState(0, D3DTSS_MAGFILTER, D3DTEXF_LINEAR);
	m_Device.Device -> SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);	// Select the texture
	m_Device.Device -> SetTextureStageState(1, D3DTSS_MAGFILTER, D3DTEXF_LINEAR);
	m_Device.Device -> SetTextureStageState(1, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_COUNT2);
	m_Device.Device -> SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_BLENDTEXTUREALPHA);
	
	// transform the clouds
	D3DXMATRIX mat;
	D3DXMatrixIdentity(&mat);
	mat._31 = m_utran;
	mat._32 = m_vtran;
	m_Device.Device -> SetTransform(D3DTS_TEXTURE1, &mat);

	// Do the magic!
	m_Device.Device -> SetStreamSource(0, m_pVB, sizeof(SKYDOMEVERTEX));
	m_Device.Device -> SetVertexShader(FVF_SKYDOME);
	m_Device.Device -> SetIndices(m_pIB, 0);
	m_Device.Device -> DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, m_NumVertices, 0, m_NumIndices / 3);

	m_pStack -> Pop();
	m_pStack -> Push();

	// Set the render states for the sun
	if(m_pSun != NULL)
	{
		m_Device.Device -> SetTexture(0, m_pSun);
		m_Device.Device -> SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE);
		m_Device.Device -> SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
		m_Device.Device -> SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
		m_Device.Device -> SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
		m_Device.Device -> SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
		m_Device.Device -> SetRenderState(D3DRS_DESTBLEND, D3DBLEND_ONE);

		// Do the magic!
		m_pBillboard -> Render(
			m_SunPosition,
			m_SunDiameter,
			m_SunColor
			);
	}

	m_pStack -> Pop();

	return TRUE;
}

BOOL CSkydome::GenerateSkydome()
{
	float Scale = (m_ARadius * 2) / m_SkydomeTesselation;
	// Generate vertices
	SKYDOMEVERTEX *pVertices;
	if(FAILED(m_pVB -> Lock(0, 0, (BYTE**)&pVertices, 0)))
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not lock the vertex buffer.");
		return FALSE;
	}

	float PlaneSize = 2.0f * (float)sqrt((SQR(m_ARadius) - SQR((m_HRadius))));
	float PlaneDelta = PlaneSize / (float)m_SkydomeTesselation;
	
	// variables used during the dome's generation
	float x_dist = 0.0f;
	float z_dist = 0.0f;
	float x_height = 0.0f;
	float z_height = 0.0f;
	float height = 0.0f;
	
	SKYDOMEVERTEX temp;
	for(int i = 0; i <= (int)m_SkydomeTesselation; i++)
	{
		for(int j = 0; j <= (int)m_SkydomeTesselation; j++)
		{
			x_dist = (-0.5f * PlaneSize) + ((float)j * PlaneDelta);
			z_dist = (-0.5f * PlaneSize) + ((float)i * PlaneDelta);
			x_height = SQR(x_dist) / m_ARadius;
			z_height = SQR(z_dist) / m_ARadius;
			height = x_height + z_height;

			// set the vertex coordinates
			temp.pos.x = i * Scale - (m_SkydomeTesselation / 2) * Scale;
			temp.pos.z = j * Scale - (m_SkydomeTesselation / 2) * Scale;
			temp.pos.y = m_Height - height;

			float xd = m_SkydomeTesselation / 2.0f - i;
			float zd = m_SkydomeTesselation / 2.0f - j;
			float dist = sqrtf((SQR(xd) + SQR(zd)));
			
			BYTE r, g, b;
			if(m_Gradient == NULL)
			{
				r = 0;
				g = 0;
				b = 255;
			}
			else
			{
				r = 255;
				g = 255;
				b = 255;
			}

			temp.color = D3DCOLOR_ARGB(255, r, g, b);

			temp.tu = i * (1.0f / m_SkydomeTesselation);
			temp.tv = j * (1.0f / m_SkydomeTesselation);
			temp.tu1 = temp.tu;
			temp.tv1 = temp.tv;

			pVertices[i * (m_SkydomeTesselation + 1) + j] = temp;
		}
	}
	
	m_pVB -> Unlock();

	// Generate indices
	WORD *pIndices;
	if(FAILED(m_pIB -> Lock(0, 0, (BYTE**)&pIndices, 0)))
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not lock the index buffer.");
		return FALSE;
	}

	int index = 0;
	for(i = 0; i < (int)m_SkydomeTesselation; i++)
	{
		for(int j = 0; j < (int)m_SkydomeTesselation; j++)
		{
			int startvert = (i * (m_SkydomeTesselation + 1) + j);
			// triangle 1
			pIndices[index++] = startvert;
			pIndices[index++] = startvert + 1;
			pIndices[index++] = startvert + m_SkydomeTesselation + 1;
			// triangle 2
			pIndices[index++] = startvert + 1;
			pIndices[index++] = startvert + m_SkydomeTesselation + 2;
			pIndices[index++] = startvert + m_SkydomeTesselation + 1;
		}
	}

	m_pIB -> Unlock();

	return TRUE;
}

BOOL CSkydome::UpdateCloudTexture(float Timeslice)
{
	// Fill the texture with noise
	UINT Pitch;
	BYTE *pData = (BYTE*)m_pCloudsTex -> Lock(Pitch);
	for(UINT y = 0; y < m_TextureSize; y++)
	{
		for(UINT x = 0; x < m_TextureSize; x++)
		{
			//float f[3];
			D3DXVECTOR3 f;
			f.x = (float)x / (m_TextureSize - 1);
			f.y = (float)y / (m_TextureSize - 1);
			f.z = m_TimeDimension;

			float v = 0.0f;
			float t = 1.0f;
			f *= m_CloudFreq;
			for(UINT count = 0; count < m_CloudOctaves; count++)
			{
				v += (noise3(f) + 1.0f) / 2.0f / t;
				f.x *= 2;
				f.y *= 2;

				t *= 2;
			}
			if(v > 1.0f)
				v = 1.0f;

			D3DXVECTOR3 g;
			g.x = (float)x / m_TextureSize;
			g.y = (float)y / m_TextureSize;

			g *= m_ShadingFreq;
			float color = 0;
			t = 1.0f;
			for(count = 0; count < m_ShadingOctaves; count++)
			{
				color += (noise2(g) + 1.0f) / 2.0f / t;
				g.x *= 2;
				g.y *= 2;

				t *= 2;
			}
			if(color > 1.0f)
				color = 1.0f;

			D3DXCOLOR c3;
			D3DXColorLerp(&c3, &m_CloudColor1, &m_CloudColor2, color);

			// v is the cloud density value from the fractal generator (range 0 to 255)
			float a = (v * 255.0f) - m_Density;
			if(a < 0)
				a = 0;

			a = powf(m_Fluffiness, a);
			a = 255.0f - (a * 255.0f); 
			// f now is your cloud opacity cloud_alpha

			pData[x * 4 + 0] = (BYTE)(c3.b * 255.0f);	// blue
			pData[x * 4 + 1] = (BYTE)(c3.g * 255.0f);	// green
			pData[x * 4 + 2] = (BYTE)(c3.r * 255.0f);	// red
			pData[x * 4 + 3] = (BYTE)a;			// alpha
		}
		pData += Pitch;
	}

	m_pCloudsTex -> Unlock();

	return TRUE;
}
