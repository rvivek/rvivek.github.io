
#include <windows.h>
#include <d3d8.h>
#include <d3dx8.h>
#include "billboard_impl.h"
#include "fractal_errors.h"
#include "collision_utils.h"

struct BILLBOARDVERTEX
{
    FLOAT x, y, z, rhw; // The transformed position for the vertex.
    DWORD color;        // The vertex color.
	FLOAT tu, tv;		// Texture map
};

#define FVF_BILLBOARD (D3DFVF_XYZRHW | D3DFVF_DIFFUSE | D3DFVF_TEX1)

CBillboard::CBillboard()
{
}

CBillboard::~CBillboard()
{
	Destroy();
}

BOOL CBillboard::Create(const VIDEODEVICE &Device)
{
	m_Device = Device;

	return TRUE;
}

BOOL CBillboard::Destroy()
{
	m_Device.API = NULL;
	m_Device.Device = NULL;

	return TRUE;
}

BOOL CBillboard::Render(FLOAT Vert[], FLOAT Size, DWORD Color, BOOL Scale)
{
	// Transform the vertex to screen space
	D3DXMATRIX matWorld, matView, matProj, matIdentity;
	D3DVIEWPORT8 viewport;
	D3DXVECTOR3 v(Vert);

	m_Device.Device -> GetTransform(D3DTS_WORLD, &matWorld);
	m_Device.Device -> GetTransform(D3DTS_VIEW, &matView);
	m_Device.Device -> GetTransform(D3DTS_PROJECTION, &matProj);
	m_Device.Device -> GetViewport(&viewport);
	D3DXMatrixIdentity(&matIdentity);

	// TO DO: This must be done in the scene graph, not here
	if(Scale)
	{
		if(!IsPointInFrustum(&matView, &matProj, D3DXVECTOR3(Vert)))
			return FALSE;
	}

	// Figure out the screenspace position
	D3DXVec3Project(&v, &v, &viewport, &matProj, &matView, &matWorld);

	// Figure out the size
	FLOAT s;
	if(Scale)
	{
		D3DXVECTOR3 temp;
		BillboardLookAt(Vert, matView, Size, temp);
		D3DXVec3Project(&temp, &temp, &viewport, &matProj, &matView, &matIdentity);
		s = D3DXVec3Length(&(v - temp)) / 2;
	}
	else
	{
		// TO DO: Make sure this size computation is governed by a property
		// NOTE: the size of the particle is relative to the size of the viewport
		// the original size is considered to be in 640x480 coordinates!!!

		s = Size / 2.0f * (m_Device.Width / 640.0f);

		// See if we're inside the screen
		if(v.x + s < 0 || v.y + s < 0 || v.x - s > m_Device.Width || v.y - s > m_Device.Height)
			return FALSE;
	}

	// Render the quad
	BILLBOARDVERTEX g_Vertices[] =
	{
		{ v.x - s,	v.y - s,	v.z, 1.0f, Color, 0, 0,}, // x, y, z, rhw, color, tu, tv
		{ v.x + s,	v.y - s,	v.z, 1.0f, Color, 1, 0,},
		{ v.x - s,	v.y + s,	v.z, 1.0f, Color, 0, 1,},
		{ v.x + s,	v.y + s,	v.z, 1.0f, Color, 1, 1,},
	};

	// Set vertex shader
	m_Device.Device -> SetVertexShader(FVF_BILLBOARD);

	// Draw the primitive
	m_Device.Device -> DrawPrimitiveUP(
		D3DPT_TRIANGLESTRIP,
		2,
		g_Vertices,
		sizeof(BILLBOARDVERTEX)
		);

	return TRUE;
}

BOOL CBillboard::BillboardLookAt(const D3DXVECTOR3 &Pos, const D3DXMATRIX &Camera, FLOAT Size, D3DXVECTOR3 &Vector)
{
	D3DXVECTOR3 CamPos;
	m_Device.Camera -> GetPosition(CamPos);

	// Extract the camera position;
	//D3DXVECTOR3 CamPos(Camera._14, Camera._24, Camera._34);

	// Get the view vector
	D3DXVECTOR3 View = CamPos - Pos;
	D3DXVec3Normalize(&View, &View);

	// Get the world up vector
	D3DXVECTOR3 WorldUp(0.0f, 1.0f, 0.0f);

	// Get the right vector
	D3DXVECTOR3 Right;
	D3DXVec3Cross(&Right, &WorldUp, &View);
	D3DXVec3Normalize(&Right, &Right);

	Vector = Pos + Right * Size;

	return TRUE;
}
