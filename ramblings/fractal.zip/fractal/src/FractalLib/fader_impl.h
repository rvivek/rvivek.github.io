
#ifndef _FADER_IMPL_H_
#define _FADER_IMPL_H_

#include "fader.h"

class CFader : public IFader
{
public:
	CFader();
	virtual ~CFader();

	// Initialization / destruction
	virtual BOOL			Create(const VIDEODEVICE &Device, IAttributeStack *Stack);
	virtual BOOL			Destroy();

	// These functions should be called before the initialization
	virtual BOOL			SetInterval(FLOAT Interval, BOOL FadeIn);
	virtual BOOL			SetDimensions(UINT x, UINT y, UINT Width, UINT Height);

	// Action functions
	virtual BOOL			Tick(FLOAT Timeslice);
	virtual BOOL			Render();

private:
	VIDEODEVICE				m_Device;
	IAttributeStack			*m_pStack;

	FLOAT					m_Interval;
	FLOAT					m_Counter;
	BOOL					m_FadeIn;

	UINT					m_x, m_y, m_Width, m_Height;
};

#endif // _FADER_IMPL_H_
