
#ifndef _TEXTURE_IMPL_H_
#define _TEXTURE_IMPL_H_

#include <windows.h>
#include <d3d8.h>
#include <d3dx8.h>
#include "texture.h"
#include "hermes.h"

class CTexture : public ITexture
{
public:
	CTexture();
	virtual ~CTexture();

	virtual BOOL			Create(const VIDEODEVICE &Device, IAttributeStack *Stack);
	virtual BOOL			Destroy();

	// These functions can only be called before initialization
	virtual BOOL			SetSize(UINT Width, UINT Height);
	virtual BOOL			SetFormat(UINT Format);

	// Properties
	virtual BOOL			GetSize(UINT &Width, UINT &Height);
	virtual BOOL			GetTextureObject(TEXTURE &Texture);
	virtual UINT			GetRealFormat();

	// Action functions
	/* This will always be in a desired format and will be copied to
	video memory and converted automatically */
	virtual LPVOID			Lock(UINT &Pitch);
	virtual BOOL			Unlock();

private:
	HermesFormat*			CreateHermesFormat(UINT Format);

private:
	VIDEODEVICE				m_Device;
	IAttributeStack			*m_pStack;

	LPDIRECT3DTEXTURE8		m_pScratch;
	LPDIRECT3DTEXTURE8		m_pReal;
	D3DLOCKED_RECT			m_sdesc;

	HermesHandle			m_HermesHandle;
	HermesFormat			*m_SourceHermesFormat, *m_DestHermesFormat;

	UINT					m_Width, m_Height;
	UINT					m_ScratchFormat, m_RealFormat;
};

#endif // _TEXTURE_IMPL_H_
