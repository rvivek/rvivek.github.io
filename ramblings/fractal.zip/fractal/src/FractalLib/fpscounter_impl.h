
#ifndef _FPSCOUNTER_IMPL_H_
#define _FPSCOUNTER_IMPL_H_

#include "fpscounter.h"

#define FPS_LENGTH					50
#define DEFAULT_FPS_TIME			10

class CFPSCounter : public IFPSCounter
{
public:
	CFPSCounter();
	virtual ~CFPSCounter();
	
	virtual VOID			Tick();

	virtual FLOAT			GetTimeslice();
	virtual FLOAT			GetFramerate();

	virtual VOID			Activate();
	virtual VOID			Deactivate();

private:
	long					m_CurrentTime, m_PrevTime;
	long					m_TotalTime;
	long					m_Timing[FPS_LENGTH];

	bool					m_LostFocus;
};

#endif // _FPSCOUNTER_IMPL_H_
