
#include "text_impl.h"
#include "scom.h"

struct TEXTVERTEX
{
    FLOAT x, y, z, rhw; // The transformed position for the vertex.
    DWORD color;        // The vertex color.
	FLOAT tu, tv;		// Texture map
};

#define FVF_TEXT (D3DFVF_XYZRHW | D3DFVF_DIFFUSE | D3DFVF_TEX1)

#define CHARSIZE		1.0f / 16.0f

CText::CText()
{
	m_pFont = NULL;
}

CText::~CText()
{
}

BOOL CText::Create(const VIDEODEVICE &Device, IAttributeStack *Stack)
{
	m_Device = Device;
	m_pStack = Stack;

	return TRUE;
}

BOOL CText::Destroy()
{
	m_pStack = NULL;
	if(m_pFont != NULL)
	{
		m_pFont -> Release();
		m_pFont = NULL;
	}

	return TRUE;
}

BOOL CText::LoadText(LPCSTR Filename)
{
	if(FAILED(D3DXCreateTextureFromFileEx(
		m_Device.Device,
		Filename,
		D3DX_DEFAULT, D3DX_DEFAULT,
		1, 0,
		D3DFMT_UNKNOWN, D3DPOOL_MANAGED,
		D3DX_DEFAULT, D3DX_DEFAULT,
		0, NULL, NULL,
		&m_pFont
		)))
	{
		FRACTAL_ERROR(0, "Could not load text texture.");
		return FALSE;
	}

	return TRUE;
}

BOOL CText::DrawString(LPCSTR Text, FLOAT x, FLOAT y, FLOAT cw, FLOAT ch, DWORD Color)
{
	m_pStack -> Push();

	// Set vertex shader
	m_Device.Device -> SetVertexShader(FVF_TEXT);

	// Ze Texture :)
	m_Device.Device -> SetTexture(0, m_pFont);

	// Set the states
	m_Device.Device -> SetTextureStageState(0, D3DTSS_MAGFILTER, D3DTEXF_LINEAR);
	m_Device.Device -> SetTextureStageState(0, D3DTSS_MINFILTER, D3DTEXF_LINEAR);
	m_Device.Device -> SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE);
	m_Device.Device -> SetRenderState(D3DRS_ZENABLE, FALSE);
	m_Device.Device -> SetRenderState(D3DRS_CLIPPING, FALSE);
	m_Device.Device -> SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_Device.Device -> SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_Device.Device -> SetRenderState(D3DRS_DESTBLEND, D3DBLEND_ONE);

	for(UINT i = 0; i < strlen(Text); i++)
		DrawChar(Text[i], x + cw * i, y, cw, ch, Color);

	m_pStack -> Pop();

	return TRUE;
}

BOOL CText::DrawChar(char c, FLOAT x, FLOAT y, FLOAT cw, FLOAT ch, DWORD Color)
{
	// Figure out the texture coordinates
	FLOAT u = c % 16 * CHARSIZE;
	FLOAT v = c / 16 * CHARSIZE;

	// Render the character
	TEXTVERTEX g_Vertices[] =
	{
		{ x,		y,		0.0f, 1.0f, Color, u,				v,				}, // x, y, z, rhw, color, tu, tv
		{ x + cw,	y,		0.0f, 1.0f, Color, u + CHARSIZE,	v,				},
		{ x,		y + ch,	0.0f, 1.0f, Color, u,				v + CHARSIZE,	},
		{ x + cw,	y + ch,	0.0f, 1.0f, Color, u + CHARSIZE,	v + CHARSIZE,	},
	};

	// Draw the primitive
	m_Device.Device -> DrawPrimitiveUP(
		D3DPT_TRIANGLESTRIP,
		2,
		g_Vertices,
		sizeof(TEXTVERTEX)
		);

	return TRUE;
}
