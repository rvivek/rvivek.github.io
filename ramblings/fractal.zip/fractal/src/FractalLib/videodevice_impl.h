
#ifndef _VIDEODEVICEIMPL_H_
#define _VIDEODEVICEIMPL_H_

#include <windows.h>
#include <d3d8.h>
#include <stack>
#include "inc/videodevice.h"

#define VIDEO_DEFAULT_ADAPTER			D3DADAPTER_DEFAULT
#define VIDEO_DEFAULT_WIDTH				640
#define VIDEO_DEFAULT_HEIGHT			480
#define VIDEO_DEFAULT_FORMAT			D3DFMT_UNKNOWN
#define VIDEO_DEFAULT_REFRESHRATE		D3DFMT_UNKNOWN
#define VIDEO_DEFAULT_STENCIL			D3DFMT_UNKNOWN

#define DEPTH_BUFFER_FORMATS_COUNT	7
#define STATEBLOCK_MAX_DEPTH		32

class CVideoDevice : public IVideoDevice
{
public:
	CVideoDevice();
	virtual ~CVideoDevice();

	virtual BOOL			Create(const NATIVEWINDOW &Window);
	virtual BOOL			Destroy();

	// These state functions are used to control initialization
	virtual BOOL			SetAdapter(UINT uAdapter);
	virtual BOOL			SetResolution(UINT uWidth, UINT uHeight);
	virtual BOOL			SetColorDepth(UINT uFormat);
	virtual BOOL			SetRefreshRate(UINT uRefreshRate);
	virtual BOOL			SetStencilDepth(UINT uFormat = 0);

	// Information about hardware
	virtual UINT			GetAdapterCount();
	virtual BOOL			GetAdapterInfo(UINT uAdapter, ADAPTERINFO &adapter);

	virtual UINT			GetModeCount(UINT uAdapter);
	virtual BOOL			GetModeInfo(UINT uAdapter, UINT uMode, MODEINFO &mode);

	virtual UINT			GetStencilFormatCount();
	virtual UINT			GetStencilFormat(UINT uFormatIndex);

	// Access to internal structures
	virtual BOOL			GetDevice(VIDEODEVICE &device);

	// Inherited from IAttributeStack
	virtual BOOL			Push();
	virtual BOOL			Pop();
	virtual BOOL			ResetStack();

private:
	// State variables that control creation
	UINT					m_uAdapter;
	UINT					m_uWidth, m_uHeight;
	UINT					m_uFormat;
	UINT					m_uRefreshRate;
	UINT					m_uStencil;

	// The application window passed to the API
	NATIVEWINDOW			m_AppWindow;

	// Error
	HRESULT					m_hLastError;

	// D3D Interfaces
	LPDIRECT3D8				m_pAPI;
	LPDIRECT3DDEVICE8		m_pDevice;

	// Cached adapter information
	D3DADAPTER_IDENTIFIER8	m_AdapterId;

	// Supported depth stencil formats
	UINT					m_DepthStencilFormats[DEPTH_BUFFER_FORMATS_COUNT];
	UINT					m_DepthStencilCount;

	// State block
	DWORD					m_StateBlock;
	std::stack<DWORD>		m_StateStack;
	std::stack<DWORD>		m_StatePool;
};

#endif // _VIDEODEVICEIMPL_H_
