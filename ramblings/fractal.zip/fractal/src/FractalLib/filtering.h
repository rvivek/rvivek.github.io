
#ifndef _FILTERING_H_
#define _FILTERING_H_

enum FILTERTYPE
{
	FILTER_GAUSSIAN_BLUR
};

inline GetColor(VOID *pData, UINT Pitch, UINT Width, UINT Height, UINT x, UINT y)
{
}

void FilterBuffer(VOID *pData, UINT Pitch, UINT Width, UINT Height, FILTERTYPE Filter)
{

}

#endif // _FILTERING_H_
