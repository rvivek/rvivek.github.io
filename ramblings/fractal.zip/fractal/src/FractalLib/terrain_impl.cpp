
#include <string>
#include <d3dx8.h>
#include <fstream>
#include "fractal_errors.h"
#include "terrain_impl.h"
#include "noise.h"
#include "scom.h"

struct TERRAINVERTEX
{
    D3DXVECTOR3 pos;	// The transformed position for the vertex.
	D3DXVECTOR3 normal;	// Vertex normal 
    DWORD color;        // The vertex color.
	FLOAT tu, tv;		// Texture map
	FLOAT tu2, tv2;		// Texture map
};
#define FVF_TERRAIN (D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_DIFFUSE | D3DFVF_TEX2)

CTerrain::CTerrain()
{
	m_pIB = NULL;
	m_pVB = NULL;
	m_NumVertices = 0;
	m_NumIndices = 0;
	m_Device.API = NULL;
	m_Device.Device = NULL;
	m_pStack = NULL;

	m_HeightmapTex = NULL;
	m_Heightmap = NULL;

	m_Light.x = 200;
	m_Light.y = 20;
	m_Light.z = 0;
	D3DXVec3Normalize(&m_Light, &m_Light);

	m_Ambient = 0.05f;

	m_VerticalScale = TERRAIN_DEFAULT_VERTICALSCALE;
	m_HorizontalScale = TERRAIN_DEFAULT_HORIZONTALSCALE;

	m_Divisions = 0;
}

CTerrain::~CTerrain()
{
	if(m_pIB != NULL)
	{
		m_pIB -> Release();
		m_pIB = NULL;
	}
	if(m_pVB != NULL)
	{
		m_pVB -> Release();
		m_pVB = NULL;
	}

	m_NumVertices = 0;
	m_NumIndices = 0;


	for(LAYERLIST::iterator i = m_Layers.begin(); i != m_Layers.end(); i++)
	{
		LAYERINFO *pInfo = &(*i);
		if(pInfo -> pTexture != NULL)
			pInfo -> pTexture -> Release();
		if(pInfo -> pAlphaTexture != NULL)
			scDeleteComponent(pInfo -> pAlphaTexture);
	}

	// destroy the texture
	if(m_HeightmapTex != NULL)
	{
		m_HeightmapTex -> Release();
		m_HeightmapTex = NULL;
	}

	m_Device.API = NULL;
	m_Device.Device = NULL;

	if(m_Heightmap != NULL)
	{
		delete[] m_Heightmap;
		m_Heightmap = NULL;
	}
}

BOOL CTerrain::Create(const VIDEODEVICE &Device, IAttributeStack *Stack, LPCSTR Filename)
{
	m_Device = Device;
	m_pStack = Stack;

	// generate our terrain
	LoadHeightmap(Filename);

	// TO DO: MAX vertical size and MAX vertical scale
	m_NormalBase = m_VerticalScale * (2.0f / (m_HorizontalScale / m_Divisions));
	
	GenerateNormals();
	SetupGeometry();

	return TRUE;
}

BOOL CTerrain::Destroy()
{
	return TRUE;
}

BOOL CTerrain::SetScale(FLOAT Vertical, FLOAT Horizontal)
{
	m_VerticalScale = Vertical;
	m_HorizontalScale = Horizontal;

	return TRUE;
}

BOOL CTerrain::Render()
{
	m_pStack -> Push();

	// Set up the necessary states
	m_Device.Device -> SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_Device.Device -> SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_Device.Device -> SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
	m_Device.Device -> SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
	m_Device.Device -> SetRenderState(D3DRS_LIGHTING, TRUE);
	m_Device.Device -> SetRenderState(D3DRS_AMBIENTMATERIALSOURCE, D3DMCS_COLOR1);

	// The alpha map
	m_Device.Device -> SetTextureStageState(0, D3DTSS_MAGFILTER, D3DTEXF_LINEAR);
	m_Device.Device -> SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
	m_Device.Device -> SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG2);

	// The texture
	m_Device.Device -> SetTextureStageState(1, D3DTSS_MAGFILTER, D3DTEXF_LINEAR);
	m_Device.Device -> SetTextureStageState(1, D3DTSS_MINFILTER, D3DTEXF_LINEAR);
	m_Device.Device -> SetTextureStageState(1, D3DTSS_MIPFILTER, D3DTEXF_LINEAR);
	m_Device.Device -> SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_MODULATE2X);
	m_Device.Device -> SetTextureStageState(1, D3DTSS_ALPHAOP, D3DTOP_SELECTARG2);

	m_Device.Device -> SetStreamSource(0, m_pVB, sizeof(TERRAINVERTEX));
	m_Device.Device -> SetVertexShader(FVF_TERRAIN);
	m_Device.Device -> SetIndices(m_pIB, 0);

	for(LAYERLIST::iterator i = m_Layers.begin(); i != m_Layers.end(); i++)
	{
		LAYERINFO *pInfo = &(*i);

		TEXTURE tex;
		pInfo -> pAlphaTexture -> GetTextureObject(tex);
		m_Device.Device -> SetTexture(0, tex.Texture);
		m_Device.Device -> SetTexture(1, pInfo -> pTexture);

		m_Device.Device -> DrawIndexedPrimitive( D3DPT_TRIANGLELIST, 0, m_NumVertices, 0, m_NumIndices / 3 );
	}

	m_pStack -> Pop();

	return TRUE;
}

BOOL CTerrain::AddLayer(LPCSTR Filename, BYTE minh, BYTE maxh, FLOAT mins, FLOAT maxs)
{
	LAYERINFO info;

	// Save the values
	info.minh = (FLOAT)minh / 255.0f * m_VerticalScale;
	info.maxh = (FLOAT)maxh / 255.0f * m_VerticalScale;
	info.mins = mins;
	info.maxs = maxs;

	// Load the texture
	if(FAILED(D3DXCreateTextureFromFileEx(
		m_Device.Device,
		Filename,
		D3DX_DEFAULT, D3DX_DEFAULT,
		D3DX_DEFAULT,			// mipmap levels
		0, D3DFMT_UNKNOWN,
		D3DPOOL_MANAGED,
		D3DX_DEFAULT,
		D3DX_FILTER_BOX,		// mipmap filter
		0,
		NULL, NULL,
		&(info.pTexture)
		)))
	{
		FRACTAL_ERROR(-1, "Could not load terrain texture");
		return FALSE;
	}

	// Create the alpha texture
	info.pAlphaTexture = (ITexture*)scCreateComponent("Texture");
	info.pAlphaTexture -> SetSize(m_Divisions, m_Divisions);
	info.pAlphaTexture -> SetFormat(D3DFMT_A8R8G8B8);
	info.pAlphaTexture -> Create(m_Device, m_pStack);

	CalculateTexture(info);

	m_Layers.push_back(info);

	return TRUE;
}

FLOAT CTerrain::GetHeightAt(FLOAT x, FLOAT z)
{
	// TO DO: Implement
	return 0;
}

FLOAT CTerrain::GetVerticalScale()
{
	return m_VerticalScale;
}

FLOAT CTerrain::GetHorizontalScale()
{
	return m_HorizontalScale;
}

BOOL CTerrain::LoadHeightmap(LPCSTR Filename)
{
	// Create a texture in system memory
	D3DXIMAGE_INFO info;
	if(FAILED(D3DXCreateTextureFromFileEx(
		m_Device.Device,
		Filename,
		D3DX_DEFAULT, D3DX_DEFAULT,
		1, 0,
		D3DFMT_A8R8G8B8, D3DPOOL_SCRATCH,
		D3DX_FILTER_NONE, D3DX_FILTER_NONE,
		0,
		&info, NULL,
		&m_HeightmapTex
		)))
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not load the heightmap.");
		return FALSE;
	}
	
	D3DSURFACE_DESC info2;
	m_HeightmapTex -> GetLevelDesc(0, &info2);
	if((info.Width != info.Height) || (info2.Format != D3DFMT_A8R8G8B8))		// in bytes
	{
		m_HeightmapTex -> Release();
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Improper heightmap.");
		return FALSE;
	}
	
	m_Divisions = info.Width; // same as = info.Height
	m_Heightmap = new HEIGHTINFO[m_Divisions * m_Divisions];

	// copy the texture to the normal array
	D3DLOCKED_RECT desc;
	if(FAILED(m_HeightmapTex -> LockRect(0, &desc, NULL, 0)))
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not lock the texture.");
		return FALSE;
	}

	BYTE *pData = (BYTE*)desc.pBits;

	float hscale = m_HorizontalScale / m_Divisions;
	for(UINT y = 0; y < m_Divisions; y++)
	{
		for(UINT x = 0; x < m_Divisions; x++)
		{
			// TO DO: Scale this so HorizontalScale will be absolute
			m_Heightmap[y * m_Divisions + x].pos.x = y * hscale - (m_Divisions / 2) * hscale;
			m_Heightmap[y * m_Divisions + x].pos.z = x * hscale - (m_Divisions / 2) * hscale;
			m_Heightmap[y * m_Divisions + x].pos.y = ((FLOAT)(pData[x * 4]) / 255.0f) * m_VerticalScale;
			
			m_Heightmap[y * m_Divisions + x].tu = x * (1.0f / (m_Divisions - 1));	// alpha texture, don't repeat it
			m_Heightmap[y * m_Divisions + x].tv = y * (1.0f / (m_Divisions - 1));	// alpha texture, don't repeat it

			m_Heightmap[y * m_Divisions + x].tu2 = x * (1.0f / (m_Divisions - 1)) * TERRAIN_DEFAULT_DETAILREPEAT;	// texture, we need to repeat it
			m_Heightmap[y * m_Divisions + x].tv2 = y * (1.0f / (m_Divisions - 1)) * TERRAIN_DEFAULT_DETAILREPEAT;	// texture, we need to repeat it
		}
		pData += desc.Pitch;
	}

	m_HeightmapTex -> UnlockRect(0);

	return TRUE;
}

BOOL CTerrain::SetupGeometry()
{
	// calculate our vertices and indices amounts
	m_NumIndices = ((m_Divisions - 1) * (m_Divisions - 1)) * 2 * 3;
	m_NumVertices = (m_Divisions * m_Divisions);

	// create vertex buffer
	if(FAILED(m_Device.Device -> CreateVertexBuffer(
		m_NumVertices * sizeof(TERRAINVERTEX),
		0,
		FVF_TERRAIN,
		D3DPOOL_MANAGED,
		&m_pVB
		)))
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not create the vertex buffer.");
		return FALSE;
	}

	// create index buffer
	if(FAILED(m_Device.Device -> CreateIndexBuffer(
		m_NumIndices * sizeof(WORD),
		0,
		D3DFMT_INDEX16,
		D3DPOOL_MANAGED,
		&m_pIB
		)))
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not create the index buffer.");
		return FALSE;
	}

	// Generate vertices
	TERRAINVERTEX *pVertices;
	if(FAILED(m_pVB -> Lock(0, 0, (BYTE**)&pVertices, 0)))
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not lock the vertex buffer.");
		return FALSE;
	}

	TERRAINVERTEX temp;
	// IMPORTANT: CHECK THIS
	for(UINT i = 0; i <= (m_Divisions - 1); i++)
	{
		for(UINT j = 0; j <= (m_Divisions - 1); j++)
		{
			// set the vertex coordinates
			temp.pos = m_Heightmap[i * m_Divisions + j].pos;
			temp.pos.y = m_Heightmap[i * m_Divisions + j].pos.y;

			temp.normal = m_Heightmap[i * m_Divisions + j].normal;

			// calculate the light
			CalculateLighting(temp.color, i, j);

			temp.tu = m_Heightmap[i * m_Divisions + j].tu;
			temp.tv = m_Heightmap[i * m_Divisions + j].tv;

			temp.tu2 = m_Heightmap[i * m_Divisions + j].tu2;
			temp.tv2 = m_Heightmap[i * m_Divisions + j].tv2;

			pVertices[i * (m_Divisions) + j] = temp;
		}
	}

	m_pVB -> Unlock();

	// Generate indices
	WORD *pIndices;
	if(FAILED(m_pIB -> Lock(0, 0, (BYTE**)&pIndices, 0)))
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "FRACTAL_INVALID_PARAMETER");
		return FALSE;
	}

	int index = 0;
	for(i = 0; i < (m_Divisions - 1); i++)
	{
		for(UINT j = 0; j < (m_Divisions - 1); j++)
		{
			int startvert = (i * (m_Divisions) + j);
			// triangle 1
			pIndices[index++] = startvert;
			pIndices[index++] = startvert + 1;
			pIndices[index++] = startvert + m_Divisions;
			// triangle 2
			pIndices[index++] = startvert + 1;
			pIndices[index++] = startvert + m_Divisions + 1;
			pIndices[index++] = startvert + m_Divisions;
		}
	}

	m_pIB -> Unlock();

	return TRUE;
}

BOOL CTerrain::CalculateLighting(D3DCOLOR &Color, UINT i, UINT j)
{
	float light = D3DXVec3Dot(&m_Light, &m_Heightmap[i * m_Divisions + j].normal);
	if(light < 0)
		light = 0;
	light += m_Ambient;
	if(light > 1)
		light = 1;
	//Color = D3DCOLOR_ARGB(255, BYTE(255.0f * light), BYTE(255.0f * light), BYTE(255.0f * light));
	Color = D3DCOLOR_ARGB(255, 255, 255, 255);

	return TRUE;
}

BOOL CTerrain::GenerateNormals()
{
	LPDIRECT3DTEXTURE8 TempTexture;
	m_Device.Device -> CreateTexture(
		m_Divisions, m_Divisions,
		1,
		0,
		D3DFMT_R8G8B8,
		D3DPOOL_SCRATCH,
		&TempTexture
		);
	
	if(FAILED(D3DXComputeNormalMap(
		TempTexture,
		m_HeightmapTex,
		NULL,
		0,
		D3DX_CHANNEL_RED,
		m_NormalBase
		)))
	{
		TempTexture -> Release();
		TempTexture = NULL;
	}

	// Vertex normal
	D3DLOCKED_RECT TextureInfo;
	TempTexture -> LockRect(0, &TextureInfo, NULL, 0);
	BYTE *pData = (BYTE*)TextureInfo.pBits;

	for(UINT i = 0; i < m_Divisions; i++)
	{
		for(UINT j = 0; j < m_Divisions; j++)
		{

			m_Heightmap[i * m_Divisions + j].normal.x = (pData[j * 3 + 2] / 256.0f - 0.5f) * 2.0f;
			m_Heightmap[i * m_Divisions + j].normal.y = (pData[j * 3 + 0] / 256.0f - 0.5f) * 2.0f;	// y and z should be flipped
			m_Heightmap[i * m_Divisions + j].normal.z = (pData[j * 3 + 1] / 256.0f - 0.5f) * 2.0f;	// y and z should be flipped
			D3DXVec3Normalize(&m_Heightmap[i * m_Divisions + j].normal, &m_Heightmap[i * m_Divisions + j].normal);
		}
		pData += TextureInfo.Pitch;
	}

	TempTexture -> UnlockRect(0);
	TempTexture -> Release();
	TempTexture = NULL;

	return TRUE;
}

BOOL CTerrain::CalculateTexture(LAYERINFO &Info)
{
	// Lock the texture
	UINT Pitch;
	BYTE *pData = (BYTE*)Info.pAlphaTexture -> Lock(Pitch);

	for(UINT y = 0; y < m_Divisions; y++)
	{
		for(UINT x = 0; x < m_Divisions; x++)
		{
			pData[x * 4 + 0] = 0;//IsLayerVisible(&Info, x, y) ? 255 : 0;
			pData[x * 4 + 1] = 0;//IsLayerVisible(&Info, x, y) ? 255 : 0;
			pData[x * 4 + 2] = 0;//IsLayerVisible(&Info, x, y) ? 255 : 0;
			pData[x * 4 + 3] = IsLayerVisible(&Info, x, y) ? 255 : 0;
		}
		pData += Pitch;
	}
		
	// Unlock the texture
	Info.pAlphaTexture -> Unlock();

	return TRUE;
}

BOOL CTerrain::IsPixelVisible(const LAYERINFO *pInfo, UINT x, UINT y)
{
	// check for bounds
	if(x < 0 || x >= m_Divisions)
	{
		FRACTAL_WARNING(FRACTAL_INVALID_PARAMETER, "FRACTAL_INVALID_PARAMETER");
		return FALSE;
	}
	if(y < 0 || y >= m_Divisions)
	{
		FRACTAL_WARNING(FRACTAL_INVALID_PARAMETER, "FRACTAL_INVALID_PARAMETER");
		return FALSE;
	}

	// Get the vertex info
	HEIGHTINFO hi = m_Heightmap[y * m_Divisions + x];

	// Check the height
	if(hi.pos.y > pInfo -> maxh)
	{
		FRACTAL_WARNING(FRACTAL_INVALID_PARAMETER, "FRACTAL_INVALID_PARAMETER");
		return FALSE;
	}
	if(hi.pos.y < pInfo -> minh)
	{
		FRACTAL_WARNING(FRACTAL_INVALID_PARAMETER, "FRACTAL_INVALID_PARAMETER");
		return FALSE;
	}

	// TO DO: Calculate the slope
	/*D3DXVECTOR3 planenorm(0, 1, 0);
	float slope = D3DXVec3Dot(&planenorm, &hi.normal);
	slope = 90 - D3DXToDegree(acosf(slope));
	if(slope > 90)
		slope = 180 - slope;

	// Check the slope
	if(slope < pInfo -> mins)
		return FALSE;
	if(slope > pInfo -> maxs)
		return FALSE;*/
	
	return TRUE;
}

BOOL CTerrain::IsLayerVisible(const LAYERINFO *pInfo, UINT x, UINT y)
{
	// if any of the 8 neighbors is visible, the pixel is visible
	if(IsPixelVisible(pInfo, x - 1, y - 1))
		return TRUE;
	if(IsPixelVisible(pInfo, x + 0, y - 1))
		return TRUE;
	if(IsPixelVisible(pInfo, x + 1, y - 1))
		return TRUE;
	if(IsPixelVisible(pInfo, x - 1, y + 0))
		return TRUE;
	if(IsPixelVisible(pInfo, x + 0, y + 0))
		return TRUE;
	if(IsPixelVisible(pInfo, x + 1, y + 0))
		return TRUE;
	if(IsPixelVisible(pInfo, x - 1, y + 1))
		return TRUE;
	if(IsPixelVisible(pInfo, x + 0, y + 1))
		return TRUE;
	if(IsPixelVisible(pInfo, x + 1, y + 1))
		return TRUE;
	

	return FALSE;
}
