
#ifndef _SKYDOME_IMPL_H_
#define _SKYDOME_IMPL_H_

#include <windows.h>
#include <d3d8.h>
#include <d3dx8.h>
#include "skydome.h"
#include "billboard.h"
#include "texture.h"

#define SKYDOME_DEFAULT_ARADIUS			15000
#define SKYDOME_DEFAULT_HRADIUS			13500
#define SKYDOME_DEFAULT_DIVISIONS		16
#define SKYDOME_DEFAULT_TEXTURE_SIZE	64
#define SKYDOME_DEFAULT_HEIGHT			1000
#define SKYDOME_DEFAULT_DENSITY			210
#define SKYDOME_DEFAULT_FLUFFINESS		0.96f
#define SKYDOME_DEFAULT_SUN_TEXTURE_SIZE	64

class CSkydome : public ISkydome
{
public:
	CSkydome();
	virtual ~CSkydome();

	// Initialization / destruction
	virtual BOOL			Create(const VIDEODEVICE &Device, IAttributeStack *Stack);
	virtual BOOL			Destroy();

	// These functions can only be called before initialization
	virtual BOOL			SetHeight(FLOAT Height);
	virtual BOOL			SetRadius(FLOAT ARadius, FLOAT HRadius);
	virtual BOOL			SetCloudsTextureSize(UINT Size);
	virtual BOOL			SetSkydomeTesselation(UINT Tesselation);
	virtual BOOL			SetGradientTexture(LPCSTR Texture);
	virtual BOOL			SetSunTexture(LPCSTR Texture);

	// The functions control the behavior of the component
	virtual BOOL			SetWindVelocity(FLOAT dx, FLOAT dy);
	virtual BOOL			SetCloudColors(DWORD Color1, DWORD Color2);
	virtual BOOL			SetCloudDensity(BYTE Density, FLOAT Fluffiness);
	virtual BOOL			SetCloudFrequency(FLOAT Freq, UINT Octaves);
	virtual BOOL			SetShadingFrequency(FLOAT Freq, UINT Octaves);
	virtual BOOL			SetModificationConstant(FLOAT Modification);
	virtual BOOL			SetSunColor(DWORD Color);
	virtual BOOL			SetSunDiameter(FLOAT Diameter);
	virtual BOOL			SetSunPosition(FLOAT Position[]);

	// Action functions
	virtual BOOL			Tick(FLOAT Timeslice);
	virtual BOOL			Render();

private:
	BOOL					GenerateSkydome();
	BOOL					UpdateCloudTexture(float Timeslice);

private:
	VIDEODEVICE				m_Device;
	IAttributeStack			*m_pStack;

	LPDIRECT3DINDEXBUFFER8	m_pIB;
	LPDIRECT3DVERTEXBUFFER8	m_pVB;
	ITexture				*m_pCloudsTex;
	LPDIRECT3DTEXTURE8		m_Gradient; // Color gradient of the sky
	LPDIRECT3DTEXTURE8		m_pSun;		// Sun texture
	LPSTR					m_GradientName;
	LPSTR					m_SunName;

	IBillboard				*m_pBillboard;

	UINT					m_NumVertices;
	UINT					m_NumIndices;
	FLOAT					m_SkyCounter;

	FLOAT					m_ARadius, m_HRadius;
	FLOAT					m_Height;
	UINT					m_TextureSize;
	UINT					m_SkydomeTesselation;

	D3DXVECTOR2				m_Wind;
	FLOAT					m_Modification;
	D3DXCOLOR				m_CloudColor1, m_CloudColor2;
	BYTE					m_Density;
	FLOAT					m_Fluffiness;

	FLOAT					m_CloudFreq;
	UINT					m_CloudOctaves;
	FLOAT					m_ShadingFreq;
	UINT					m_ShadingOctaves;

	DWORD					m_SunColor;
	FLOAT					m_SunDiameter;
	D3DXVECTOR3				m_SunPosition;

	FLOAT					m_TimeDimension;

	// Current translation values for the clouds
	FLOAT					m_utran, m_vtran;
};

#endif // _SKYDOME_IMPL_H_
