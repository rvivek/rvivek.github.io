
#ifndef _TEXT_IMPL_H_
#define _TEXT_IMPL_H_

#include <windows.h>
#include <d3d8.h>
#include <d3dx8.h>
#include "text.h"

class CText : public IText
{
public:
	CText();
	virtual ~CText();

	// Initialization / destruction
	virtual BOOL			Create(const VIDEODEVICE &Device, IAttributeStack *Stack);
	virtual BOOL			Destroy();

	virtual BOOL			LoadText(LPCSTR Filename);

	// Let's get some action
	virtual BOOL			DrawString(LPCSTR Text, FLOAT x, FLOAT y, FLOAT cw, FLOAT ch, DWORD Color);

private:
	BOOL					DrawChar(char c, FLOAT x, FLOAT y, FLOAT cw, FLOAT ch, DWORD Color);

private:
	VIDEODEVICE				m_Device;
	IAttributeStack			*m_pStack;

	LPDIRECT3DTEXTURE8		m_pFont;
};

#endif // _TEXT_IMPL_H_
