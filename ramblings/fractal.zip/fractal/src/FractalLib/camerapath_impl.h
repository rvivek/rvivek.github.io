
#ifndef _CAMERAPATH_IMPL_H_
#define _CAMERAPATH_IMPL_H_

#include <vector>
#include <d3dx8.h>
#include "camerapath.h"

typedef struct _POINTINFO
{
	D3DXQUATERNION		Quat;
	D3DXVECTOR3			Pos;
} POINTINFO;

class CCameraPath : public ICameraPath
{
public:
	CCameraPath();
	virtual ~CCameraPath();

	// Initialization / destruction
	virtual BOOL			Create();
	virtual BOOL			Create(LPCSTR Filename);
	virtual BOOL			Destroy();

	// Control
	virtual BOOL			AddControlPoint(const D3DXMATRIX &mat, const D3DXVECTOR3 &Pos);

	// Information
	virtual BOOL			GetMatrix(D3DXMATRIX &Matrix);
	virtual BOOL			GetPosition(D3DXVECTOR3 &Pos);

	// Action functions
	virtual BOOL			Slerp(FLOAT s);

private:
	BOOL					InitLengths();
	FLOAT					CalculateLength(POINTINFO Points[4], FLOAT start, FLOAT end, UINT level);

private:
	std::vector<POINTINFO>	m_Points;
	std::vector<FLOAT>		m_Segments;
	POINTINFO				m_CurrentPoint;

	FLOAT					m_Length;
};

#endif // _CAMERAPATH_IMPL_H_
