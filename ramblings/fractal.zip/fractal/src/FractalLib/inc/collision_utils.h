
#ifndef _COLLISION_UTILS_H_
#define _COLLISION_UTILS_H_

#include <d3dx8.h>
#include "scom_types.h"
#include "scom_component.h"
#include "fractal_types.h"

// Forward declarations
struct CULLINFO;
inline BOOL IsPointInFrustum(D3DXMATRIX* pMatView, D3DXMATRIX* pMatProj, D3DXVECTOR3 Pos, FLOAT Dist = 0);
inline void ExtractFrustum(CULLINFO* pCullInfo, const D3DXMATRIX* pMatView, const D3DXMATRIX* pMatProj);

// Some definitions
struct CULLINFO
{
    D3DXVECTOR3 vecFrustum[8];    // corners of the view frustum
    D3DXPLANE planeFrustum[6];    // planes of the view frustum
};

// Let's get to work
BOOL IsPointInFrustum(D3DXMATRIX* pMatView, D3DXMATRIX* pMatProj, D3DXVECTOR3 Pos, FLOAT Dist)
{
	CULLINFO info;
	ExtractFrustum(&info, pMatView, pMatProj);

	for(int p = 0; p < 6; p++)
		if(info.planeFrustum[p].a * Pos.x + info.planeFrustum[p].b * Pos.y + info.planeFrustum[p].c * Pos.z + info.planeFrustum[p].d < Dist)
			return FALSE;

	return TRUE;
}

// Lets get to work
void ExtractFrustum(CULLINFO* pCullInfo, const D3DXMATRIX* pMatView, const D3DXMATRIX* pMatProj)
{
	// TO DO: optimize so we don't call this all the time
    D3DXMATRIX mat;

    D3DXMatrixMultiply( &mat, pMatView, pMatProj );
    D3DXMatrixInverse( &mat, NULL, &mat );

    pCullInfo->vecFrustum[0] = D3DXVECTOR3(-1.0f, -1.0f,  0.0f); // xyz
    pCullInfo->vecFrustum[1] = D3DXVECTOR3( 1.0f, -1.0f,  0.0f); // Xyz
    pCullInfo->vecFrustum[2] = D3DXVECTOR3(-1.0f,  1.0f,  0.0f); // xYz
    pCullInfo->vecFrustum[3] = D3DXVECTOR3( 1.0f,  1.0f,  0.0f); // XYz
    pCullInfo->vecFrustum[4] = D3DXVECTOR3(-1.0f, -1.0f,  1.0f); // xyZ
    pCullInfo->vecFrustum[5] = D3DXVECTOR3( 1.0f, -1.0f,  1.0f); // XyZ
    pCullInfo->vecFrustum[6] = D3DXVECTOR3(-1.0f,  1.0f,  1.0f); // xYZ
    pCullInfo->vecFrustum[7] = D3DXVECTOR3( 1.0f,  1.0f,  1.0f); // XYZ

    for( INT i = 0; i < 8; i++ )
        D3DXVec3TransformCoord( &pCullInfo->vecFrustum[i], &pCullInfo->vecFrustum[i], &mat );

    D3DXPlaneFromPoints( &pCullInfo->planeFrustum[0], &pCullInfo->vecFrustum[0], 
        &pCullInfo->vecFrustum[1], &pCullInfo->vecFrustum[2] ); // Near
    D3DXPlaneFromPoints( &pCullInfo->planeFrustum[1], &pCullInfo->vecFrustum[6], 
        &pCullInfo->vecFrustum[7], &pCullInfo->vecFrustum[5] ); // Far
    D3DXPlaneFromPoints( &pCullInfo->planeFrustum[2], &pCullInfo->vecFrustum[2], 
        &pCullInfo->vecFrustum[6], &pCullInfo->vecFrustum[4] ); // Left
    D3DXPlaneFromPoints( &pCullInfo->planeFrustum[3], &pCullInfo->vecFrustum[7], 
        &pCullInfo->vecFrustum[3], &pCullInfo->vecFrustum[5] ); // Right
    D3DXPlaneFromPoints( &pCullInfo->planeFrustum[4], &pCullInfo->vecFrustum[2], 
        &pCullInfo->vecFrustum[3], &pCullInfo->vecFrustum[6] ); // Top
    D3DXPlaneFromPoints( &pCullInfo->planeFrustum[5], &pCullInfo->vecFrustum[1], 
        &pCullInfo->vecFrustum[0], &pCullInfo->vecFrustum[4] ); // Bottom
}

inline FLOAT Vec3Dist(const D3DXVECTOR3 &Vec1, const D3DXVECTOR3 &Vec2)
{
	FLOAT x = (Vec1.x - Vec2.x) * (Vec1.x - Vec2.x);
	FLOAT y = (Vec1.y - Vec2.y) * (Vec1.y - Vec2.y);
	FLOAT z = (Vec1.z - Vec2.z) * (Vec1.z - Vec2.z);
	FLOAT Length = sqrtf(x + y + z);
	return Length;
}

#endif // _COLLISION_UTILS_H_
