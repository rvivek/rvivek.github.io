
#ifndef _TASKINTERFACE_H_
#define _TASKINTERFACE_H_

#include "scom_types.h"
#include "fractal_types.h"

interface ITask;

typedef struct _TASKPARAM
{
	UINT				Param;
	FLOAT				Duration;
	FLOAT				CurrentTime;
} TASKPARAM;

typedef struct _FRACTALTASK
{
	FLOAT				StartTime;
	FLOAT				EndTime;

	ITask				*Task;
	TASKPARAM			Param;
} FRACTALTASK;

interface ITask
{
	virtual BOOL		ExecuteTask(FLOAT Timeslice, const TASKPARAM &Param) = 0;
};

#endif // _TASKINTERFACE_H_
