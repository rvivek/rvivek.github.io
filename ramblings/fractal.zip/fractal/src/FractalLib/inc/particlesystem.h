
#ifndef _PARTICLESYSTEM_H_
#define _PARTICLESYSTEM_H_

#include "scom_types.h"
#include "fractal_types.h"
#include "particle.h"

interface IParticleSystem
{
	/*
		RETVAL < 0,			the system should be deleted.
		RETVAL == 0,		do nothing
		RETVAL > 0,			call the Emit() function
	*/
	virtual INT				Tick(FLOAT Timeslice) = 0;

	/*
		Updates the particle
		RETVAL == FALSE,	remove the particle
		RETVAL == TRUE,		do nothing
	*/
	virtual BOOL			UpdateParticle(PARTICLE *Particle, FLOAT Timeslice) = 0;

	/*
		RETVAL == FALSE,	render the particle
		RETVAL == TRUE,		do nothing
	*/
	virtual BOOL			Render(const PARTICLE &Particle) = 0;

	/*
		Accepts an array of particles of size returned by the last Tick()
		Fills up the array with new particles
		RETVAL == TRUE,		The array is filled succesfully
		RETVAL == FALSE,	There was an error
	*/
	virtual BOOL			Emit(PARTICLE *Particle) = 0;
};

#endif // _PARTICLESYSTEM_H_
