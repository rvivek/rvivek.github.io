
#ifndef _FPSCOUNTER_H_
#define _FPSCOUNTER_H_

#include "scom_types.h"
#include "scom_component.h"
#include "fractal_types.h"

interface IFPSCounter : public IComponent
{
	virtual VOID			Tick() = 0;

	virtual FLOAT			GetTimeslice() = 0;
	virtual FLOAT			GetFramerate() = 0;

	virtual VOID			Activate() = 0;
	virtual VOID			Deactivate() = 0;
};

#endif // _FPSCOUNTER_H_
