
#ifndef _TERRAIN_H_
#define _TERRAIN_H_

#include "scom_types.h"
#include "scom_component.h"
#include "fractal_types.h"
#include "attributestack.h"

interface ITerrain : public IComponent
{
	// Initialization / destruction
	virtual BOOL			Create(const VIDEODEVICE &Device, IAttributeStack *Stack, LPCSTR Heightmap) = 0;
	virtual BOOL			Destroy() = 0;

	// These functions can only be called before initialization
	virtual BOOL			SetScale(FLOAT Vertical, FLOAT Horizontal) = 0;

	// These functions can only be called after initialization
	virtual BOOL			AddLayer(LPCSTR Filename, BYTE minh, BYTE maxh, FLOAT mins, FLOAT maxs) = 0;

	// Other functions
	virtual FLOAT			GetHeightAt(FLOAT x, FLOAT z) = 0;

	// Property accessors
	virtual FLOAT			GetVerticalScale() = 0;
	virtual FLOAT			GetHorizontalScale() = 0;

	// Action functions
	virtual BOOL			Render() = 0;
};

#endif // _TERRAIN_H_
