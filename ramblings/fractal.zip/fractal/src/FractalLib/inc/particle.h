
#ifndef _PARTICLE_H_
#define _PARTICLE_H_

#include "scom_types.h"
#include "fractal_types.h"
#include "particlesystem.h"

// TO DO: Implement a memory pool

interface IParticleSystem;
typedef struct _PARTICLE
{
	FLOAT				x, y, z;		// Position
	FLOAT				dx, dy, dz;

	FLOAT				age, maxage;

	BYTE				a, r, g, b;		// Particle color
	TEXTURE				Texture;		// Particle texture
	FLOAT				size;			// Particle's size
	
	IParticleSystem		*System;		// A system that controls the particle
} PARTICLE;

#endif // _PARTICLE_H_
