
#ifndef _FADER_H_
#define _FADER_H_

#include "scom_types.h"
#include "scom_component.h"
#include "fractal_types.h"
#include "attributestack.h"

interface IFader : public IComponent
{
	// Initialization / destruction
	virtual BOOL			Create(const VIDEODEVICE &Device, IAttributeStack *Stack) = 0;
	virtual BOOL			Destroy() = 0;

	// These functions should be called before the initialization
	virtual BOOL			SetInterval(FLOAT Interval, BOOL FadeIn) = 0;
	virtual BOOL			SetDimensions(UINT x, UINT y, UINT Width, UINT Height) = 0;

	// Action functions
	virtual BOOL			Tick(FLOAT Timeslice) = 0;
	virtual BOOL			Render() = 0;
};

#endif // _FADER_H_
