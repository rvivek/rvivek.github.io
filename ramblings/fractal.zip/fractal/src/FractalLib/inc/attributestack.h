
#ifndef _ATTRIBUTE_STACK_H_
#define _ATTRIBUTE_STACK_H_

#include "scom_types.h"

interface IAttributeStack
{
	virtual BOOL			Push() = 0;
	virtual BOOL			Pop() = 0;

	virtual BOOL			ResetStack() = 0;
};

#endif // _ATTRIBUTE_STACK_H_
