
#ifndef _FRACTALTYPES_H_
#define _FRACTALTYPES_H_

#include "fractal_config.h"
#include "fractal_types.h"
#include "camera.h"			// TO DO: dirty hack

// Include the necessary headers
#ifdef FRACTAL_WIN32
#include <windows.h>
#endif

#ifdef FRACTAL_VIDEO_DIRECTX
#include <d3d8.h>
#endif

// Information about the application's window
typedef struct _NATIVEWINDOW
{
#ifdef FRACTAL_WIN32
	HWND Wnd;
#endif
	BOOL Windowed;
} NATIVEWINDOW;

// Window message handler
#ifdef FRACTAL_WIN32
typedef LRESULT (*WINDOWMESSAGEHANDLER)(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
#endif

// Information about a video device
typedef struct _VIDEODEVICE
{
#ifdef FRACTAL_VIDEO_DIRECTX
	IDirect3D8			*API;
	IDirect3DDevice8	*Device;
	// TO DO: These are DIRTY hacks. Pass these values to other classes differently
	CCamera				*Camera;
	UINT				Width, Height;
#endif
} VIDEODEVICE;

// Texture object
typedef struct _TEXTURE
{
#ifdef FRACTAL_VIDEO_DIRECTX
	IDirect3DTexture8	*Texture;
#endif
} TEXTURE;

#endif // _FRACTALTYPES_H_
