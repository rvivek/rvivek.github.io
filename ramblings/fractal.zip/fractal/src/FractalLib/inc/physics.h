
#ifndef _PHYSICS_H_
#define _PHYSICS_H_

#include <math.h>

// x is the cos between the normal and the eye vector
inline FLOAT Fresnel(FLOAT x)
{
	return 1 / powf((x + 1), 8);
}

#endif // _PHYSICS_H_
