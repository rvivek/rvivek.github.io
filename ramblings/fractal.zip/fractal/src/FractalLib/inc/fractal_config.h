
#ifndef _FRACTALCONFIG_H_
#define _FRACTALCONFIG_H_

// We're working on win32 platform
#define FRACTAL_WIN32					1

// We're using directx as our video api
#define FRACTAL_VIDEO_DIRECTX			1

#endif // _FRACTALCONFIG_H_
