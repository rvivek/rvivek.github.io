
#ifndef _CAMERA_H_
#define _CAMERA_H_

#include <d3dx8.h>
#include <ostream>
#include <istream>

class CCamera
{
public:
	CCamera()
	{
		Pos = D3DXVECTOR3(0, 0, 0);
		R = D3DXVECTOR3(1, 0, 0);
		U = D3DXVECTOR3(0, 1, 0);
		V = D3DXVECTOR3(0, 0, 1);

		m_fov = D3DX_PI/4;
		m_aspect = 1.0f;
		m_near = 10.0f;
		m_far = 100000.0f;
	}
	~CCamera() {}

	void SetPosition(const D3DXVECTOR3 &Position)
	{
		Pos = Position;
	}

	void GetPosition(D3DXVECTOR3 &Position)
	{
		Position = Pos;
	}
	
	void MoveForward(FLOAT Delta)
	{
		Pos.x += Delta * V.x;
		Pos.y += Delta * V.y;
		Pos.z += Delta * V.z;
	}

	void Yaw(FLOAT Angle)			// Arount Y axes
	{
		D3DXMATRIX mat;
		D3DXMatrixRotationAxis(&mat, &U, Angle);
		D3DXVec3TransformCoord(&R, &R, &mat);
		D3DXVec3TransformCoord(&V, &V, &mat);
		D3DXVec3Normalize(&R, &R);
		D3DXVec3Normalize(&V, &V);
		NormalizeBasis();
	}
	void Pitch(FLOAT Angle)			// Around X axes
	{
		D3DXMATRIX mat;
		D3DXMatrixRotationAxis(&mat, &R, Angle);
		D3DXVec3TransformCoord(&U, &U, &mat);
		D3DXVec3TransformCoord(&V, &V, &mat);
		D3DXVec3Normalize(&U, &U);
		D3DXVec3Normalize(&V, &V);
		NormalizeBasis();
	}
	void Roll(FLOAT Angle)			// Around Z Axes
	{
		D3DXMATRIX mat;
		D3DXMatrixRotationAxis(&mat, &V, Angle);
		D3DXVec3TransformCoord(&U, &U, &mat);
		D3DXVec3TransformCoord(&R, &R, &mat);
		D3DXVec3Normalize(&U, &U);
		D3DXVec3Normalize(&R, &R);
		NormalizeBasis();
	}

	void GetCameraMatrix(D3DXMATRIX &Matrix)
	{
		D3DXMatrixLookAtLH(
			&Matrix,
			&Pos,
			&D3DXVECTOR3(Pos + V),
			&U
			);
	}

	void SetCameraMatrix(const D3DXMATRIX &Matrix)
	{
		R.x = Matrix._11;
		R.y = Matrix._21;
		R.z = Matrix._31;
		U.x = Matrix._12;
		U.y = Matrix._22;
		U.z = Matrix._32;
		V.x = Matrix._13;
		V.y = Matrix._23;
		V.z = Matrix._33;

		NormalizeBasis();
	}

	// Projection
	void SetFOV(FLOAT fov)
	{
		m_fov = fov;
	}
	
	void SetAspect(FLOAT aspect)
	{
		m_aspect = aspect;
	}

	void SetCullPlanes(FLOAT n, FLOAT f)
	{
		m_near = n;
		m_far = f;
	}

	void GetProjMatrix(D3DXMATRIX &Matrix)
	{
	    D3DXMatrixPerspectiveFovLH( &Matrix, m_fov, m_aspect, m_near, m_far );
	}

	// Serialization operators
	std::ostream& operator>>(std::ostream &out)
	{
		// Orientation
		out << R.x << ' ';
		out << R.y << ' ';
		out << R.z << std::endl;
		out << U.x << ' ';
		out << U.y << ' ';
		out << U.z << std::endl;
		out << V.x << ' ';
		out << V.y << ' ';
		out << V.z << std::endl;

		// Position
		out << Pos.x << ' ';
		out << Pos.y << ' ';
		out << Pos.z << std::endl;

		// Perspective
		out << m_fov << ' ';
		out << m_aspect << std::endl;
		out << m_near << ' ';
		out << m_far << ' ';

		out << std::endl;
		out << std::endl;
		out << std::endl;

		return out;
	}

	std::istream& operator<<(std::istream &in)
	{
		in >> R.x;
		in >> R.y;
		in >> R.z;
		in >> U.x;
		in >> U.y;
		in >> U.z;
		in >> V.x;
		in >> V.y;
		in >> V.z;

		// Position
		in >> Pos.x;
		in >> Pos.y;
		in >> Pos.z;

		// Perspective
		in >> m_fov;
		in >> m_aspect;
		in >> m_near;
		in >> m_far;

		return in;
	}

protected:
	virtual void NormalizeBasis()
	{
		D3DXVec3Cross(&R, &V, &U);
	}

protected:
	D3DXVECTOR3		R, U, V;
	D3DXVECTOR3		Pos;

	FLOAT			m_fov, m_aspect, m_near, m_far;
};

#endif // _CAMERA_H_
