
#ifndef _VIDEODEVICE_H_
#define _VIDEODEVICE_H_

#include "scom_types.h"
#include "scom_component.h"
#include "fractal_types.h"
#include "attributestack.h"

typedef struct _ADAPTERINFO
{
	LPCSTR Driver;
	LPCSTR Description;
} ADAPTERINFO;

typedef struct _MODEINFO
{
	UINT Width;
	UINT Height;
	UINT Format;
	UINT RefreshRate;
} MODEINFO;

interface IVideoDevice : public IComponent, public IAttributeStack
{
	// Initialization / destruction
	virtual BOOL			Create(const NATIVEWINDOW &Window) = 0;
	virtual BOOL			Destroy() = 0;

	// These state functions are used to control initialization
	virtual BOOL			SetAdapter(UINT Adapter) = 0;
	virtual BOOL			SetResolution(UINT Width, UINT Height) = 0;
	virtual BOOL			SetColorDepth(UINT Format) = 0;
	virtual BOOL			SetRefreshRate(UINT RefreshRate) = 0;
	virtual BOOL			SetStencilDepth(UINT Format = 0) = 0;

	// Information about hardware
	virtual UINT			GetAdapterCount() = 0;
	virtual BOOL			GetAdapterInfo(UINT Adapter, ADAPTERINFO &AdapterInfo) = 0;

	virtual UINT			GetModeCount(UINT Adapter) = 0;
	virtual BOOL			GetModeInfo(UINT Adapter, UINT Mode, MODEINFO &ModeInfo) = 0;

	virtual UINT			GetStencilFormatCount() = 0;
	virtual UINT			GetStencilFormat(UINT FormatIndex) = 0;

	// Access to internal structures
	virtual BOOL			GetDevice(VIDEODEVICE &Device) = 0;
};

#endif // _VIDEODEVICE_H_
