
#ifndef _WATERSURFACE_H_
#define _WATERSURFACE_H_

#include "scom_types.h"
#include "scom_component.h"
#include "fractal_types.h"
#include "attributestack.h"

interface IWaterSurface : public IComponent
{
	virtual BOOL			Create(const VIDEODEVICE &Device, IAttributeStack *Stack) = 0;
	virtual BOOL			Destroy() = 0;

	virtual BOOL			SetTextureSize(UINT Size) = 0;
	virtual BOOL			SetEnvironmentMap(LPCSTR Filename) = 0;	// TO DO: Change this

	virtual BOOL			SetSideSize(FLOAT Size) = 0;

	virtual BOOL			Tick(FLOAT Timeslice) = 0;
	virtual BOOL			Render() = 0;
};

#endif // _WATERSURFACE_H_
