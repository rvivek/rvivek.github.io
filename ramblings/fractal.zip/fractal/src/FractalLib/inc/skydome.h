
#ifndef _SKYDOME_H_
#define _SKYDOME_H_

#include "scom_types.h"
#include "scom_component.h"
#include "fractal_types.h"
#include "attributestack.h"

interface ISkydome : public IComponent
{
	// Initialization / destruction
	virtual BOOL			Create(const VIDEODEVICE &Device, IAttributeStack *Stack) = 0;
	virtual BOOL			Destroy() = 0;

	// These functions can only be called before initialization
	virtual BOOL			SetHeight(FLOAT Height) = 0;
	virtual BOOL			SetRadius(FLOAT ARadius, FLOAT HRadius) = 0;

	virtual BOOL			SetCloudsTextureSize(UINT Size) = 0;
	virtual BOOL			SetSkydomeTesselation(UINT Tesselation) = 0;

	virtual BOOL			SetGradientTexture(LPCSTR Texture) = 0;
	virtual BOOL			SetSunTexture(LPCSTR Texture) = 0;

	// The functions control the behavior of the component
	virtual BOOL			SetWindVelocity(FLOAT dx, FLOAT dy) = 0;
	virtual BOOL			SetModificationConstant(FLOAT Modification) = 0;
	
	virtual BOOL			SetCloudColors(DWORD Color1, DWORD Color2) = 0;
	virtual BOOL			SetCloudDensity(BYTE Density, FLOAT Fluffiness) = 0;
	virtual BOOL			SetCloudFrequency(FLOAT Freq, UINT Octaves) = 0;
	virtual BOOL			SetShadingFrequency(FLOAT Freq, UINT Octaves) = 0;	
	
	virtual BOOL			SetSunColor(DWORD Color) = 0;
	virtual BOOL			SetSunDiameter(FLOAT Diameter) = 0;
	virtual BOOL			SetSunPosition(FLOAT Position[]) = 0;

	// Action functions
	virtual BOOL			Tick(FLOAT Timeslice) = 0;
	virtual BOOL			Render() = 0;
};

#endif // _SKYDOME_H_
