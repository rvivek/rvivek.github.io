
#ifndef _PROGRESSBAR_H_
#define _PROGRESSBAR_H_

#include "scom_types.h"
#include "scom_component.h"
#include "fractal_types.h"
#include "attributestack.h"

interface IProgressBar : public IComponent
{
	// Initialization / destruction
	virtual BOOL			Create(const VIDEODEVICE &Device, IAttributeStack *Stack) = 0;
	virtual BOOL			Destroy() = 0;

	// These functions can only be called before initialization
	virtual BOOL			SetSize(FLOAT Width, FLOAT Height) = 0;
	virtual BOOL			SetPosition(FLOAT X, FLOAT Y) = 0;
	virtual BOOL			SetColor(DWORD Color) = 0;

	// These functions can be called at any time
	virtual BOOL			SetMinMax(FLOAT Min, FLOAT Max) = 0;
	virtual BOOL			SetValue(FLOAT Value) = 0;

	// Action functions
	virtual BOOL			Render() = 0;
};

#endif // _PROGRESSBAR_H_
