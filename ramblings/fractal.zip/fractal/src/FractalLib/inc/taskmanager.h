
#ifndef _TASKMANAGER_H_
#define _TASKMANAGER_H_

#include "scom_types.h"
#include "scom_component.h"
#include "fractal_types.h"
#include "attributestack.h"
#include "taskinterface.h"

interface ITaskManager : public IComponent
{
	// Initialization / destruction
	virtual BOOL			Create() = 0;
	virtual BOOL			Destroy() = 0;

	// Control functions
	virtual BOOL			AddTask(const FRACTALTASK &Task) = 0;
	virtual BOOL			SetCurrentTime(FLOAT Time) = 0;

	// Action functions
	virtual BOOL			Tick(FLOAT Timeslice) = 0;
};

#endif // _TASKMANAGER_H_
