
#ifndef _TEXT_H_
#define _TEXT_H_

#include "scom_types.h"
#include "scom_component.h"
#include "fractal_types.h"
#include "attributestack.h"

interface IText : public IComponent
{
	// Initialization / destruction
	virtual BOOL			Create(const VIDEODEVICE &Device, IAttributeStack *Stack) = 0;
	virtual BOOL			Destroy() = 0;

	virtual BOOL			LoadText(LPCSTR Filename) = 0;

	// Let's get some action
	virtual BOOL			DrawString(LPCSTR Text, FLOAT x, FLOAT y, FLOAT cw, FLOAT ch, DWORD Color) = 0;
};

#endif // _TEXT_H_
