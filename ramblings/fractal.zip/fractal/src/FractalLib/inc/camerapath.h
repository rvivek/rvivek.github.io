
#ifndef _CAMERAPATH_H_
#define _CAMERAPATH_H_

#include "scom_types.h"
#include "scom_component.h"
#include "fractal_types.h"
#include "attributestack.h"

interface ICameraPath : public IComponent
{
	// Initialization / destruction
	virtual BOOL			Create() = 0;
	virtual BOOL			Create(LPCSTR Filename) = 0;
	virtual BOOL			Destroy() = 0;

	// Control
	virtual BOOL			AddControlPoint(const D3DXMATRIX &mat, const D3DXVECTOR3 &Pos) = 0;

	// Information
	virtual BOOL			GetMatrix(D3DXMATRIX &Matrix) = 0;
	virtual BOOL			GetPosition(D3DXVECTOR3 &Pos) = 0;

	// Action functions
	virtual BOOL			Slerp(FLOAT s) = 0;
};

#endif // _CAMERAPATH_H_
