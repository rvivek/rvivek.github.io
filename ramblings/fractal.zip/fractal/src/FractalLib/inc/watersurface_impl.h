
#ifndef _WATERSURFACE_IMPL_H_
#define _WATERSURFACE_IMPL_H_

#include "watersurface.h"

class CWaterSurface : public IWaterSurface
{
public:
	CWaterSurface();
	virtual ~CWaterSurface();

	virtual BOOL			Create(const VIDEODEVICE &Device, IAttributeStack *Stack);
	virtual BOOL			Destroy();

	virtual BOOL			SetTextureSize(UINT Size);
	virtual BOOL			SetEnvironmentMap(LPCSTR Filename);

	virtual BOOL			SetSideSize(FLOAT Size);

	virtual BOOL			Tick(FLOAT Timeslice);
	virtual BOOL			Render();

private:
	BOOL					UpdateTexture(FLOAT Timeslice);
	BOOL					UpdateGeometry(FLOAT Timeslice);
	BOOL					GenerateGeometry();

private:
	VIDEODEVICE				m_Device;
	IAttributeStack			*m_Stack;

	LPDIRECT3DINDEXBUFFER8	m_pIB;
	LPDIRECT3DVERTEXBUFFER8	m_pVB;
	
	LPDIRECT3DTEXTURE8		m_pHeightmap;
	LPDIRECT3DTEXTURE8		m_pNormalMap;
	LPDIRECT3DCUBETEXTURE8	m_pEnvMap;

	UINT					m_NumVertices;
	UINT					m_NumIndices;
	UINT					m_Tesselation;

	UINT					m_TextureSize;
	UINT					m_TextureRepeats;
	FLOAT					m_SideSize;
	FLOAT					m_VerticalScale;
	D3DXVECTOR3				m_Position;

	FLOAT					m_ColorThreshold;
	FLOAT					m_FresnelThreshold;

	FLOAT					m_TimeDimension;
	FLOAT					m_Counter;
};

#endif // _WATERSURFACE_IMPL_H_
