
#ifndef _NATIVEWINDOW_H_
#define _NATIVEWINDOW_H_

#include "scom_types.h"
#include "scom_component.h"
#include "fractal_types.h"

interface INativeWindow : public IComponent
{
	// Initialization / destruction
	virtual BOOL			Create() = 0;
	virtual BOOL			Destroy() = 0;

	// These functions can only be called prior to initialization to control initialization
	virtual BOOL			SetWindowed(BOOL Windowed) = 0;

	// These functions control the properties and can be called both before and after initialization
	virtual BOOL			SetSize(UINT Width, UINT Height, BOOL ModifyClientRect = TRUE) = 0;
	virtual BOOL			SetPosition(UINT x, UINT y) = 0;
	virtual BOOL			SetTitle(LPCSTR Title) = 0;
	virtual BOOL			SetMessageHandler(WINDOWMESSAGEHANDLER MessageHandler) = 0;
	
	// Property accessors
	virtual BOOL			IsWindowed() = 0;
	virtual BOOL			GetSize(UINT &Width, UINT &Height) = 0;
	virtual BOOL			GetPosition(UINT &x, UINT &y) = 0;
	virtual LPCSTR			GetTitle() = 0;

	// State accessors
	virtual BOOL			IsActive() = 0;

	// Access to internal structures
	virtual BOOL			GetNative(NATIVEWINDOW &Window) = 0;
};

#endif // _NATIVEWINDOW_H_
