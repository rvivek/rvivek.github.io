
#ifndef _UNIFORM_NOISE_H_
#define _UNIFORM_NOISE_H_

#include <math.h>
#include <stdlib.h>

/*
seeds the random number generator
*/
inline void Seed(unsigned long i)
{
	srand(i);
}

/*
returns a float between 0.0 and 1.0 (uniform distribution)
*/
inline float Random()
{
	return float(rand()) / float(RAND_MAX);
}

/*
returns a value between min and max
*/
inline float Random(float low, float high)
{
	if(high < low)
	{
		float temp = high;
		high = low;
		low = temp;
	}

	float range = high - low; 
	float num; 

    do
	{
		long l = rand();
		num = (range * (float)l) / (float) RAND_MAX; 
	}
	while(num == 0);
    return( num + low ); 
}

/*
returns a float (normal distribution)
m - mean, s - standard deviation
*/
inline float NormDist(float m, float s)
{
	float x1, x2, w, y1;
	static float y2;
	static int use_last = 0;

	if (use_last)		        /* use value from previous call */
	{
		y1 = y2;
		use_last = 0;
	}
	else
	{
		do {
			x1 = 2.0f * Random() - 1.0f;
			x2 = 2.0f * Random() - 1.0f;
			w = x1 * x1 + x2 * x2;
		} while ( w >= 1.0f );

		w = sqrtf( (-2.0f * logf( w ) ) / w );
		y1 = x1 * w;
		y2 = x2 * w;
		use_last = 1;
	}

	return( m + y1 * s );
}

/*
makes sure the value isn't less then min
*/
inline float ClampMin(float min, float value)
{
	if(value < min)
		return min;
	else
		return value;
}
	
/*
makes sure the value isn't more then max
*/
inline float ClampMax(float max, float value)
{
	if(value > max)
		return max;
	else
		return value;
}

/*
makes sure the value isn't more then max and less then min
*/
inline float Clamp(float min, float max, float value)
{
	float r = value;
	if(r < min)
		r = min;
	if(r > max)
		r = max;

	return r;
}

/*
if(value > -range) value = - range;
if(value < range) value = range;
*/
inline float ClampMiddle(float range, float value)
{
	float r;
	if(value > -range) r = - range;
	if(value < range) r = range;
	
	return r;
}

inline FLOAT Lerp(FLOAT f1, FLOAT f2, float lerp)
{
	return f1 + ((f2 - f1) * lerp);
}

inline BYTE Lerp(BYTE b1, BYTE b2, float lerp)
{
	float f1 = (FLOAT)b1;
	float f2 = (FLOAT)b2;
	return (BYTE)Lerp(f1, f2, lerp);
}

#endif // _UNIFORM_NOISE_H_
