
#ifndef _FPSCAMERA_H_
#define _FPSCAMERA_H_

#include <d3dx8.h>
#include "camera.h"

class CFPSCamera : public CCamera
{
public:
	CFPSCamera() : CCamera()
	{
	}
	~CFPSCamera() {}

	void SetPosition(const D3DXVECTOR3 &Position)
	{
		CCamera::SetPosition(Position);
	}

	void GetPosition(D3DXVECTOR3 &Position)
	{
		CCamera::GetPosition(Position);
	}
	
	void MoveForward(FLOAT Delta)
	{
		CCamera::MoveForward(Delta);
	}

	void Strafe(FLOAT Delta)
	{
		Pos.x += Delta * R.x;
		Pos.y += Delta * R.y;
		Pos.z += Delta * R.z;
	}

	void Turn(FLOAT Angle)			// Arount Y axes
	{
		D3DXMATRIX mat;
		D3DXMatrixRotationAxis(&mat, &D3DXVECTOR3(0, 1, 0), Angle);
		D3DXVec3TransformCoord(&R, &R, &mat);
		D3DXVec3TransformCoord(&V, &V, &mat);
		D3DXVec3Normalize(&R, &R);
		D3DXVec3Normalize(&V, &V);
		NormalizeBasis();
	}
	void LookUp(FLOAT Angle)		// Around X axes
	{
		D3DXMATRIX mat;
		D3DXMatrixRotationAxis(&mat, &R, Angle);
		//D3DXVec3TransformCoord(&U, &U, &mat);
		D3DXVec3TransformCoord(&V, &V, &mat);
		//D3DXVec3Normalize(&U, &U);
		D3DXVec3Normalize(&V, &V);
		NormalizeBasis();
	}

protected:
	virtual void NormalizeBasis()
	{
		U = D3DXVECTOR3(0, 1, 0);
		CCamera::NormalizeBasis();
	}
};

#endif // _FPSCAMERA_H_
