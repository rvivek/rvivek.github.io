
/*
A class for PROCEDURAL textures
*/

#ifndef _TEXTURE_H_
#define _TEXTURE_H_

#include "scom_types.h"
#include "scom_component.h"
#include "fractal_types.h"
#include "attributestack.h"

interface ITexture : public IComponent
{
	// Initialization / destruction
	virtual BOOL			Create(const VIDEODEVICE &Device, IAttributeStack *Stack) = 0;
	virtual BOOL			Destroy() = 0;

	// These functions can only be called before initialization
	virtual BOOL			SetSize(UINT Width, UINT Height) = 0;
	virtual BOOL			SetFormat(UINT Format) = 0;

	// Properties
	virtual BOOL			GetSize(UINT &Width, UINT &Height) = 0;
	virtual BOOL			GetTextureObject(TEXTURE &Texture) = 0;
	virtual UINT			GetRealFormat() = 0;

	// Action functions
	/* This will always be in a desired format and will be copied to
	video memory and converted automatically */
	virtual LPVOID			Lock(UINT &Pitch) = 0;
	virtual BOOL			Unlock() = 0;
};

#endif // _TEXTURE_H_
