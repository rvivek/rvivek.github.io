
#ifndef _PARTICLESYSTEMMANAGER_H_
#define _PARTICLESYSTEMMANAGER_H_

#include "scom_types.h"
#include "scom_component.h"
#include "fractal_types.h"
#include "particlesystem.h"
#include "attributestack.h"

interface IParticleSystemManager : public IComponent
{
	// Initialization / destruction
	virtual BOOL			Create(const VIDEODEVICE &Device, IAttributeStack *Stack) = 0;
	virtual BOOL			Destroy() = 0;

	virtual BOOL			AddParticleSystem(IParticleSystem *System) = 0;

	// Action functions
	virtual BOOL			Tick(FLOAT Timeslice) = 0;
	virtual BOOL			Render() = 0;
};

#endif // _PARTICLESYSTEMMANAGER_H_
