
#ifndef _COLLIDEABLE_H_
#define _COLLIDEABLE_H_

#include <d3dx8.h>
#include "scom_types.h"
#include "scom_component.h"
#include "fractal_types.h"

interface ICollideable : public IComponent
{
	// Object/object intersection
	virtual BOOL			IsInsideFrustum(D3DXMATRIX* pMatView, D3DXMATRIX* pMatProj) = 0;
	
	//virtual BOOL			IsInsideBox() = 0;
	//virtual BOOL			IsInsideSphere() = 0;
	//virtual BOOL			IsInsideCyllinder() = 0;
};

#endif // _COLLIDEABLE_H_
