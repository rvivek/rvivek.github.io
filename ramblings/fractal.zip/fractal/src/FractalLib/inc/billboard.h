
#ifndef _BILLBOARD_H_
#define _BILLBOARD_H_

#include "scom_types.h"
#include "scom_component.h"
#include "fractal_types.h"

interface IBillboard : public IComponent
{
	virtual BOOL			Create(const VIDEODEVICE &Device) = 0;
	virtual BOOL			Destroy() = 0;

	virtual BOOL			Render(FLOAT Vertex[], FLOAT Size, DWORD Color, BOOL Scale = FALSE) = 0;
};

#endif // _BILLBOARD_H_
