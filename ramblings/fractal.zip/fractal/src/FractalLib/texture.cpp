
#include "texture_impl.h"
#include "fractal_errors.h"
#include "scom.h"

CTexture::CTexture()
{
	// Init the conversion library
	Hermes_Init();

	m_pScratch = NULL;
	m_pReal = NULL;
}

CTexture::~CTexture()
{
	Destroy();

	// Free the conversion library
	Hermes_Done();
}

BOOL CTexture::Create(const VIDEODEVICE &Device, IAttributeStack *Stack)
{
	m_Device = Device;
	m_pStack = Stack;

	// Create the scratch texture
	if(FAILED(D3DXCreateTexture(
		m_Device.Device,
		m_Width, m_Height,
		1, 0,
		(D3DFORMAT)m_ScratchFormat,
		D3DPOOL_SCRATCH,
		&m_pScratch
		)))
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not create the texture.");
		return FALSE;
	}

	// Create the real texture
	if(FAILED(D3DXCreateTexture(
		m_Device.Device,
		m_Width, m_Height,
		1, 0,
		(D3DFORMAT)m_ScratchFormat,
		D3DPOOL_MANAGED,
		&m_pReal
		)))
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not create the texture.");
		return FALSE;
	}

	// Get the file format
	D3DSURFACE_DESC desc;
	m_pReal -> GetLevelDesc(0, &desc);
	m_RealFormat = desc.Format;

	// Create the converter
	m_SourceHermesFormat = CreateHermesFormat(m_ScratchFormat);
	m_DestHermesFormat = CreateHermesFormat(m_RealFormat);

	m_HermesHandle = Hermes_ConverterInstance(0);
	Hermes_ConverterRequest(m_HermesHandle, m_SourceHermesFormat, m_DestHermesFormat);

	return TRUE;
}

BOOL CTexture::Destroy()
{
	if(m_pReal != NULL)
	{
		m_pReal -> Release();
		m_pReal = NULL;
	}
	if(m_pScratch != NULL)
	{
		m_pScratch -> Release();
		m_pScratch = NULL;
	}

	// Get rid of the converter
	Hermes_ConverterReturn(m_HermesHandle);

	return TRUE;
}

BOOL CTexture::SetSize(UINT Width, UINT Height)
{
	m_Width = Width;
	m_Height = Height;

	return TRUE;
}

BOOL CTexture::SetFormat(UINT Format)
{
	m_ScratchFormat = Format;

	return TRUE;
}

BOOL CTexture::GetSize(UINT &Width, UINT &Height)
{
	Width = m_Width;
	Height = m_Height;

	return TRUE;
}

BOOL CTexture::GetTextureObject(TEXTURE &Texture)
{
	Texture.Texture = m_pReal;
	return TRUE;
}

UINT CTexture::GetRealFormat()
{
	return m_RealFormat;
}

LPVOID CTexture::Lock(UINT &Pitch)
{
	m_pScratch -> LockRect(0, &m_sdesc, NULL, 0);
	
	Pitch = m_sdesc.Pitch;
	return m_sdesc.pBits;
}

BOOL CTexture::Unlock()
{
	// Lock the real
	D3DLOCKED_RECT ddesc;
	m_pReal -> LockRect(0, &ddesc, NULL, 0);

	if(!Hermes_ConverterCopy(
		m_HermesHandle,
		m_sdesc.pBits,
		0, 0,
		m_Width, m_Height,
		m_sdesc.Pitch,
		ddesc.pBits,
		0, 0,
		m_Width, m_Height,
		ddesc.Pitch
		))
	{
		m_pReal -> UnlockRect(0);
		m_pScratch -> UnlockRect(0);

		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not convert the texture formats.");
		return FALSE;
	}

	// Unlock
	m_pReal -> UnlockRect(0);
	m_pScratch -> UnlockRect(0);

	return TRUE;
}

HermesFormat* CTexture::CreateHermesFormat(UINT Format)
{
	DWORD abits, rbits, gbits, bbits;
	UINT bits;

	switch(Format)
	{
	case D3DFMT_R8G8B8:
		bits = 24;
		abits = 0x0;
		rbits = 0xFF0000;
		gbits = 0xFF00;
		bbits = 0xFF;
		break;
	case D3DFMT_X8R8G8B8:
		bits = 32;
		abits = 0x0;
		rbits = 0xFF0000;
		gbits = 0xFF00;
		bbits = 0xFF;
		break;
	case D3DFMT_A8R8G8B8:
		bits = 32;
		abits = 0xFF000000;
		rbits = 0xFF0000;
		gbits = 0xFF00;
		bbits = 0xFF;
		break;
	case D3DFMT_R5G6B5:
		bits = 16;
		abits = 0x0;
		rbits = 0xF800;
		gbits = 0x7E0;
		bbits = 0x1F;
		break;
	case D3DFMT_X1R5G5B5:
		bits = 16;
		abits = 0x0;
		rbits = 0xF800;
		gbits = 0x7E0;
		bbits = 0x1F;
		break;
	case D3DFMT_A1R5G5B5:
		bits = 16;
		abits = 0x8000;
		rbits = 0xF800;
		gbits = 0x7E0;
		bbits = 0x1F;
		break;
	case D3DFMT_A8:
		bits = 8;
		abits = 0xFF;
		rbits = 0x0;
		gbits = 0x0;
		bbits = 0x0;
		break;
	default:
		return NULL;
	}

	HermesFormat *temp = Hermes_FormatNew(bits, rbits, gbits, bbits, abits, 0);
	return temp;
}
