
#include "fractal_errors.h"
#include "videodevice_impl.h"
#include "scom.h"

CVideoDevice::CVideoDevice()
{
	m_uWidth = VIDEO_DEFAULT_WIDTH;
	m_uHeight = VIDEO_DEFAULT_HEIGHT;
	m_uFormat = VIDEO_DEFAULT_FORMAT;
	m_uRefreshRate = VIDEO_DEFAULT_REFRESHRATE;
	m_uStencil = VIDEO_DEFAULT_STENCIL;

	m_pAPI = Direct3DCreate8(D3D_SDK_VERSION);
	if(m_pAPI == NULL)
		FRACTAL_ERROR(FRACTAL_INVALID_API, "Incorrect version of DirectX.");

	m_pDevice = NULL;
	m_DepthStencilCount = 0;

	SetAdapter(VIDEO_DEFAULT_ADAPTER);
}

CVideoDevice::~CVideoDevice()
{
	Destroy();
}

BOOL CVideoDevice::Create(const NATIVEWINDOW &window)
{
	if(m_pAPI == NULL)
	{
		FRACTAL_ERROR(FRACTAL_NOT_INITIALIZED, "FRACTAL_NOT_INITIALIZED");
		return FALSE;
	}
	if(m_pDevice != NULL)
	{
		FRACTAL_ERROR(FRACTAL_ALREADY_INITIALIZED, "FRACTAL_ALREADY_INITIALIZED");
		return FALSE;
	}

	if(window.Wnd == NULL)
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Invalid window.");
		return FALSE;
	}

	m_AppWindow = window;

	// Specify some basic stuff
	D3DPRESENT_PARAMETERS d3dpp;
	ZeroMemory(&d3dpp, sizeof(D3DPRESENT_PARAMETERS));
	d3dpp.Windowed			= m_AppWindow.Windowed;
	d3dpp.hDeviceWindow		= m_AppWindow.Wnd;
	d3dpp.SwapEffect		= D3DSWAPEFFECT_DISCARD;

	// Stencil surface
	if(m_uStencil != D3DFMT_UNKNOWN)
	{
		d3dpp.EnableAutoDepthStencil = TRUE;
		d3dpp.AutoDepthStencilFormat = (D3DFORMAT)m_uStencil;
	}

	// Backbuffer format
	if(m_AppWindow.Windowed)
	{
		D3DDISPLAYMODE currentMode;
		m_pAPI -> GetAdapterDisplayMode(m_uAdapter, &currentMode);
		d3dpp.BackBufferFormat = currentMode.Format;
	}
	else
		d3dpp.BackBufferFormat = (D3DFORMAT)m_uFormat;

	// Backbuffer suze
	if(!m_AppWindow.Windowed)
	{
		d3dpp.BackBufferWidth = m_uWidth;
		d3dpp.BackBufferHeight = m_uHeight;
	}

	// Refresh rate
	if(!m_AppWindow.Windowed && m_uRefreshRate != D3DFMT_UNKNOWN)
		d3dpp.FullScreen_RefreshRateInHz = m_uRefreshRate;

	// Flags
	DWORD flags = 0;
	D3DCAPS8 caps;
	m_pAPI -> GetDeviceCaps(m_uAdapter, D3DDEVTYPE_HAL, &caps);
	if(caps.DevCaps & D3DDEVCAPS_HWTRANSFORMANDLIGHT == D3DDEVCAPS_HWTRANSFORMANDLIGHT)
		flags |= D3DCREATE_HARDWARE_VERTEXPROCESSING;
		//flags |= D3DCREATE_MIXED_VERTEXPROCESSING;
	else
		flags |= D3DCREATE_SOFTWARE_VERTEXPROCESSING;
		
	// Do the magic!
	if(FAILED(m_pAPI -> CreateDevice(
		m_uAdapter,
		D3DDEVTYPE_HAL,
		m_AppWindow.Wnd,
		flags,
		&d3dpp,
		&m_pDevice
		)))
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not create video device.");
		return FALSE;
	}

	// Fill up the state blocks
	if(FAILED(m_pDevice -> CreateStateBlock(D3DSBT_ALL, &m_StateBlock)))
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not create the state block.");
		return FALSE;
	}
	for(int i = 0; i < STATEBLOCK_MAX_DEPTH; i++)
	{
		DWORD Temp;
		m_pDevice -> CreateStateBlock(D3DSBT_ALL, &Temp);
		m_StatePool.push(Temp);
	}

	return TRUE;
}

BOOL CVideoDevice::Destroy()
{
	if(m_pDevice != NULL)
	{
		m_pDevice -> DeleteStateBlock(m_StateBlock);

		for(int i = 0; i < STATEBLOCK_MAX_DEPTH; i++)
		{
			DWORD Temp;
			Temp = m_StatePool.top();
			m_StatePool.pop();
			m_pDevice -> DeleteStateBlock(Temp);
		}

		m_pDevice -> Release();
		m_pDevice = NULL;
	}
	else
	{
		FRACTAL_WARNING(FRACTAL_NOT_INITIALIZED, "FRACTAL_NOT_INITIALIZED");
		return FALSE;
	}

	if(m_pAPI != NULL)
	{
		m_pAPI -> Release();
		m_pAPI = NULL;
	}
	else
	{
		FRACTAL_WARNING(FRACTAL_NOT_INITIALIZED, "FRACTAL_NOT_INITIALIZED");
		return FALSE;
	}

	return TRUE;
}

// These state functions are used to control initialization
BOOL CVideoDevice::SetAdapter(UINT uAdapter)
{
	if(m_pDevice != NULL)
	{
		FRACTAL_ERROR(FRACTAL_ALREADY_INITIALIZED, "FRACTAL_ALREADY_INITIALIZED");
		return FALSE;
	}

	m_uAdapter = uAdapter;

	// Update the format
	D3DDISPLAYMODE currentMode;
	if(FAILED(m_pAPI -> GetAdapterDisplayMode(m_uAdapter, &currentMode)))
	{
		FRACTAL_ERROR(0, "Invalid adapter specified.");
		return FALSE;
	}
	m_uFormat = currentMode.Format;

	return TRUE;
}

BOOL CVideoDevice::SetResolution(UINT uWidth, UINT uHeight)
{
	if(m_pDevice != NULL)
	{
		FRACTAL_ERROR(FRACTAL_ALREADY_INITIALIZED, "FRACTAL_ALREADY_INITIALIZED");
		return FALSE;
	}

	m_uWidth = uWidth;
	m_uHeight = uHeight;

	return TRUE;
}

BOOL CVideoDevice::SetColorDepth(UINT uFormat)
{
	if(m_pDevice != NULL)
	{
		FRACTAL_ERROR(FRACTAL_ALREADY_INITIALIZED, "FRACTAL_ALREADY_INITIALIZED");
		return FALSE;
	}

	m_uFormat = uFormat;

	return TRUE;
}

BOOL CVideoDevice::SetStencilDepth(UINT uFormat)
{
	if(m_pDevice != NULL)
	{
		FRACTAL_ERROR(FRACTAL_ALREADY_INITIALIZED, "FRACTAL_ALREADY_INITIALIZED");
		return FALSE;
	}

	m_uStencil = uFormat;

	return TRUE;
}

BOOL CVideoDevice::SetRefreshRate(UINT uRefreshRate)
{
	if(m_pDevice != NULL)
	{
		FRACTAL_ERROR(FRACTAL_ALREADY_INITIALIZED, "FRACTAL_ALREADY_INITIALIZED");
		return FALSE;
	}

	m_uRefreshRate = uRefreshRate;

	return TRUE;
}

// Information about hardware
UINT CVideoDevice::GetAdapterCount()
{
	if(m_pAPI == NULL)
	{
		FRACTAL_ERROR(FRACTAL_NOT_INITIALIZED, "FRACTAL_NOT_INITIALIZED");
		return FALSE;
	}

	return m_pAPI -> GetAdapterCount();
}

BOOL CVideoDevice::GetAdapterInfo(UINT uAdapter, ADAPTERINFO &adapter)
{
	if(m_pAPI == NULL)
	{
		FRACTAL_ERROR(FRACTAL_NOT_INITIALIZED, "FRACTAL_NOT_INITIALIZED");
		return FALSE;
	}

	if(FAILED(m_pAPI -> GetAdapterIdentifier(uAdapter, D3DENUM_NO_WHQL_LEVEL, &m_AdapterId)))
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Invalid adapter.");
		return FALSE;
	}

	adapter.Description = m_AdapterId.Description;
	adapter.Driver = m_AdapterId.Driver;

	return TRUE;
}

UINT CVideoDevice::GetModeCount(UINT uAdapter)
{
	if(m_pAPI == NULL)
	{
		FRACTAL_ERROR(FRACTAL_NOT_INITIALIZED, "FRACTAL_NOT_INITIALIZED");
		return FALSE;
	}

	return m_pAPI -> GetAdapterModeCount(uAdapter);
}

BOOL CVideoDevice::GetModeInfo(UINT uAdapter, UINT uMode, MODEINFO &mode)
{
	if(m_pAPI == NULL)
	{
		FRACTAL_ERROR(FRACTAL_NOT_INITIALIZED, "FRACTAL_NOT_INITIALIZED");
		return FALSE;
	}

	D3DDISPLAYMODE m;
	if(FAILED(m_pAPI -> EnumAdapterModes(uAdapter, uMode, &m)))
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Invalid adapter.");
		return FALSE;
	}

	mode.Format = m.Format;
	mode.Height = m.Height;
	mode.Width = m.Width;
	mode.RefreshRate = m.RefreshRate;

	return TRUE;
}

UINT CVideoDevice::GetStencilFormatCount()
{
	// Create a list of supported depth-stencil formats
	UINT formats[] = {
		D3DFMT_D24S8,
		D3DFMT_D24X4S4,
		D3DFMT_D15S1,
		D3DFMT_D32,
		D3DFMT_D24X8,
		D3DFMT_D16,
		D3DFMT_D16_LOCKABLE
	};

	for(int i = 0; i < DEPTH_BUFFER_FORMATS_COUNT; i++)
	{
		if(
			SUCCEEDED(m_pAPI -> CheckDeviceFormat(
				m_uAdapter,
				D3DDEVTYPE_HAL,
				(D3DFORMAT)m_uFormat,
				D3DUSAGE_DEPTHSTENCIL,
				D3DRTYPE_SURFACE,
				(D3DFORMAT)formats[i]
				)) && SUCCEEDED(m_pAPI -> CheckDepthStencilMatch(
					m_uAdapter,
					D3DDEVTYPE_HAL,
					(D3DFORMAT)m_uFormat,
					(D3DFORMAT)m_uFormat,
					(D3DFORMAT)formats[i]
					))
					)
		{
			m_DepthStencilFormats[m_DepthStencilCount] = formats[i];
			m_DepthStencilCount++;
		}
	}

	return m_DepthStencilCount;
}

UINT CVideoDevice::GetStencilFormat(UINT uFormatIndex)
{
	return m_DepthStencilFormats[uFormatIndex];
}

BOOL CVideoDevice::GetDevice(VIDEODEVICE &device)
{
	if(m_pAPI == NULL)
	{
		FRACTAL_ERROR(FRACTAL_NOT_INITIALIZED, "FRACTAL_NOT_INITIALIZED");
		return FALSE;
	}

	device.API = m_pAPI;
	device.Device = m_pDevice;

	return TRUE;
}

BOOL CVideoDevice::Push()
{
	// TO DO: Make this more efficient
	DWORD Temp;
	Temp = m_StatePool.top();
	m_StatePool.pop();

	m_pDevice -> CaptureStateBlock(Temp);
	
	m_StateStack.push(Temp);

	return TRUE;
}

BOOL CVideoDevice::Pop()
{
	DWORD Temp = m_StateStack.top();
	m_StateStack.pop();

	m_pDevice -> ApplyStateBlock(Temp);

	m_StatePool.push(Temp);

	return TRUE;
}

BOOL CVideoDevice::ResetStack()
{
	if(FAILED(m_pDevice -> ApplyStateBlock(m_StateBlock)))
	{
		FRACTAL_ERROR(FRACTAL_NOT_INITIALIZED, "FRACTAL_NOT_INITIALIZED");
		return FALSE;
	}

	return TRUE;
}
