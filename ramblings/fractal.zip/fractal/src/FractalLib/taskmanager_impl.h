
#ifndef _TASKMANAGER_IMPL_H_
#define _TASKMANAGER_IMPL_H_

#include <list>
#include "taskmanager.h"

class CTaskManager : public ITaskManager
{
	// Initialization / destruction
	virtual BOOL			Create();
	virtual BOOL			Destroy();

	// Control functions
	virtual BOOL			AddTask(const FRACTALTASK &Task);
	virtual BOOL			SetCurrentTime(FLOAT Time);

	// Action functions
	virtual BOOL			Tick(FLOAT Timeslice);

private:
	std::list<FRACTALTASK>	m_Tasks;
	FLOAT					m_Time;
};

#endif // _TASKMANAGER_IMPL_H_
