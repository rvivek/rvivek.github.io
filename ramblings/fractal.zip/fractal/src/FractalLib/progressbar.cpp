
#include "progressbar_impl.h"
#include "fractal_errors.h"
#include "scom.h"

struct BARVERTEX
{
    FLOAT x, y, z, rhw; // The transformed position for the vertex.
    DWORD color;        // The vertex color.
};

#define FVF_BAR (D3DFVF_XYZRHW | D3DFVF_DIFFUSE)

CProgressBar::CProgressBar()
{
}

CProgressBar::~CProgressBar()
{
	m_pStack = NULL;
}

BOOL CProgressBar::Create(const VIDEODEVICE &Device, IAttributeStack *Stack)
{
	m_Device = Device;
	m_pStack = Stack;

	m_Min = 0;
	m_Max = 100;
	m_Value = 0;

	return TRUE;
}

BOOL CProgressBar::Destroy()
{
	m_pStack = NULL;

	return TRUE;
}

BOOL CProgressBar::SetSize(FLOAT Width, FLOAT Height)
{
	m_Width = Width;
	m_Height = Height;

	return TRUE;
}

BOOL CProgressBar::SetPosition(FLOAT X, FLOAT Y)
{
	m_x = X;
	m_y = Y;

	return TRUE;
}

BOOL CProgressBar::SetColor(DWORD Color)
{
	m_Color = Color;

	return TRUE;
}

BOOL CProgressBar::SetMinMax(FLOAT Min, FLOAT Max)
{
	m_Min = Min;
	m_Max = Max;

	return TRUE;
}

BOOL CProgressBar::SetValue(FLOAT Value)
{
	if(Value < m_Min || Value > m_Max)
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Invalid parameter in a progress bar.");
		return FALSE;
	}

	m_Value = Value;

	return TRUE;
}

BOOL CProgressBar::Render()
{
	FLOAT l = m_x - m_Width / 2;
	FLOAT r = m_x + m_Width / 2;
	FLOAT t = m_y - m_Height / 2;
	FLOAT b = m_y + m_Height / 2;
	FLOAT p = l + (m_Width * (m_Value / (m_Max - m_Min)));

	BARVERTEX g_Vertices[] =
	{
		// The vertical lines
		{ l - 2,	t - 2,	0.0f,	1.0f,	m_Color,}, // x, y, z, rhw, color
		{ l - 2,	b + 1,	0.0f,	1.0f,	m_Color,},
		{ r + 1,	t - 2,	0.0f,	1.0f,	m_Color,},
		{ r + 1,	b + 1,	0.0f,	1.0f,	m_Color,},

		// The horizontal lines
		{ l - 2,	t - 2,	0.0f,	1.0f,	m_Color,}, // x, y, z, rhw, color
		{ r + 1,	t - 2,	0.0f,	1.0f,	m_Color,},
		{ l - 2,	b + 1,	0.0f,	1.0f,	m_Color,},
		{ r + 1,	b + 1,	0.0f,	1.0f,	m_Color,},

		// The bar
		{ l,		t,	0.0f,	1.0f,	m_Color,}, // x, y, z, rhw, color
		{ p,		t,	0.0f,	1.0f,	m_Color,},
		{ l,		b,	0.0f,	1.0f,	m_Color,},
		{ p,		b,	0.0f,	1.0f,	m_Color,},
	};

	// Set vertex shader
	m_Device.Device -> SetVertexShader(FVF_BAR);

	// Draw the lines
	m_Device.Device -> DrawPrimitiveUP(
		D3DPT_LINELIST,
		4,
		g_Vertices,
		sizeof(BARVERTEX)
		);

	// Draw the bar
	m_Device.Device -> DrawPrimitiveUP(
		D3DPT_TRIANGLESTRIP,
		2,
		g_Vertices + 8,
		sizeof(BARVERTEX)
		);

	return TRUE;
}
