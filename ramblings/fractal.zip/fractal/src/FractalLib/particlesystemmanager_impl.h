
#ifndef _PARTICLESYSTEMMANAGER_IMPL_H_
#define _PARTICLESYSTEMMANAGER_IMPL_H_

#include <list>
#include "scom_types.h"
#include "scom_component.h"
#include "fractal_types.h"
#include "particlesystemmanager.h"
#include "billboard.h"

class CParticleSystemManager : public IParticleSystemManager
{
public:
	CParticleSystemManager();
	virtual ~CParticleSystemManager();

	// Initialization / destruction
	virtual BOOL			Create(const VIDEODEVICE &Device, IAttributeStack *Stack);
	virtual BOOL			Destroy();

	virtual BOOL			AddParticleSystem(IParticleSystem *System);

	// Action functions
	virtual BOOL			Tick(FLOAT Timeslice);
	virtual BOOL			Render();

private:
	VIDEODEVICE						m_Device;
	IBillboard						*m_Billboard;

	IAttributeStack					*m_AttributeStack;

	std::list<IParticleSystem*>		m_Systems;
	std::list<PARTICLE>				m_Particles;
};

#endif // _PARTICLESYSTEMMANAGER_IMPL_H_
