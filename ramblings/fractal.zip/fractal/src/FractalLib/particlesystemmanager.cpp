
#include <d3dx8.h>
#include "particlesystemmanager_impl.h"
#include "fractal_errors.h"
#include "billboard.h"
#include "scom.h"

CParticleSystemManager::CParticleSystemManager()
{
	m_Billboard = NULL;
}

CParticleSystemManager::~CParticleSystemManager()
{
}

BOOL CParticleSystemManager::Create(const VIDEODEVICE &Device, IAttributeStack *Stack)
{
	m_Device = Device;
	m_AttributeStack = Stack;
	m_Billboard = (IBillboard*)scCreateComponent("Billboard");
	m_Billboard -> Create(Device);

	return TRUE;
}

BOOL CParticleSystemManager::Destroy()
{
	scDeleteComponent(m_Billboard);
	m_Billboard = NULL;

	return TRUE;
}

BOOL CParticleSystemManager::AddParticleSystem(IParticleSystem *System)
{
	m_Systems.push_back(System);

	return TRUE;
}

BOOL CParticleSystemManager::Tick(FLOAT Timeslice)
{
	// go through all the systems...
	std::list<IParticleSystem*>::iterator si;
	for(si = m_Systems.begin(); si != m_Systems.end();)
	{
		IParticleSystem *pSystem = *si;
		int retval = pSystem -> Tick(Timeslice);
		if(retval < 0)
		{
			m_Systems.erase(si);

		}
		else
		{
			if(retval > 0)
			{
				// we need to call the emit function
				PARTICLE *pParticles = new PARTICLE[retval]; // TO DO: Change
				pSystem -> Emit(pParticles);
				for(int i = 0; i < retval; i++)
					m_Particles.push_back(pParticles[i]);
				delete[] pParticles;
			}

			si++;
		}
	}

	// update all particles
	std::list<PARTICLE>::iterator pi;
	for(pi = m_Particles.begin(); pi != m_Particles.end();)
	{
		PARTICLE *Particle = &(*pi);
		if(!Particle -> System -> UpdateParticle(Particle, Timeslice))
		{
			pi = m_Particles.erase(pi);
		}
		else
		{
			pi++;
		}
	}

	return TRUE;
}

BOOL CParticleSystemManager::Render()
{
	m_AttributeStack -> Push();

	// go through all the particles
	LPDIRECT3DTEXTURE8 pPrevTex = NULL;
	std::list<PARTICLE>::iterator pi;
	for(pi = m_Particles.begin(); pi != m_Particles.end(); pi++)
	{
		PARTICLE Particle = *pi;
		if(!Particle.System -> Render(Particle))
		{
			if(Particle.Texture.Texture != pPrevTex)
			{
				m_Device.Device -> SetTexture(0, Particle.Texture.Texture);
				pPrevTex = Particle.Texture.Texture;
			}

			m_Device.Device -> SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
			m_Device.Device -> SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
			m_Device.Device -> SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
			m_Device.Device -> SetRenderState(D3DRS_DESTBLEND, D3DBLEND_ONE);
			m_Device.Device -> SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE);
			m_Device.Device -> SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_TEXTURE);
			m_Device.Device -> SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);

			m_Billboard -> Render(
				D3DXVECTOR3(Particle.x, Particle.y, Particle.z),
				Particle.size,
				D3DCOLOR_ARGB(Particle.a, Particle.r, Particle.g, Particle.b),
				TRUE
				);
		}
	}

	m_AttributeStack -> Pop();

	return TRUE;
}
