
#ifndef _TERRAIN_IMPL_H_
#define _TERRAIN_IMPL_H_

#include <d3d8.h>
#include <d3dx8.h>
#include <list>
#include "scom_types.h"
#include "scom_component.h"
#include "fractal_types.h"
#include "terrain.h"
#include "texture.h"

// TO DO: move all defines back to CPPs
#define TERRAIN_DEFAULT_VERTICALSCALE				3500.0f
#define TERRAIN_DEFAULT_HORIZONTALSCALE				18000.0f
#define TERRAIN_DEFAULT_DETAILREPEAT				15

class CTerrain : public ITerrain
{
public:
	CTerrain();
	virtual ~CTerrain();

	// Initialization / destruction
	virtual BOOL			Create(const VIDEODEVICE &Device, IAttributeStack *Stack, LPCSTR Filename);
	virtual BOOL			Destroy();

	// These functions can only be called before initialization
	virtual BOOL			SetScale(FLOAT Vertical, FLOAT Horizontal);

	// These functions can only be called after initialization
	virtual BOOL			AddLayer(LPCSTR Filename, BYTE minh, BYTE maxh, FLOAT mins, FLOAT maxs);

	// Property accessors
	virtual FLOAT			GetVerticalScale();
	virtual FLOAT			GetHorizontalScale();

	// Other functions
	virtual FLOAT			GetHeightAt(FLOAT x, FLOAT z);

	// Action functions
	virtual BOOL			Render();

private:
	BOOL					LoadHeightmap(LPCSTR Filename);
	BOOL					SetupGeometry();

	BOOL					CalculateLighting(D3DCOLOR &Color, UINT i, UINT j);
	BOOL					GenerateNormals();

private:
	VIDEODEVICE				m_Device;
	IAttributeStack			*m_pStack;

	LPDIRECT3DINDEXBUFFER8	m_pIB;
	LPDIRECT3DVERTEXBUFFER8	m_pVB;

	LPDIRECT3DTEXTURE8		m_HeightmapTex;

	typedef struct _LAYERINFO
	{
		ITexture			*pAlphaTexture;
		LPDIRECT3DTEXTURE8	pTexture;
		FLOAT				minh, maxh;
		FLOAT				mins, maxs;	// 0 - 90
	} LAYERINFO;
	typedef std::list<LAYERINFO>	LAYERLIST;
	LAYERLIST				m_Layers;
	
	UINT					m_NumVertices;
	UINT					m_NumIndices;
	FLOAT					m_VerticalScale;
	FLOAT					m_HorizontalScale;
	
	D3DXVECTOR3				m_Light;
	float					m_Ambient;

	typedef struct _HEIGHTINFO
	{
		D3DXVECTOR3			pos;
		D3DXVECTOR3			normal;
		FLOAT				tu, tv;
		FLOAT				tu2, tv2;
	} HEIGHTINFO;
	HEIGHTINFO				*m_Heightmap;
	UINT					m_Divisions;

	FLOAT					m_NormalBase;

	HRESULT					m_hLastError;

private:
	BOOL					CalculateTexture(LAYERINFO &Info);
	BOOL					IsPixelVisible(const LAYERINFO *pInfo, UINT x, UINT y);
	BOOL					IsLayerVisible(const LAYERINFO *pInfo, UINT x, UINT y);
};

#endif // _TERRAIN_IMPL_H_
