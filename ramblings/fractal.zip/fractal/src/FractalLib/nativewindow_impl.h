
#ifndef _NATIVEWINDOW_IMPL_H_
#define _NATIVEWINDOW_IMPL_H_

#include <windows.h>
#include <d3d8.h>
#include <string>
#include "inc/nativewindow.h"

#define WINDOW_DEFAULT_WINDOWED			TRUE
#define WINDOW_DEFAULT_WIDTH			640
#define WINDOW_DEFAULT_HEIGHT			480
#define WINDOW_DEFAULT_MODCLIENTRECT	TRUE
#define WINDOW_DEFAULT_X				CW_USEDEFAULT
#define WINDOW_DEFAULT_Y				CW_USEDEFAULT

class CNativeWindow : public INativeWindow
{
public:
	CNativeWindow();
	virtual ~CNativeWindow();

	// Initialization / destruction
	virtual BOOL			Create();
	virtual BOOL			Destroy();

	// These functions can only be called prior to initialization to control initialization
	virtual BOOL			SetWindowed(BOOL Windowed);

	// These functions control the properties and can be called both before and after initialization
	virtual BOOL			SetSize(UINT Width, UINT Height, BOOL ModifyClientRect = TRUE);
	virtual BOOL			SetPosition(UINT x, UINT y);
	virtual BOOL			SetTitle(LPCSTR Title);
	virtual BOOL			SetMessageHandler(WINDOWMESSAGEHANDLER MessageHandler);
	
	// Property accessors
	virtual BOOL			IsWindowed();
	virtual BOOL			GetSize(UINT &Width, UINT &Height);
	virtual BOOL			GetPosition(UINT &x, UINT &y);
	virtual LPCSTR			GetTitle();

	// State accessors
	virtual BOOL			IsActive();

	// Access to internal structures
	virtual BOOL			GetNative(NATIVEWINDOW &Window);

	// Windows callback function
	static LRESULT CALLBACK	CNativeWindow::WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

private:
	// State variables
	BOOL					m_fWindowed;
	UINT					m_Width, m_Height;
	BOOL					m_fModClientRect;
	UINT					m_x, m_y;
	std::string				m_Title;
	static WINDOWMESSAGEHANDLER	m_MsgHandler;

	// More state
	static BOOL				m_Active;
	
	// Error
	HRESULT					m_hLastError;

	// OS Window Representation
	HWND					m_hWnd;
};

#endif // _NATIVEWINDOW_IMPL_H_
