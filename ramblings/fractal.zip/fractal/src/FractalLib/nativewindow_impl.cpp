
#include <windows.h>
#include "inc/fractal_errors.h"
#include "nativewindow_impl.h"
#include "scom.h"

char DEFAULT_TITLE[] =			"FractalLib";
char DEFAULT_CLASSNAME[] =		"FractalLibWindowClass";

CNativeWindow::CNativeWindow()
{
	m_fWindowed = WINDOW_DEFAULT_WINDOWED;
	m_Width = WINDOW_DEFAULT_WIDTH;
	m_Height = WINDOW_DEFAULT_HEIGHT;
	m_fModClientRect = WINDOW_DEFAULT_MODCLIENTRECT;
	m_x = WINDOW_DEFAULT_X;
	m_y = WINDOW_DEFAULT_Y;
	m_Title = DEFAULT_TITLE;

	m_Active = FALSE;

	m_hWnd = NULL;

	m_MsgHandler = NULL;
}

CNativeWindow::~CNativeWindow()
{
	Destroy();
}

BOOL CNativeWindow::Create()
{
	if(m_hWnd != NULL)
	{
		FRACTAL_ERROR(FRACTAL_ALREADY_INITIALIZED, "FRACTAL_ALREADY_INITIALIZED");
		return FALSE;
	}

	WNDCLASS wc;
	DWORD dwExStyle;
	DWORD dwStyle;
	
	RECT WindowRect;
	WindowRect.left = 0;
	WindowRect.right = m_Width;
	WindowRect.top = 0;
	WindowRect.bottom = m_Height;

	HINSTANCE hInstance = GetModuleHandle(NULL);

	wc.style			= CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
	wc.lpfnWndProc		= (WNDPROC) WndProc;
	wc.cbClsExtra		= 0;
	wc.cbWndExtra		= 0;
	wc.hInstance		= hInstance;
	wc.hIcon			= NULL;			// TO DO: CHANGE
	wc.hCursor			= LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground	= NULL;
	wc.lpszMenuName		= NULL;
	wc.lpszClassName	= DEFAULT_CLASSNAME;

	if(!RegisterClass(&wc))
	{
		// TO DO: REGISTER THIS CLASS ONLY ONCE
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not register window class.");
		return FALSE;
	}

	if(!m_fWindowed)
	{
		dwExStyle = WS_EX_APPWINDOW;
		dwStyle = WS_POPUP;
	}
	else
	{
		dwExStyle = WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;
		//dwStyle = WS_OVERLAPPEDWINDOW;
		dwStyle = WS_POPUPWINDOW | WS_MINIMIZEBOX | WS_CAPTION;
	}

	if(m_fModClientRect)
	{
		AdjustWindowRectEx(&WindowRect, dwStyle, FALSE, dwExStyle);
	}

	// Create The Window
	if(!(m_hWnd = CreateWindowEx(dwExStyle,
								DEFAULT_CLASSNAME,
								m_Title.c_str(),
								dwStyle |
								WS_CLIPSIBLINGS |
								WS_CLIPCHILDREN,
								m_x, m_y,
								WindowRect.right - WindowRect.left,
								WindowRect.bottom - WindowRect.top,
								NULL,
								NULL,
								hInstance,
								NULL)))
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not create the window.");
		return FALSE;
	}

	ShowWindow(m_hWnd, SW_SHOW);
	SetForegroundWindow(m_hWnd);
	SetFocus(m_hWnd);
	
	return TRUE;
}

BOOL CNativeWindow::Destroy()
{
	if(m_hWnd != NULL)
	{
		// destroy the window
		DestroyWindow(m_hWnd);
		m_hWnd = NULL;

		// unregister the class
		UnregisterClass(DEFAULT_CLASSNAME, GetModuleHandle(NULL));
	}
	else
	{
		FRACTAL_WARNING(FRACTAL_NOT_INITIALIZED, "FRACTAL_NOT_INITIALIZED");
		return FALSE;
	}

	return TRUE;
}

BOOL CNativeWindow::SetWindowed(BOOL Windowed)
{
	if(m_hWnd != NULL)
	{
		FRACTAL_ERROR(FRACTAL_ALREADY_INITIALIZED, "FRACTAL_ALREADY_INITIALIZED");
		return FALSE;
	}

	m_fWindowed = Windowed;

	return TRUE;
}

BOOL CNativeWindow::SetSize(UINT Width, UINT Height, BOOL ModifyClientRect)
{
	m_Width = Width;
	m_Height = Height;
	m_fModClientRect = ModifyClientRect;

	if(m_hWnd != NULL)
	{
		SetWindowPos(m_hWnd, 0, m_x, m_y, m_Width, m_Height, SWP_NOACTIVATE | SWP_NOCOPYBITS | SWP_NOMOVE | SWP_NOZORDER);
	}

	return TRUE;
}

BOOL CNativeWindow::SetPosition(UINT x, UINT y)
{
	m_x = x;
	m_y = y;

	if(m_hWnd != NULL)
	{
		SetWindowPos(m_hWnd, 0, m_x, m_y, m_Width, m_Height, SWP_NOACTIVATE | SWP_NOCOPYBITS | SWP_NOSIZE | SWP_NOZORDER);
	}

	return TRUE;
}

BOOL CNativeWindow::SetTitle(LPCSTR Title)
{
	m_Title = Title;

	if(m_hWnd != NULL)
	{
		SetWindowText(m_hWnd, m_Title.c_str());
	}

	return TRUE;
}

BOOL CNativeWindow::SetMessageHandler(WINDOWMESSAGEHANDLER MessageHandler)
{
	m_MsgHandler = MessageHandler;

	return TRUE;
}

BOOL CNativeWindow::IsWindowed()
{
	return m_fWindowed;
}

BOOL CNativeWindow::GetSize(UINT &Width, UINT &Height)
{
	Width = m_Width;
	Height = m_Height;

	return TRUE;
}

BOOL CNativeWindow::GetPosition(UINT &x, UINT &y)
{
	x = m_x;
	y = m_y;

	return TRUE;
}

LPCSTR CNativeWindow::GetTitle()
{
	return m_Title.c_str();
}

BOOL CNativeWindow::IsActive()
{
	if(m_hWnd == NULL)
	{
		FRACTAL_ERROR(FRACTAL_ALREADY_INITIALIZED, "FRACTAL_ALREADY_INITIALIZED");
		return FALSE;
	}

	return m_Active;
}

BOOL CNativeWindow::GetNative(NATIVEWINDOW &Window)
{
	Window.Wnd = m_hWnd;
	Window.Windowed = m_fWindowed;

	return TRUE;
}

BOOL CNativeWindow::m_Active = FALSE;

LRESULT CALLBACK CNativeWindow::WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if(m_MsgHandler != NULL)
		m_MsgHandler(hWnd, uMsg, wParam, lParam);

	switch(uMsg)
	{
		case WM_ACTIVATE:
		{
			if(!HIWORD(wParam))
				m_Active = true;
			else
				m_Active = false;

			return 0;
		} break;

		case WM_SETFOCUS:
		{
			m_Active = true;

			return 0;
		} break;

		case WM_KILLFOCUS:
		{
			m_Active = false;

			return 0;
		} break;

		case WM_SYSCOMMAND:
		{
			switch(wParam)
			{
				case SC_SCREENSAVE:
				case SC_MONITORPOWER:
					return 0;
			} break;
		} break;

		case WM_CLOSE:
		{
			PostQuitMessage(0);

			return 0;
		} break;
	}

	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

WINDOWMESSAGEHANDLER CNativeWindow::m_MsgHandler = NULL;