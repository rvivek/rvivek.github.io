
#ifndef _BILLBOARD_IMPL_H_
#define _BILLBOARD_IMPL_H_

#include "scom_types.h"
#include "scom_component.h"
#include "fractal_types.h"
#include "billboard.h"
#include <d3dx8.h>

class CBillboard : public IBillboard
{
public:
	CBillboard();
	virtual ~CBillboard();

	virtual BOOL			Create(const VIDEODEVICE &Device);
	virtual BOOL			Destroy();

	virtual BOOL			Render(FLOAT Vertex[], FLOAT Size, DWORD Color, BOOL Scale = FALSE);

private:
	BOOL					BillboardLookAt(const D3DXVECTOR3 &Pos, const D3DXMATRIX &Camera, FLOAT Size, D3DXVECTOR3 &Vector);

private:
	VIDEODEVICE				m_Device;
};

#endif // _BILLBOARD_IMPL_H_
