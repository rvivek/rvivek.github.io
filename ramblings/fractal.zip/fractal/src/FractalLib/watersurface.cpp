
#include <d3dx8.h>
#include "watersurface_impl.h"
#include "noise.h"
#include "fractal_errors.h"
#include "physics.h"
#include "uniform_noise.h"
#include "scom.h"

struct WATERVERTEX
{
    FLOAT x, y, z;		// The transformed position for the vertex.
	FLOAT nx, ny, nz;	// Normal
    DWORD color;        // The vertex color.
	FLOAT u, v, s;
};
#define FVF_WATER (D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_DIFFUSE | D3DFVF_TEX1 | D3DFVF_TEXCOORDSIZE3(0))

inline DWORD F2DW( FLOAT f ) { return *((DWORD*)&f); }

CWaterSurface::CWaterSurface()
{
	m_pHeightmap = NULL;
	m_pEnvMap = NULL;

	m_pIB = NULL;
	m_pVB = NULL;

	m_Tesselation = 40;
	m_VerticalScale = 1000.0f;

	m_TextureSize = 40;
	m_SideSize = 150000;
	m_Position = D3DXVECTOR3(0, -200, 0);
	m_TextureRepeats = 5;

	m_TimeDimension = 0;
	m_Counter = 0;

	m_ColorThreshold = 0.15f;
	m_FresnelThreshold = 0.125f;
}

CWaterSurface::~CWaterSurface()
{
	Destroy();
}

BOOL CWaterSurface::Create(const VIDEODEVICE &Device, IAttributeStack *Stack)
{
	m_Device = Device;
	m_Stack = Stack;

	m_TextureSize = m_Tesselation + 1;

	// Create the scratch heightmap and normal map textures
	if(FAILED(D3DXCreateTexture(
		m_Device.Device,
		m_TextureSize, m_TextureSize,
		1, 0,
		D3DFMT_A8,
		D3DPOOL_SCRATCH,
		&m_pHeightmap
		)))
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not create texture.");
		return FALSE;
	}
	if(FAILED(D3DXCreateTexture(
		m_Device.Device,
		m_TextureSize, m_TextureSize,
		1, 0,
		D3DFMT_R8G8B8,
		D3DPOOL_SCRATCH,
		&m_pNormalMap
		)))
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not create texture.");
		return FALSE;
	}

	GenerateGeometry();
	UpdateTexture(0);
	UpdateGeometry(0);

	return TRUE;
}

BOOL CWaterSurface::Destroy()
{
	if(m_pHeightmap != NULL)
	{
		m_pHeightmap -> Release();
		m_pHeightmap = NULL;
	}

	if(m_pNormalMap != NULL)
	{
		m_pNormalMap -> Release();
		m_pNormalMap = NULL;
	}

	if(m_pEnvMap != NULL)
	{
		m_pEnvMap -> Release();
		m_pEnvMap = NULL;
	}

	if(m_pIB != NULL)
	{
		m_pIB -> Release();
		m_pIB = NULL;
	}

	if(m_pVB != NULL)
	{
		m_pVB -> Release();
		m_pVB = NULL;
	}

	return TRUE;
}

BOOL CWaterSurface::SetTextureSize(UINT Size)
{
	m_TextureSize = Size;

	return TRUE;
}

BOOL CWaterSurface::SetEnvironmentMap(LPCSTR Filename)
{
	// Load the map
	if(FAILED(D3DXCreateCubeTextureFromFileEx(
		m_Device.Device,
		Filename,
		D3DX_DEFAULT,
		D3DX_DEFAULT,			// mipmap levels
		0, D3DFMT_UNKNOWN,
		D3DPOOL_MANAGED,
		D3DX_DEFAULT,
		D3DX_FILTER_BOX,		// mipmap filter
		0,
		NULL, NULL,
		&m_pEnvMap
		)))
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not create texture.");
		return FALSE;
	}

	return TRUE;
}

BOOL CWaterSurface::SetSideSize(FLOAT Size)
{
	m_SideSize = Size;

	return TRUE;
}

BOOL CWaterSurface::Tick(FLOAT Timeslice)
{
	m_TimeDimension += 0.25f * Timeslice;

	UpdateTexture(Timeslice);
	UpdateGeometry(Timeslice);

	return TRUE;
}

BOOL CWaterSurface::Render()
{
	m_Stack -> Push();

	// Render States
	D3DXVECTOR3 sp(0, 0, 1);
	D3DXVec3Normalize(&sp, &sp);

	// Set the render stages
	//m_Device.Device -> SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME );
	m_Device.Device -> SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
	m_Device.Device -> SetRenderState(D3DRS_NORMALIZENORMALS, TRUE);

	// Texture stage 0
	m_Device.Device -> SetTextureStageState(0, D3DTSS_TEXCOORDINDEX, D3DTSS_TCI_CAMERASPACEREFLECTIONVECTOR | 1);
	m_Device.Device -> SetTextureStageState(0, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_COUNT3);
	
	m_Device.Device -> SetTextureStageState(0, D3DTSS_ADDRESSU, D3DTADDRESS_MIRROR);
	m_Device.Device -> SetTextureStageState(0, D3DTSS_ADDRESSV, D3DTADDRESS_MIRROR);
	m_Device.Device -> SetTextureStageState(0, D3DTSS_MINFILTER, D3DTEXF_LINEAR);
	m_Device.Device -> SetTextureStageState(0, D3DTSS_MAGFILTER, D3DTEXF_LINEAR);
	m_Device.Device -> SetTextureStageState(0, D3DTSS_MIPFILTER, D3DTEXF_LINEAR);
	
	m_Device.Device -> SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_BLENDDIFFUSEALPHA);
	m_Device.Device -> SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	m_Device.Device -> SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	
	m_Device.Device -> SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);
	m_Device.Device -> SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE);
	//m_Device.Device -> SetTextureStageState(1, D3DTSS_ALPHAARG2, D3DTOP_BLENDDIFFUSEALPHA);

	// Set the texture
	m_Device.Device -> SetTexture(0, m_pEnvMap);

	// Draw the primitive
	m_Device.Device -> SetStreamSource(0, m_pVB, sizeof(WATERVERTEX));
	m_Device.Device -> SetVertexShader(FVF_WATER);
	m_Device.Device -> SetIndices(m_pIB, 0);
	m_Device.Device -> DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, m_NumVertices, 0, m_NumIndices / 3);

	m_Stack -> Pop();

	return TRUE;
}

BOOL CWaterSurface::UpdateTexture(FLOAT Timeslice)
{
	// Fill the texture with noise
	D3DLOCKED_RECT desc;
	if(FAILED(m_pHeightmap -> LockRect(0, &desc, NULL, 0)))
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not lock the texture.");
		return FALSE;
	}
	BYTE *pData = (BYTE*)desc.pBits;
	for(UINT y = 0; y < m_TextureSize; y++)
	{
		for(UINT x = 0; x < m_TextureSize; x++)
		{
			//float f[3];
			D3DXVECTOR3 f;
			f.x = (float)x / (m_TextureSize - 1.0f) * 10.0f;
			f.y = (float)y / (m_TextureSize - 1.0f) * 10.0f;
			f.z = m_TimeDimension;

			float v = (noise(f, 6) + 1.0f) / 2.0f;

			pData[x] = (BYTE)(255.0f * v);
		}
		pData += desc.Pitch;
	}

	m_pHeightmap -> UnlockRect(0);

	FLOAT Scale = m_VerticalScale * (2.0f / (m_SideSize / m_TextureSize));

	// Generate the normals
	D3DXComputeNormalMap(
		m_pNormalMap,
		m_pHeightmap,
		NULL,
		0,
		D3DX_CHANNEL_ALPHA,
		Scale
		);

	return TRUE;
}

BOOL CWaterSurface::GenerateGeometry()
{
	// Calculate the number of vertices and indices
	m_NumIndices = (m_Tesselation * m_Tesselation) * 2 * 3;
	m_NumVertices = (m_Tesselation + 1) * (m_Tesselation + 1);

	// Create the index buffer
	if(FAILED(m_Device.Device -> CreateIndexBuffer(
		m_NumIndices * sizeof(WORD),
		0,
		D3DFMT_INDEX16,
		D3DPOOL_MANAGED,
		&m_pIB
		)))
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not create index buffer.");
		return FALSE;
	}

	// Create the vertex buffer
	if(FAILED(m_Device.Device -> CreateVertexBuffer(
		m_NumVertices * sizeof(WATERVERTEX),
		D3DUSAGE_DYNAMIC | D3DUSAGE_WRITEONLY,
		FVF_WATER,
		D3DPOOL_DEFAULT,
		&m_pVB
		)))
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not create vertex buffer.");
		return FALSE;
	}

	// Generate indices
	WORD *pIndices;
	if(FAILED(m_pIB -> Lock(0, 0, (BYTE**)&pIndices, 0)))
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not lock the index buffer");
		return FALSE;
	}

	int index = 0;
	for(int i = 0; i < (int)m_Tesselation; i++)
	{
		for(int j = 0; j < (int)m_Tesselation; j++)
		{
			int startvert = (i * (m_Tesselation + 1) + j);
			// triangle 1
			pIndices[index++] = startvert;
			pIndices[index++] = startvert + 1;
			pIndices[index++] = startvert + m_Tesselation + 1;
			// triangle 2
			pIndices[index++] = startvert + 1;
			pIndices[index++] = startvert + m_Tesselation + 2;
			pIndices[index++] = startvert + m_Tesselation + 1;
		}
	}

	m_pIB -> Unlock();

	return TRUE;
}

BOOL CWaterSurface::UpdateGeometry(FLOAT Timeslice)
{
	// Lock the vertex buffer
	WATERVERTEX *pVertices;
	if(FAILED(m_pVB -> Lock(0, 0, (BYTE**)&pVertices, D3DLOCK_DISCARD)))
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not lock the vertex buffer");
		return FALSE;
	}
	WATERVERTEX temp;

	// Lock the texture with normals
	D3DLOCKED_RECT desc;
	if(FAILED(m_pNormalMap -> LockRect(0, &desc, NULL, 0)))
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not lock the texture");
		return FALSE;
	}
	BYTE *pData = (BYTE*)desc.pBits;

	// Lock the texture with heightmap
	D3DLOCKED_RECT heightdesc;
	if(FAILED(m_pHeightmap -> LockRect(0, &heightdesc, NULL, 0)))
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not lock the texture");
		return FALSE;
	}
	BYTE *pHeightData = (BYTE*)heightdesc.pBits;

	FLOAT Scale = m_SideSize / (m_Tesselation - 1);
	for(int i = 0; i <= (int)m_Tesselation; i++)
	{
		for(int j = 0; j <= (int)m_Tesselation; j++)
		{
			// set the vertex coordinates
			temp.x = i * Scale - (m_Tesselation / 2) * Scale;
			temp.z = j * Scale - (m_Tesselation / 2) * Scale;
			temp.y = m_Position.y + ((pHeightData[j] / 256.0f - 0.5f) * 2.0f) * m_VerticalScale;
			D3DXVECTOR3 Vertex(temp.x, temp.y, temp.z);

			// Vertex normal
			D3DXVECTOR3 Normal;
			Normal.z = (pData[j * 3 + 2] / 256.0f - 0.5f) / 2.0f;
			Normal.y = (pData[j * 3 + 0] / 256.0f - 0.5f) / 2.0f;			// y and z should be flipped
			Normal.x = (pData[j * 3 + 1] / 256.0f - 0.5f) / 2.0f;			// y and z should be flipped
			D3DXVec3Normalize(&Normal, &Normal);

			temp.nx = Normal.x;
			temp.ny = Normal.y;
			temp.nz = Normal.z;
			
			// Eye vector
			D3DXVECTOR3 Eye;
			m_Device.Camera -> GetPosition(Eye);
			D3DXVECTOR3 EyeVector = Eye - Vertex;
			D3DXVec3Normalize(&EyeVector, &EyeVector);

			// Calculate the Fresnel term
			FLOAT dot = D3DXVec3Dot(&Normal, &EyeVector);
			BYTE Alpha = (BYTE)(255.0f * Fresnel(Clamp(m_FresnelThreshold, 1.0f, dot + m_FresnelThreshold)));

			// Calculate the wave color
			D3DXCOLOR Color1(40.0f / 255.0f, 80.0f / 255.0f, 100.0f / 255.0f, 1.0f);
			D3DXCOLOR Color2(40.0f / 255.0f, 60.0f / 255.0f, 10.0f / 255.0f, 1.0f);
			D3DXCOLOR Result;
			D3DXColorLerp(&Result, &Color1, &Color2, Clamp(m_ColorThreshold, 1.0f, dot + m_ColorThreshold));
			temp.color = D3DCOLOR_ARGB(Alpha, (BYTE)(Result.r * 255.0f), (BYTE)(Result.g * 255.0f), (BYTE)(Result.b * 255.0f));

			// Texture coordinates
			temp.u = (i * (1.0f / m_Tesselation));
			temp.v = (j * (1.0f / m_Tesselation));
			temp.s = (j * (1.0f / m_Tesselation));

			pVertices[i * (m_Tesselation + 1) + j] = temp;
		}
		pData += desc.Pitch;
		pHeightData += heightdesc.Pitch;
	}
	
	m_pHeightmap -> UnlockRect(0);
	m_pNormalMap -> UnlockRect(0);
	m_pVB -> Unlock();

	return TRUE;
}
