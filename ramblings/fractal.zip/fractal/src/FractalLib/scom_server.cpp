
#include "scom_server.h"
#include "videodevice_impl.h"
#include "nativewindow_impl.h"
#include "skydome_impl.h"
#include "terrain_impl.h"
#include "fpscounter_impl.h"
#include "billboard_impl.h"
#include "particlesystemmanager_impl.h"
#include "watersurface_impl.h"
#include "progressbar_impl.h"
#include "texture_impl.h"
#include "taskmanager_impl.h"
#include "fader_impl.h"
#include "camerapath_impl.h"
#include "text_impl.h"

extern "C" IComponent* InstantiateComponent(LPCSTR pName, LONG lInstData)
{
	if(strcmp(pName, "VideoDevice") == 0)
	{
		// TO DO: Make a singleton!!!
		return new CVideoDevice();
	}
	if(strcmp(pName, "NativeWindow") == 0)
	{
		return new CNativeWindow();
	}
	if(strcmp(pName, "Skydome") == 0)
	{
		return new CSkydome();
	}
	if(strcmp(pName, "Terrain") == 0)
	{
		return new CTerrain();
	}
	if(strcmp(pName, "FPSCounter") == 0)
	{
		return new CFPSCounter();
	}
	if(strcmp(pName, "Billboard") == 0)
	{
		return new CBillboard();
	}
	if(strcmp(pName, "ParticleSystemManager") == 0)
	{
		return new CParticleSystemManager();
	}
	if(strcmp(pName, "WaterSurface") == 0)
	{
		return new CWaterSurface();
	}
	if(strcmp(pName, "ProgressBar") == 0)
	{
		return new CProgressBar();
	}
	if(strcmp(pName, "Texture") == 0)
	{
		return new CTexture();
	}
	if(strcmp(pName, "TaskManager") == 0)
	{
		return new CTaskManager();
	}
	if(strcmp(pName, "Fader") == 0)
	{
		return new CFader();
	}
	if(strcmp(pName, "CameraPath") == 0)
	{
		return new CCameraPath();
	}
	if(strcmp(pName, "Text") == 0)
	{
		return new CText();
	}

	return NULL;
}

extern "C" BOOL DeleteComponent(IComponent *pComponent)
{
	delete pComponent;

	return TRUE;
}
