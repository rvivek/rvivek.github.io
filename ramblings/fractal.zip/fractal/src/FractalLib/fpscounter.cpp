
#include "fpscounter_impl.h"
#include "fractal_errors.h"

CFPSCounter::CFPSCounter()
{
	m_CurrentTime = GetTickCount();
	m_PrevTime = m_CurrentTime - DEFAULT_FPS_TIME;
	
	m_TotalTime = 0;

	for(int i = 0; i < FPS_LENGTH; i++)
		m_Timing[i] = 0;
}

CFPSCounter::~CFPSCounter()
{
}

VOID CFPSCounter::Tick()
{
	m_PrevTime = m_CurrentTime;
	m_CurrentTime = GetTickCount();
	
	if(m_LostFocus)
	{
		m_PrevTime = m_CurrentTime - DEFAULT_FPS_TIME;
		m_LostFocus = false;
	}

	long timeslice = (long)(GetTimeslice() * 1000.0f);

	m_TotalTime = 0;
	for(int i = 1; i < FPS_LENGTH; i++)
	{
		m_Timing[i - 1] = m_Timing[i];
		m_TotalTime += m_Timing[i - 1];
	}
	
	m_Timing[FPS_LENGTH - 1] = timeslice;
	m_TotalTime += timeslice;

	m_CurrentTime = GetTickCount();
}

FLOAT CFPSCounter::GetTimeslice()
{
	return (m_CurrentTime - m_PrevTime) / 1000.0f;
}

FLOAT CFPSCounter::GetFramerate()
{
	return FPS_LENGTH / (m_TotalTime / 1000.0f);
}

VOID CFPSCounter::Activate()
{
	m_LostFocus = true;
}

VOID CFPSCounter::Deactivate()
{
}
