
#include <fstream>
#include "camerapath_impl.h"
#include "camera.h"
#include "uniform_noise.h"
#include "collision_utils.h"
#include "scom.h"

CCameraPath::CCameraPath()
{
	m_Length = 0;
}

CCameraPath::~CCameraPath()
{
}

BOOL CCameraPath::Create()
{
	InitLengths();
	return TRUE;
}

BOOL CCameraPath::Create(LPCSTR Filename)
{
	std::ifstream CamFile(Filename);
	if(CamFile.fail())
		FRACTAL_ERROR(0, "Could not open the camera path file.");

	CCamera Camera;
	D3DXMATRIX mat;
	D3DXVECTOR3 pos;
	while(!CamFile.eof())
	{
		Camera << CamFile;
		Camera.GetCameraMatrix(mat);
		Camera.GetPosition(pos);
		AddControlPoint(mat, pos);
	}

	CamFile.close();

	if(m_Points.size() < 4)
		FRACTAL_ERROR(0, "Invalid camera path.");

	InitLengths();

	return TRUE;
}

BOOL CCameraPath::Destroy()
{
	return TRUE;
}

BOOL CCameraPath::AddControlPoint(const D3DXMATRIX &mat, const D3DXVECTOR3 &Pos)
{
	POINTINFO info;
	D3DXQuaternionRotationMatrix(&info.Quat, &mat);
	info.Pos = Pos;
	
	m_Points.push_back(info);

	return TRUE;
}

BOOL CCameraPath::GetMatrix(D3DXMATRIX &Matrix)
{
	D3DXMatrixRotationQuaternion(&Matrix, &m_CurrentPoint.Quat);

	return TRUE;
}

BOOL CCameraPath::GetPosition(D3DXVECTOR3 &Pos)
{
	Pos = m_CurrentPoint.Pos;

	return TRUE;
}

BOOL CCameraPath::Slerp(FLOAT s)
{
	s = Clamp(0, 1, s);

	// go through the segments and figure out where s belongs
	FLOAT b1 = 0,
		b2 = m_Segments[0];
	for(UINT i = 0; i < m_Segments.size(); i++)
	{
		if(s >= b1 && s <= b2)
		{
			// Great
			break;
		}
		else
		{
			b1 = b2;
			b2 = b2 + m_Segments[i + 1];
		}
	}

	/*
	By now i contains the segment we need
	*/
	FLOAT ts = s - b1;
	FLOAT tb2 = b2 - b1;
	if(tb2 == 0)
		tb2 = 1;
	ts = ts / tb2;
	if(ts < 0 || ts > 1)
	{
		FRACTAL_CRITICAL(0, "Division by zero in a camera path.");
		return FALSE;
	}

	D3DXQuaternionSlerp(&m_CurrentPoint.Quat, &m_Points[i + 1].Quat, &m_Points[i + 2].Quat, ts);
	D3DXQuaternionNormalize(&m_CurrentPoint.Quat, &m_CurrentPoint.Quat);

	D3DXVec3CatmullRom(
		&m_CurrentPoint.Pos,
		&m_Points[i + 0].Pos,
		&m_Points[i + 1].Pos,
		&m_Points[i + 2].Pos,
		&m_Points[i + 3].Pos,
		ts
		);

	return TRUE;
}

BOOL CCameraPath::InitLengths()
{
	m_Length = 0;

	POINTINFO Points[4];
	m_Segments.resize(m_Points.size() - 3);
	for(UINT i = 0; i < m_Points.size() - 3; i++)
	{
		// Set up the points
		Points[0] = m_Points[i + 0];
		Points[1] = m_Points[i + 1];
		Points[2] = m_Points[i + 2];
		Points[3] = m_Points[i + 3];

		// Calculate the length of the segment
		m_Segments[i] = CalculateLength(Points, 0, 1, 8);
		m_Length += m_Segments[i];
	}

	// Normalize the lengths of the segments
	for(i = 0; i < m_Points.size() - 3; i++)
	{
		m_Segments[i] /= m_Length;
	}

	return TRUE;
}

FLOAT CCameraPath::CalculateLength(POINTINFO Points[4], FLOAT start, FLOAT end, UINT level)
{
	// Get the two vectors
	D3DXVECTOR3 Vec1, Vec2;
	D3DXVec3CatmullRom(
		&Vec1,
		&Points[0].Pos,
		&Points[1].Pos,
		&Points[2].Pos,
		&Points[3].Pos,
		start
		);
	D3DXVec3CatmullRom(
		&Vec2,
		&Points[0].Pos,
		&Points[1].Pos,
		&Points[2].Pos,
		&Points[3].Pos,
		end
		);

	FLOAT length;
	if(level == 1)
	{
		length = Vec3Dist(Vec1, Vec2);
		return length;
	}

	length =
		CalculateLength(Points, start, (start + end) / 2, level - 1) +
		CalculateLength(Points, (start + end) / 2, end, level - 1);
	return length;
}
