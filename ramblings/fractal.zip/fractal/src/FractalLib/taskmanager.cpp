
#include "taskmanager_impl.h"

BOOL CTaskManager::Create()
{
	m_Time = 0.0f;

	return TRUE;
}

BOOL CTaskManager::Destroy()
{
	return TRUE;
}

BOOL CTaskManager::AddTask(const FRACTALTASK &Task)
{
	m_Tasks.push_back(Task);

	return TRUE;
}

BOOL CTaskManager::SetCurrentTime(FLOAT Time)
{
	m_Time = Time;

	return TRUE;
}

BOOL CTaskManager::Tick(FLOAT Timeslice)
{
	// Go through all the tasks (TO DO: look into a more efficient system)
	std::list<FRACTALTASK>::iterator i = m_Tasks.begin();
	FRACTALTASK Task;
	for(; i != m_Tasks.end(); i++)
	{
		Task = *i;
		if(((m_Time >= Task.StartTime) && (m_Time <= Task.EndTime)) || (Task.StartTime == -1) || (Task.StartTime == Task.EndTime && m_Time >= Task.StartTime))
		{
			Task.Param.CurrentTime += Timeslice;
			*i = Task;
			Task.Task -> ExecuteTask(Timeslice, Task.Param);
		}

		if(m_Time > Task.EndTime)
			i = m_Tasks.erase(i);
		// If starttime == endtime we assume the task is a one time thing
		if(Task.StartTime == Task.EndTime)
			i = m_Tasks.erase(i);
	}

	m_Time += Timeslice;

	return TRUE;
}
