
#include "fader_impl.h"
#include "uniform_noise.h"

struct FADEVERTEX
{
    FLOAT x, y, z, rhw; // The transformed position for the vertex.
    DWORD color;        // The vertex color.
};

#define FVF_FADE (D3DFVF_XYZRHW | D3DFVF_DIFFUSE)


CFader::CFader()
{
	m_Counter = 0.0f;
	m_Interval = 2.0f;
	m_FadeIn = TRUE;

	m_Width = 640;
	m_Height = 480;
}

CFader::~CFader()
{
}

BOOL CFader::Create(const VIDEODEVICE &Device, IAttributeStack *Stack)
{
	m_Device = Device;
	m_pStack = Stack;

	if(m_FadeIn == TRUE)
		m_Counter = m_Interval;
	else
		m_Counter = 0;

	return TRUE;
}

BOOL CFader::Destroy()
{
	return TRUE;
}

BOOL CFader::SetInterval(FLOAT Interval, BOOL FadeIn)
{
	m_Interval = Interval;
	m_FadeIn = FadeIn;

	return TRUE;
}

BOOL CFader::SetDimensions(UINT x, UINT y, UINT Width, UINT Height)
{
	m_Width = Width;
	m_Height = Height;
	m_x = x;
	m_y = y;

	return TRUE;
}

BOOL CFader::Tick(FLOAT Timeslice)
{
	if(m_FadeIn == TRUE)
		m_Counter -= Timeslice;
	else
		m_Counter += Timeslice;
	m_Counter = Clamp(0, m_Interval, m_Counter);

	return TRUE;
}

BOOL CFader::Render()
{
	m_Counter = Clamp(0, m_Interval, m_Counter);

	m_pStack -> Push();

	m_Device.Device -> SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_Device.Device -> SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_Device.Device -> SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	// Render the quad
	BYTE Alpha = (BYTE)(m_Counter / m_Interval * 255.0f);
	DWORD Color = D3DCOLOR_ARGB(Alpha, 0, 0, 0);
	//DWORD Color = D3DCOLOR_ARGB(255, Alpha, Alpha, Alpha);

	FADEVERTEX g_Vertices[] =
	{
		{ m_x,		m_y,		0.0f,	1.0f,	Color,}, // x, y, z, rhw, color,
		{ m_Width,	m_y,		0.0f,	1.0f,	Color,},
		{ m_x,		m_y + m_Height,	0.0f,	1.0f,	Color,},
		{ m_Width,	m_y + m_Height,	0.0f,	1.0f,	Color,},
	};

	// Set vertex shader
	m_Device.Device -> SetVertexShader(FVF_FADE);

	// Draw the primitive
	m_Device.Device -> DrawPrimitiveUP(
		D3DPT_TRIANGLESTRIP,
		2,
		g_Vertices,
		sizeof(FADEVERTEX)
		);

	m_pStack -> Pop();

	return TRUE;
}
