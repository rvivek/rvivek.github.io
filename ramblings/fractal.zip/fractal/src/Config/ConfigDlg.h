// ConfigDlg.h : header file
//

#if !defined(AFX_CONFIGDLG_H__3B7BABF3_2087_4266_84CB_66A6AAE0BF7C__INCLUDED_)
#define AFX_CONFIGDLG_H__3B7BABF3_2087_4266_84CB_66A6AAE0BF7C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <algorithm>
#include <vector>
#include <d3d8.h>
#include "scom.h"
#include "videodevice.h"

/////////////////////////////////////////////////////////////////////////////
// CConfigDlg dialog

class CConfigDlg : public CDialog
{
// Construction
public:
	CConfigDlg(CWnd* pParent = NULL);	// standard constructor
	virtual ~CConfigDlg();

// Dialog Data
	//{{AFX_DATA(CConfigDlg)
	enum { IDD = IDD_CONFIG_DIALOG };
	CListBox	m_RefreshRateList;
	CListBox	m_BppList;
	CListBox	m_ModeList;
	CComboBox	m_AdapterList;
	BOOL	m_Windowed;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CConfigDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	IVideoDevice *m_pAPI;
	std::vector<MODEINFO> m_Modes;

	void UpdateAdapterList();
	void UpdateResolutionList(unsigned int nAdapter);
	void UpdateBppList(unsigned int nSel);
	void UpdateRefreshRateList(unsigned int nSel);

	// Generated message map functions
	//{{AFX_MSG(CConfigDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSelchangeAdapter();
	afx_msg void OnSelchangeMode();
	afx_msg void OnSelchangeBpp();
	afx_msg void OnWindowed();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONFIGDLG_H__3B7BABF3_2087_4266_84CB_66A6AAE0BF7C__INCLUDED_)
