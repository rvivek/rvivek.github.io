
// ConfigDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Config.h"
#include "ConfigDlg.h"
#include "fractal_errors.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define OPTIONS_FILE		"./setup.ini"

typedef struct compare_modes_
{
	bool operator()(const MODEINFO &m1, const MODEINFO &m2)
	{
		if(m1.Width < m2.Width)
			return true;
		if(m1.Width == m2.Width)
		{
			if(m1.Height < m2.Height)
				return true;
			if(m1.Height == m2.Height)
			{
				unsigned int Format1, Format2;
				if(m1.Format == D3DFMT_X1R5G5B5)
					Format1 = 16;
				if(m1.Format == D3DFMT_R5G6B5)
					Format1 = 16;
				if(m1.Format == D3DFMT_X8R8G8B8)
					Format1 = 24;
				if(m1.Format == D3DFMT_A8R8G8B8)
					Format1 = 32;
				if(m2.Format == D3DFMT_X1R5G5B5)
					Format2 = 16;
				if(m2.Format == D3DFMT_R5G6B5)
					Format2 = 16;
				if(m2.Format == D3DFMT_X8R8G8B8)
					Format2 = 24;
				if(m2.Format == D3DFMT_A8R8G8B8)
					Format2 = 32;

				if(Format1 < Format2)
					return true;
				if(Format1 == Format2)
				{
					if(m1.RefreshRate < m2.RefreshRate)
						return true;
				}
			}
		}

		return false;
	}
} compare_modes;

/////////////////////////////////////////////////////////////////////////////
// CConfigDlg dialog

CConfigDlg::CConfigDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CConfigDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CConfigDlg)
	m_Windowed = FALSE;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	// Init SCOM
	scInit(".\\compreg.ini");

	// Load the api
	m_pAPI = (IVideoDevice*)scCreateComponent("VideoDevice");
	if(m_pAPI == NULL)
		throw 0;
	VIDEODEVICE Device;
	if(m_pAPI -> GetDevice(Device) == FALSE)
		throw 1;
}

CConfigDlg::~CConfigDlg()
{
	if(m_pAPI != NULL)
	{
		scDeleteComponent(m_pAPI);
	}
	scFree();
	CDialog::~CDialog();
}

void CConfigDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CConfigDlg)
	DDX_Control(pDX, IDC_REFRESHRATE, m_RefreshRateList);
	DDX_Control(pDX, IDC_BPP, m_BppList);
	DDX_Control(pDX, IDC_MODE, m_ModeList);
	DDX_Control(pDX, IDC_ADAPTER, m_AdapterList);
	DDX_Check(pDX, IDC_WINDOWED, m_Windowed);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CConfigDlg, CDialog)
	//{{AFX_MSG_MAP(CConfigDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_CBN_SELCHANGE(IDC_ADAPTER, OnSelchangeAdapter)
	ON_LBN_SELCHANGE(IDC_MODE, OnSelchangeMode)
	ON_LBN_SELCHANGE(IDC_BPP, OnSelchangeBpp)
	ON_BN_CLICKED(IDC_WINDOWED, OnWindowed)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CConfigDlg message handlers

BOOL CConfigDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// Load the settings
	unsigned int nAdapter		= GetPrivateProfileInt("Video", "Adapter", 0, OPTIONS_FILE);
	unsigned int nWidth			= GetPrivateProfileInt("Video", "Width", 0, OPTIONS_FILE);
	unsigned int nHeight		= GetPrivateProfileInt("Video", "Height", 0, OPTIONS_FILE);
	unsigned int nFormat		= GetPrivateProfileInt("Video", "Format", 0, OPTIONS_FILE);
	unsigned int nRefreshRate	= GetPrivateProfileInt("Video", "RefreshRate", 0, OPTIONS_FILE);
	unsigned int nWindowed		= GetPrivateProfileInt("Video", "Windowed", 0, OPTIONS_FILE);
	
	// Set up the windowed switch
	m_Windowed = nWindowed;
	UpdateData(FALSE);
	OnWindowed();

	// Enumerate the video information and fill in our controls
	UpdateAdapterList();
	if((nAdapter >= 0) && (nAdapter < m_pAPI -> GetAdapterCount()))
	{
		m_AdapterList.SetCurSel(nAdapter);
		UpdateResolutionList(nAdapter);
	}

	// Go through the list and load the settings if they exist
	MODEINFO mode;
	bool found = false;
	for(unsigned int i = 0; i < m_Modes.size(); i++)
	{
		mode = m_Modes[i];
		if((mode.Width == nWidth) && (mode.Height == nHeight) && (mode.Format == nFormat) && (mode.RefreshRate == nRefreshRate))
		{
			found = true;
			break;
		}
	}

	if(found)
	{
		MODEINFO m;
		for(i = 0; i < m_ModeList.GetCount(); i++)
		{
			m = m_Modes[m_ModeList.GetItemData(i)];
			if((m.Width == mode.Width) && (m.Height == mode.Height))
			{
				m_ModeList.SetCurSel(i);
				UpdateBppList(i);
			}
		}
		for(i = 0; i < m_BppList.GetCount(); i++)
		{
			m = m_Modes[m_BppList.GetItemData(i)];
			if(m.Format == mode.Format)
			{
				m_BppList.SetCurSel(i);
				UpdateRefreshRateList(i);
			}
		}
		for(i = 0; i < m_RefreshRateList.GetCount(); i++)
		{
			m = m_Modes[m_RefreshRateList.GetItemData(i)];
			if(m.RefreshRate == mode.RefreshRate)
			{
				m_RefreshRateList.SetCurSel(i);
			}
		}
	}

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CConfigDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CConfigDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CConfigDlg::UpdateAdapterList()
{
	// Clear the adapter list
	m_AdapterList.ResetContent();

	// Fill the m_AdapterList
	ADAPTERINFO adapter;
	for(unsigned int i = 0; i < m_pAPI -> GetAdapterCount(); i++)
	{
		m_pAPI -> GetAdapterInfo(i, adapter);
		m_AdapterList.AddString(adapter.Description);
	}
	m_AdapterList.SetCurSel(0);

	UpdateResolutionList(0);
}

void CConfigDlg::UpdateResolutionList(unsigned int nAdapter)
{
	// Clear the mode list
	m_ModeList.ResetContent();

	// Go through all modes of the current adapter
	MODEINFO mode;
	m_Modes.clear();
	for(unsigned int i = 0; i < m_pAPI -> GetModeCount(nAdapter); i++)
	{
		m_pAPI -> GetModeInfo(nAdapter, i, mode);
		m_Modes.push_back(mode);
	}
	compare_modes c;
	std::sort(m_Modes.begin(), m_Modes.end() - 1, c);

	// go through the modes
	int item = 0;
	for(i = 0; i < m_Modes.size(); i++)
	{
		mode = m_Modes[i];

		CString str;
		char buf[8];
		_itoa(mode.Width, buf, 10);
		str += buf;
		str += "x";
		_itoa(mode.Height, buf, 10);
		str += buf;

		if(m_ModeList.FindStringExact(-1, str) == CB_ERR)
		{
			// the resolution is not on the list yet... add it
			m_ModeList.AddString(str);
			m_ModeList.SetItemData(item, i);
			item++;
		}
	}
	m_ModeList.SetCurSel(0);

	UpdateBppList(0);
}

void CConfigDlg::UpdateBppList(unsigned int nSel)
{
	// Clear the bpp list
	m_BppList.ResetContent();

	MODEINFO mode = m_Modes[m_ModeList.GetItemData(nSel)];
	MODEINFO m;
	int item = 0;
	for(unsigned int i = 0; i < m_Modes.size(); i++)
	{
		m = m_Modes[i];
		if((m.Width == mode.Width) && (m.Height == mode.Height))
		{
			CString str;
			if(m.Format == D3DFMT_X1R5G5B5)
				str = /*"X1R5G5B5";//*/"16";
			if(m.Format == D3DFMT_R5G6B5)
				str = /*"R5G6B5";//*/"16";
			if(m.Format == D3DFMT_X8R8G8B8)
				str = /*"X8R8G8B8";//*/"24";
			if(m.Format == D3DFMT_A8R8G8B8)
				str = /*"A8R8G8B8";//*/"32";
			if(m_BppList.FindStringExact(-1, str) == CB_ERR)
			{
				// the bpp is not on the list yet... add it
				m_BppList.AddString(str);
				m_BppList.SetItemData(item, i);
				item++;
			}
		}
	}
	m_BppList.SetCurSel(0);

	UpdateRefreshRateList(0);
}

void CConfigDlg::UpdateRefreshRateList(unsigned int nSel)
{
	// Clear the refresh rate list
	m_RefreshRateList.ResetContent();

	MODEINFO mode = m_Modes[m_BppList.GetItemData(nSel)];
	MODEINFO m;
	int item = 0;
	for(unsigned int i = 0; i < m_Modes.size(); i++)
	{
		m = m_Modes[i];
		// Is it right to calc format like this?(right now we're ignoring one 16 bit format if there is more then one)
		if((m.Width == mode.Width) && (m.Height == mode.Height) && (m.Format == mode.Format))
		{
			CString str;
			char buf[8];
			_itoa(m.RefreshRate, buf, 10);
			str = buf;
			if(m_RefreshRateList.FindStringExact(-1, str) == CB_ERR)
			{
				// the refresh rate is not on the list yet... add it
				m_RefreshRateList.AddString(str);
				m_RefreshRateList.SetItemData(item, i);
				item++;
			}
		}
	}
	m_RefreshRateList.SetCurSel(0);
}

void CConfigDlg::OnSelchangeAdapter() 
{
	UpdateResolutionList(m_AdapterList.GetCurSel());
}

void CConfigDlg::OnSelchangeMode() 
{
	UpdateBppList(m_ModeList.GetCurSel());
}

void CConfigDlg::OnSelchangeBpp() 
{
	UpdateRefreshRateList(m_BppList.GetCurSel());
}

void CConfigDlg::OnWindowed() 
{
	UpdateData(TRUE);
	if(m_Windowed)
	{
		m_BppList.EnableWindow(FALSE);
		m_RefreshRateList.EnableWindow(FALSE);
	}
	else
	{
		m_BppList.EnableWindow(TRUE);
		m_RefreshRateList.EnableWindow(TRUE);
	}
}

void CConfigDlg::OnOK()
{
	char buf[10];

	// write the adapter info
	_itoa(m_AdapterList.GetCurSel(), buf, 10);
	WritePrivateProfileString("Video", "Adapter", buf, OPTIONS_FILE);

	// write the mode info
	MODEINFO mode = m_Modes[m_RefreshRateList.GetItemData(m_RefreshRateList.GetCurSel())];

	_itoa(mode.Width, buf, 10);
	WritePrivateProfileString("Video", "Width", buf, OPTIONS_FILE);
	_itoa(mode.Height, buf, 10);
	WritePrivateProfileString("Video", "Height", buf, OPTIONS_FILE);
	_itoa(mode.Format, buf, 10);
	WritePrivateProfileString("Video", "Format", buf, OPTIONS_FILE);
	_itoa(mode.RefreshRate, buf, 10);
	WritePrivateProfileString("Video", "RefreshRate", buf, OPTIONS_FILE);

	// windowed?
	_itoa(m_Windowed, buf, 10);
	WritePrivateProfileString("Video", "Windowed", buf, OPTIONS_FILE);
	
	CDialog::OnOK();
}
