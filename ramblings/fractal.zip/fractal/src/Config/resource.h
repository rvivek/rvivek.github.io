//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Config.rc
//
#define IDD_CONFIG_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDC_MODE                        1000
#define IDC_WINDOWED                    1001
#define IDC_ADAPTER                     1002
#define IDC_BPP                         1003
#define IDC_REFRESHRATE                 1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
