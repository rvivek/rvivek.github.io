
/*
 This file is a simple component object model (scom) specification. It 
 contains all the APIs and documentation necessary to get started with 
 scom.
 */

#ifndef _SCOM_H_
#define _SCOM_H_

#include "scom_errors.h"
#include "scom_types.h"
#include "scom_component.h"
#include "errormanager.h"

/*
 Library initialization
*/ 
extern "C" BOOL				scInit(LPCSTR pConfigFilename);
extern "C" BOOL				scFree();

/*
 These functions instantiate and delete components.
*/
extern "C" IComponent*		scCreateComponent(LPCSTR pName, LONG lInstData = 0);
extern "C" BOOL				scDeleteComponent(IComponent *pComponent);

/*
 These are error handling functions. IErrorManager interface is a built in
 component designed to handle errors. It keeps the state of the last error
 that occured, and can call a specified callback function
*/
extern "C" IErrorManager*	scGetErrorManager();
extern "C" BOOL				scError(FRACTALSEVERITY Severity, UINT Code, LPCSTR Message, LPCSTR FileName, UINT Line);

// Macros to simplify error handling
#define FRACTAL_INFO(Code, Message)			scError(S_FRACTAL_INFO, Code, Message, __FILE__, __LINE__)
#define FRACTAL_WARNING(Code, Message)		scError(S_FRACTAL_WARNING, Code, Message, __FILE__, __LINE__)
#define FRACTAL_ERROR(Code, Message)		scError(S_FRACTAL_ERROR, Code, Message, __FILE__, __LINE__)
#define FRACTAL_CRITICAL(Code, Message)		scError(S_FRACTAL_CRITICAL, Code, Message, __FILE__, __LINE__)

#endif // _SCOM_H_
