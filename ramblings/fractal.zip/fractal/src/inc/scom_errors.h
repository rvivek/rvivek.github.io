
#ifndef _SCOM_ERRORS_H_
#define _SCOM_ERRORS_H_

#define SCOM_SUCCESS					0
#define SCOM_MODULE_NOT_FOUND			1
#define SCOM_INCOMPATIBLE_MODULE		2
#define SCOM_COMPONENT_NOT_FOUND		3

#endif // _SCOM_ERRORS_H_
