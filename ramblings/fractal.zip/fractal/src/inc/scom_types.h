
#ifndef _SCOM_TYPES_H_
#define _SCOM_TYPES_H_

#ifndef _WINDOWS_

#ifndef interface
#define interface		struct
#endif

#ifndef NULL
#define NULL			0
#endif

#ifndef FALSE
#define FALSE			0
#endif

#ifndef TRUE
#define TRUE			1
#endif

#ifndef CONST
#define CONST			const
#endif

typedef void			VOID;
typedef unsigned int	UINT;
typedef int				INT;
typedef INT				BOOL;
typedef long			LONG;
typedef LONG			HRESULT;
typedef float			FLOAT;
typedef void			VOID;
typedef VOID*			LPVOID;
typedef char			CHAR;
typedef CHAR			*LPSTR, *PSTR;
typedef CONST CHAR		*LPCSTR, *PCSTR;

#endif // _WINDOWS_

#endif // _SCOM_TYPES_H_
