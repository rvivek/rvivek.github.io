
#ifndef _SCOM_COMPONENT_H_
#define _SCOM_COMPONENT_H_

#include "scom_types.h"

/*
 This interface is the root of any scom hierarchy. Any scom component 
 must implement this interface.
 */
interface IComponent
{
	// Figure out how not to do this
	virtual ~IComponent() {};
};

#endif // _SCOM_COMPONENT_H_
