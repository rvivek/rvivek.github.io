
#ifndef _SCOM_SERVER_H_
#define _SCOM_SERVER_H_

#include "scom_errors.h"
#include "scom_types.h"
#include "scom_component.h"

/*
 These funcitons must be exported from a dll that implements components.
 */
extern "C" IComponent*		InstantiateComponent(LPCSTR pName, LONG lInstData);
extern "C" BOOL				DeleteComponent(IComponent *pComponent);

#endif // _SCOM_SERVER_H_
