
#ifndef _ERRORMANAGER_H_
#define _ERRORMANAGER_H_

#include "scom_types.h"
#include "scom_component.h"

// Error severity
typedef enum _FRACTALSEVERITY
{
	S_FRACTAL_INFO,			// Information about a potential abnormality
	S_FRACTAL_WARNING,		// A warning about an abnormality that is dealt with internally
	S_FRACTAL_ERROR,		// An error that cannot be fixed internally
	S_FRACTAL_CRITICAL		// A critical error in the code that should be reported/fixed
} FRACTALSEVERITY;

// A typical error object
typedef struct _FRACTALERROR
{
	FRACTALSEVERITY		Severity;
	UINT				Code;
	LPCSTR				Message;
	LPCSTR				FileName;
	UINT				Line;
} FRACTALERROR;

// This is the error handler interface
interface IErrorHandler
{
	virtual BOOL			OnError(const FRACTALERROR &Error) = 0;
};

// This is the main interface
interface IErrorManager : public IComponent
{
	virtual BOOL			OnError(const FRACTALERROR &Error) = 0;

	virtual BOOL			GetLastError(FRACTALERROR &Error) = 0;
	virtual BOOL			SetErrorHandler(IErrorHandler *Handler) = 0;
};

#endif // _ERRORMANAGER_H_
