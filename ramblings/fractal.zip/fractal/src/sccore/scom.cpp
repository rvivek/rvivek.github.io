
#pragma warning(disable: 4786)

#include <hash_map>
#include <string>
#include <windows.h>
#include "scom.h"

// Functions expected to be in the dll
typedef IComponent* (*INSTANTIATECOMPONENT)(LPCSTR, LONG); 
typedef BOOL (*DELETECOMPONENT)(IComponent*); 

// lib info struct
typedef struct _LIBINFO
{
	HMODULE					Module;
	INSTANTIATECOMPONENT	InstantiateComponent;
	DELETECOMPONENT			DeleteComponent;
} LIBINFO;

// comp info struct
typedef struct _COMPINFO
{
	LIBINFO					LibInfo;
	UINT					RefCount;
} COMPINFO;

// instantiated components
std::hash_map<LONG, COMPINFO> g_Components;
typedef std::hash_map<LONG, COMPINFO>::iterator COMPITER;

// the initialization file
std::string ConfigFilename;

// last known error
IErrorManager* g_pErrorManager = NULL;

extern "C" BOOL scInit(LPCSTR pConfigFilename)
{
	// Setup the configuration file
	ConfigFilename = pConfigFilename;

	// Load the error manager
	g_pErrorManager = (IErrorManager*)scCreateComponent("ErrorManager", 0);
	if(g_pErrorManager == NULL)
		return FALSE;

	return TRUE;
}

extern "C" BOOL scFree()
{
	if(g_pErrorManager != NULL)
	{
		scDeleteComponent(g_pErrorManager);
		g_pErrorManager = NULL;
	}

	return TRUE;
}

extern "C" IComponent* scCreateComponent(LPCSTR pName, LONG lInstData)
{
	// Find the dll name from the component name
	char buf[255];
	GetPrivateProfileString("SCOM", pName, "", buf, 255, ConfigFilename.c_str());
	std::string DllName = buf;

	// If the dll doesn't exist in the hash map, load it
	HMODULE Module = LoadLibrary(DllName.c_str());
	if(Module == NULL)
	{
		FRACTAL_ERROR(SCOM_MODULE_NOT_FOUND, "Could not load the requested component.");
		return NULL;
	}
		
	// Load the necessary functions
	INSTANTIATECOMPONENT	InstantiateComponent;
	DELETECOMPONENT			DeleteComponent;
	if((InstantiateComponent = (INSTANTIATECOMPONENT)GetProcAddress(Module, "InstantiateComponent")) == NULL || (DeleteComponent = (DELETECOMPONENT)GetProcAddress(Module, "DeleteComponent")) == NULL)
	{
		FreeLibrary(Module);

		FRACTAL_ERROR(SCOM_INCOMPATIBLE_MODULE, "The specified module does not comply with SCOM specifications.");
		return NULL;
	}

	// Instantiate the requested component
	IComponent *pComponent = InstantiateComponent(pName, lInstData);

	// Add the component to the list of components (or increment the reference count if it already exists)
	if(pComponent != NULL)
	{
		COMPITER iter;
		if((iter = g_Components.find((LONG)pComponent)) == g_Components.end())
		{
			// add a new entry
			LIBINFO LibInfo;
			LibInfo.Module = Module;
			LibInfo.InstantiateComponent = InstantiateComponent;
			LibInfo.DeleteComponent = DeleteComponent;
	
			COMPINFO cmpinfo;
			cmpinfo.LibInfo = LibInfo;
			cmpinfo.RefCount = 1;
			g_Components[(LONG)pComponent] = cmpinfo;
		}
		else
		{
			// increment the ref count
			COMPINFO *pInfo = &((*iter).second);
			pInfo -> RefCount++;
		}
	}
	else
	{
		FreeLibrary(Module);
		FRACTAL_ERROR(SCOM_INCOMPATIBLE_MODULE, "Could not instantiate the component.");
	}

	// return
	return pComponent;
}

extern "C" BOOL scDeleteComponent(IComponent *pComponent)
{
	COMPITER CompIter;

	// Find the requested component
	if((CompIter = g_Components.find((LONG)pComponent)) == g_Components.end())
	{
		FRACTAL_ERROR(SCOM_COMPONENT_NOT_FOUND, "The requested component does not exist.");
		return FALSE;
	}
	else
	{
		// Decrement the library reference count
		COMPINFO *pCompInfo = &((*CompIter).second);
		pCompInfo -> RefCount--;

		// Call the appropriate DeleteComponent function
		pCompInfo -> LibInfo.DeleteComponent(pComponent);
		FreeLibrary(pCompInfo -> LibInfo.Module);

		// If the reference count is 0, remove the entry
		if(pCompInfo -> RefCount == 0)
		{
			g_Components.erase(CompIter);
		}
	}

	return TRUE;
}

extern "C" IErrorManager* scGetErrorManager()
{
	return g_pErrorManager;
}

extern "C" BOOL scError(FRACTALSEVERITY Severity, UINT Code, LPCSTR Message, LPCSTR FileName, UINT Line)
{
	if(g_pErrorManager == NULL)
		return FALSE;

	FRACTALERROR Error;
	Error.Severity = Severity;
	Error.Code = Code;
	Error.Message = Message;
	Error.FileName = FileName;
	Error.Line = Line;

	return g_pErrorManager -> OnError(Error);
}
