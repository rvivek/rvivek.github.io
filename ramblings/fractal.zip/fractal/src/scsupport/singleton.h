
/**
This class is used by the singleton classes. When a class is inherited from
CSingleton it will have the implementation of basic singleton functionality.
The child class has to declare its constructors/destructor as private and
declare CSingleton and CJanitor as friend.
*/

#ifndef _SINGLETON_H_
#define _SINGLETON_H_

template<class TYPE>
class CSingleton
{
public:
	static TYPE*		GetInstance()
	{
		if(m_pInstance == NULL)
			m_pInstance = new TYPE();

		m_RefCount++;

		return m_pInstance;
	}

	void				ReleaseInstance()
	{
		m_RefCount--;

		//if(m_RefCount < 0);

		if(m_RefCount == 0)
		{
			delete m_pInstance;
			m_pInstance = NULL;
		}
	}

private:
	static TYPE			*m_pInstance;
	static unsigned int	m_RefCount;
};

template<class TYPE>
TYPE *CSingleton<TYPE>::m_pInstance = NULL;

template<class TYPE>
unsigned int CSingleton<TYPE>::m_RefCount = 0;

#endif // _SINGLETON_H_
