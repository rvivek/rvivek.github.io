
#include <windows.h>
#include <string>
#include "scom_server.h"
#include "errormanager_impl.h"

extern "C" IComponent* InstantiateComponent(LPCSTR pName, LONG lInstData)
{
	if(strcmp(pName, "ErrorManager") == 0)
	{
		return CErrorManager::GetInstance();
	}

	return NULL;
}

extern "C" BOOL DeleteComponent(IComponent *pComponent)
{
	// We can downcast safely because this is the only component so far
	((CErrorManager*)pComponent) -> ReleaseInstance();

	return TRUE;
}
