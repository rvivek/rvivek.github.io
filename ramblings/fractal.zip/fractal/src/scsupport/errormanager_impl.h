
#ifndef _ERRORMANAGER_IMPL_H_
#define _ERRORMANAGER_IMPL_H_

#include "errormanager.h"
#include "singleton.h"

class CErrorManager : public IErrorManager, public CSingleton<CErrorManager>
{
public:
	CErrorManager();
	virtual ~CErrorManager();

	virtual BOOL			OnError(const FRACTALERROR &Error);
	virtual BOOL			GetLastError(FRACTALERROR &Error);
	virtual BOOL			SetErrorHandler(IErrorHandler *Handler);

private:
	IErrorHandler			*m_pHandler;
	FRACTALERROR			m_LastError;
	BOOL					m_fFirstError;

	friend CSingleton<CErrorManager>;
};


#endif // _ERRORMANAGER_IMPL_H_
