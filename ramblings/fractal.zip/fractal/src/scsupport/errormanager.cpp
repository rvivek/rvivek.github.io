
#include "errormanager_impl.h"

CErrorManager::CErrorManager()
{
	m_pHandler = NULL;
	m_fFirstError = FALSE;
}

CErrorManager::~CErrorManager()
{
}

BOOL CErrorManager::OnError(const FRACTALERROR &Error)
{
	m_fFirstError = TRUE;

	if(m_pHandler != NULL)
		m_pHandler -> OnError(Error);

	return TRUE;
}

BOOL CErrorManager::GetLastError(FRACTALERROR &Error)
{
	if(m_fFirstError == TRUE)
	{
		Error = m_LastError;
		return TRUE;
	}

	return FALSE;
}

BOOL CErrorManager::SetErrorHandler(IErrorHandler *Handler)
{
	m_pHandler = Handler;

	return TRUE;
}
