
#include <crtdbg.h>
#include "scom.h"
#include "errormanager.h"

int main()
{
	scInit("C:\\scom_registry.ini");

	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	//_CrtSetBreakAlloc(46);

	IErrorManager *pManager = (IErrorManager*)scCreateComponent("ErrorManager");
	scDeleteComponent(pManager);

	scFree();

	return 0;
}
