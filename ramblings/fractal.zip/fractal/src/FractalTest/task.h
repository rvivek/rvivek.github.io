
#ifndef _TASK_H_
#define _TASK_H_

#include <bass.h>
#include "taskinterface.h"
#include "fader.h"
#include "camera.h"
#include "camerapath.h"
#include "skydome.h"

typedef struct _SKYDOMEINFO
{
	D3DXCOLOR Color1, Color2;
	D3DXCOLOR SunColor;
	D3DXCOLOR FogColor;
	BYTE Density;
	FLOAT Fluffiness;
	FLOAT windx, windy;
	FLOAT modconst;
} SKYDOMEINFO;

class CTask : public ITask
{
public:
	CTask(
		const VIDEODEVICE &Device, IAttributeStack *Stack,
		UINT x, UINT y, UINT Width, UINT Height,
		CCamera *pCamera,
		LPSTR Caption,
		DWORD *CapColor,
		D3DCOLORVALUE *pAmbient, D3DCOLORVALUE *pDiffuse,
		D3DXCOLOR *pFog,
		ISkydome* pSkydome,
		const SKYDOMEINFO &SkyNice,
		const SKYDOMEINFO &SkyDark,
		BOOL *fFire
		);
	~CTask();

	BOOL				Init(const TASKPARAM &Param);

	virtual BOOL		ExecuteTask(FLOAT Timeslice, const TASKPARAM &Param);
	
private:
	BOOL				SetCaptionString(const TASKPARAM &Param, LPCSTR String);
	BOOL				LerpSky(FLOAT lerp);

private:
	VIDEODEVICE			m_Device;
	IAttributeStack		*m_pStack;

	IFader				*m_IntroFader;
	IFader				*m_PostFader;
	FLOAT				m_Slerp;

	ICameraPath			*m_CameraPath1;
	ICameraPath			*m_CameraPath2;
	ICameraPath			*m_CameraPath3;
	ICameraPath			*m_CameraPath4;
	ICameraPath			*m_CameraPath5;
	ICameraPath			*m_CameraPath6;
	ICameraPath			*m_CameraPath7;
	ICameraPath			*m_CameraPath8;
	
	CCamera				*m_pCamera;
	
	LPSTR				m_pStrBuf;
	DWORD				*m_pStrColor;

	D3DCOLORVALUE		*m_pAmbient, *m_pDiffuse;
	D3DCOLORVALUE		m_DarkAmbient, m_DarkDiffuse;
	D3DCOLORVALUE		m_LightAmbient, m_LightDiffuse;
	D3DXCOLOR			*m_pFog;

	BOOL				*m_fFire;

	ISkydome			*m_Skydome;

	SKYDOMEINFO			m_SkyDark, m_SkyNice, m_SkyCurrent;

	HSAMPLE				m_sAmbient, m_sGentle;
};

#endif // _TASK_H_
