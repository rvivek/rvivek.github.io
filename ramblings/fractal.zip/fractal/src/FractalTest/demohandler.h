
#ifndef _DEMOHANDLER_H_
#define _DEMOHANDLER_H_

#include <windows.h>
#include <fstream>
#include "errormanager.h"

BOOL ReleaseResources();

class CErrorHandler : public IErrorHandler
{
public:
	CErrorHandler() {};
	virtual ~CErrorHandler() {};
	
	virtual BOOL			OnError(const FRACTALERROR &Error)
	{
		switch(Error.Severity)
		{
		case S_FRACTAL_ERROR: case S_FRACTAL_CRITICAL:
			MessageBox(NULL, "An internal error has occured inside the application. We apologize for the inconvinience.", "FractalDemo", MB_ICONERROR);
			LogError(Error);
			ReleaseResources();
			exit(-1);
			break;
		}

		return TRUE;
	};

	BOOL LogError(const FRACTALERROR &Error)
	{
		std::ofstream LogFile("log.txt");

		LogFile << "Severity: \t"	<< Error.Severity	<< std::endl;
		LogFile << "Code: \t\t"		<< Error.Code		<< std::endl;
		LogFile << "Message: \t"	<< Error.Message	<< std::endl;
		LogFile << "File: \t\t"		<< Error.FileName	<< std::endl;
		LogFile << "Line: \t\t"		<< Error.Line		<< std::endl;

		LogFile.close();
		return TRUE;
	}
};

#endif // _DEMOHANDLER_H_
