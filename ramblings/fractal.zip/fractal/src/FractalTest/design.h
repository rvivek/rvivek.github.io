
#ifndef _DESIGN_H_
#define _DESIGN_H_

//#define DESIGN_PATH			1

#endif // _DESIGN_H_
