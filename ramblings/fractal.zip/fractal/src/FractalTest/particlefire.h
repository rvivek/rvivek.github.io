
#ifndef _PARTICLEFIRE_H_
#define _PARTICLEFIRE_H_

#include <d3d8.h>
#include "particlesystem.h"
#include "attributestack.h"

class CParticleFire : public IParticleSystem
{
public:
	CParticleFire(const VIDEODEVICE &Device, IAttributeStack *Stack);
	virtual ~CParticleFire();

	virtual INT				Tick(FLOAT Timeslice);
	virtual BOOL			UpdateParticle(PARTICLE *Particle, FLOAT Timeslice);
	virtual BOOL			Render(const PARTICLE &Particle);
	virtual BOOL			Emit(PARTICLE *Particle);

	BOOL					SetWindVector(const D3DXVECTOR3 &Wind);

private:
	FLOAT					m_LastTimeslice;
	FLOAT					m_TimeDimension;
	LPDIRECT3DTEXTURE8		m_FireTexture;
	D3DXVECTOR3				m_Wind;
	VIDEODEVICE				m_Device;
};

#endif // _PARTICLEFIRE_H_
