
#include <windows.h>
#include <crtdbg.h>
#include <d3d8.h>
#include <d3dx8.h>
#include <bass.h>
#include "scom.h"
#include "videodevice.h"
#include "nativewindow.h"
#include "terrain.h"
#include "skydome.h"
#include "fpscamera.h"
#include "fpscounter.h"
#include "particlefire.h"
#include "particlesystemmanager.h"
#include "watersurface.h"
#include "progressbar.h"
#include "taskmanager.h"
#include "task.h"
#include "errormanager.h"
#include "demohandler.h"
#include "text.h"
#include <fstream>
#include "design.h"
#include "noise.h"
#include <time.h>

#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }

// Some of the variables we'll need
CFPSCamera					Camera;
IFPSCounter					*pCounter = NULL;
INativeWindow				*pNativeWindow = NULL;
IVideoDevice				*pVideoDevice = NULL;
IProgressBar				*pProgressBar = NULL;
ITerrain					*pTerrain = NULL;
IWaterSurface				*pWater = NULL;
ISkydome					*pSkydome = NULL;
IParticleSystemManager		*pPSM = NULL;
ITaskManager				*pTaskManager = NULL;
IText						*pText = NULL;

// Config variables
D3DXMATRIX					matWorld, matView, matProj;
INT							Width, Height, ViewHeight;
INT							Adapter, Format, RefreshRate;
BOOL						fWindowed;
BOOL						fBass = FALSE;
BOOL						done = FALSE;
BOOL						fFire = FALSE;

// Current string
char						pCurrentCaption[255];
DWORD						CaptionColor = D3DCOLOR_ARGB(255, 255, 255, 255);
D3DXCOLOR					g_FogColor;
D3DCOLORVALUE				g_Diffuse, g_Ambient;
SKYDOMEINFO					g_Dark, g_Nice;

/*#ifdef DESIGN_PATH
std::ofstream CamFile("Camera.txt");
#endif*/

LRESULT WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static WORD oldx = 0, oldy = 0;

	WORD x, y;
	switch(uMsg)
	{
		/*case WM_MOUSEMOVE:
			x = LOWORD(lParam); 
			y = HIWORD(lParam); 

			Camera.Turn((x - oldx) / 100.0f);
			Camera.LookUp(-(y - oldy) / 50.0f);
			oldx = x;
			oldy = y;

			return 0;
			break;*/

		case WM_KEYDOWN:
			switch(wParam)
			{
			case VK_ESCAPE:
				PostQuitMessage(0);
				break;

			/*case VK_UP:
				Camera.MoveForward(150.0f);
				break;

			case VK_DOWN:
				Camera.MoveForward(-150.0f);
				break;

			case VK_LEFT:
				Camera.Strafe(150.0f);
				break;

			case VK_RIGHT:
				Camera.Strafe(-150.0f);
				break;

			case VK_NUMPAD5:
				// Dump the camera position to a file
#ifdef DESIGN_PATH
				Camera >> CamFile;
#endif
				break;*/
			}
			break;

		case WM_ACTIVATE:
			if(!HIWORD(wParam))
				if(pCounter != NULL) pCounter -> Activate();
			else
				if(pCounter != NULL) pCounter -> Deactivate();
			break;

		case WM_SETFOCUS:
				if(pCounter != NULL) pCounter -> Activate();
			break;

		case WM_KILLFOCUS:
				if(pCounter != NULL) pCounter -> Deactivate();
			break;

		case WM_QUIT:
			done = TRUE;
			break;
	}

	return 0;
}

BOOL LoadSettings(BOOL fFirst = TRUE)
{
	Adapter		= GetPrivateProfileInt("Video", "Adapter",		-1, ".\\setup.ini");
	Width		= GetPrivateProfileInt("Video", "Width",		-1, ".\\setup.ini");
	Height		= GetPrivateProfileInt("Video", "Height",		-1, ".\\setup.ini");
	Format		= GetPrivateProfileInt("Video", "Format",		-1, ".\\setup.ini");
	RefreshRate	= GetPrivateProfileInt("Video", "RefreshRate",	-1, ".\\setup.ini");
	fWindowed	= GetPrivateProfileInt("Video", "Windowed",		-1, ".\\setup.ini");

	if(Adapter == -1 || Width == -1 || Height == -1 || Format == -1 || RefreshRate == -1 || fWindowed == -1)
	{
		if(fFirst == FALSE)
		{
			MessageBox(NULL, "Error setting up the demo. Please run the setup manually.", "FractalDemo", MB_OK);
			FRACTAL_ERROR(0, "Could not setup the demo.");
		}

		PROCESS_INFORMATION procinfo;
		STARTUPINFO startupinfo;
		ZeroMemory(&startupinfo, sizeof(STARTUPINFO));
		startupinfo.cb = sizeof(STARTUPINFO);
		MessageBox(NULL, "You are running the demo for the first time. A setup will be ran that will help you configure the demo.", "FractalDemo", MB_OK);
		CreateProcess("Config.exe", NULL, NULL, NULL, FALSE, 0, NULL, NULL, &startupinfo, &procinfo);
		
		// Wait until the configuration is complete
		WaitForSingleObject(procinfo.hProcess, INFINITE);
		CloseHandle(procinfo.hThread);
		CloseHandle(procinfo.hProcess);

		// Try to load the settings again
		LoadSettings(FALSE);
	}

	return TRUE;
}

void WideViewport(const VIDEODEVICE &devinfo)
{
	UINT temp = (Height - ViewHeight) / 2;
	D3DVIEWPORT8 viewport1 = {
		0, temp,					// x, y
		Width, ViewHeight,
		0.0f, 1.0f					// minx, minz
	};
	devinfo.Device -> SetViewport(&viewport1);
}

void NormalViewport(const VIDEODEVICE &devinfo)
{
	D3DVIEWPORT8 viewport = {
		0, 0,					// x, y
		Width, Height,
		0.0f, 1.0f				// minx, minz
	};
	devinfo.Device->SetViewport(&viewport);
}

void InitFrame(const VIDEODEVICE &devinfo)
{
	// Setup states
	devinfo.Device -> SetRenderState(D3DRS_LIGHTING, FALSE);
	//devinfo.Device -> SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME );

	// Setup the matreces
    D3DXMatrixIdentity( &matWorld );
    devinfo.Device->SetTransform( D3DTS_WORLD, &matWorld );

    //D3DXMatrixPerspectiveFovLH( &matProj, D3DX_PI/4, (FLOAT)Width / (FLOAT)ViewHeight, 10.0f, 100000.0f );
	Camera.GetProjMatrix(matProj);
	devinfo.Device->SetTransform( D3DTS_PROJECTION, &matProj );

	// Init the light
	D3DLIGHT8 Light;
	ZeroMemory(&Light, sizeof(D3DLIGHT8));
	Light.Type = D3DLIGHT_DIRECTIONAL;
	Light.Diffuse = g_Diffuse;
	Light.Ambient = g_Ambient;

	D3DXVECTOR3 Dir(0, -1, -1);
	D3DXVec3Normalize((D3DXVECTOR3*)&Light.Direction, &Dir);

	devinfo.Device -> SetLight(0, &Light);
	devinfo.Device -> LightEnable(0, TRUE);

	// Fog
	FLOAT
		Density = 0.000030f,
		Start = 50000.0f,
		End = 85000.0f;
	devinfo.Device -> SetRenderState(D3DRS_FOGENABLE, TRUE);
	devinfo.Device -> SetRenderState(D3DRS_FOGCOLOR, g_FogColor);
	devinfo.Device -> SetRenderState(D3DRS_FOGTABLEMODE, D3DFOG_LINEAR);
	devinfo.Device -> SetRenderState(D3DRS_FOGDENSITY, *((DWORD*)(&Density)));
	devinfo.Device -> SetRenderState(D3DRS_FOGSTART, *((DWORD*)(&Start)));
	devinfo.Device -> SetRenderState(D3DRS_FOGEND, *((DWORD*)(&End)));
}

void InitSky()
{
	g_Dark.Color1 = D3DXCOLOR(100 / 255.0f, 80 / 255.0f, 70 / 255.0f, 255 / 255.0f);
	g_Dark.Color2 = D3DXCOLOR(50 / 255.0f, 50 / 255.0f, 50 / 255.0f, 255 / 255.0f);
	g_Dark.SunColor = D3DXCOLOR(255 / 255.0f, 255 / 255.0f, 255 / 255.0f, 60 / 255.0f);
	g_Dark.Density = 120;
	g_Dark.Fluffiness = 0.992f;
	g_Dark.modconst = 0.02f;
	g_Dark.windx = 0.02f;
	g_Dark.windy = 0.02f;
//	g_Dark.FogColor = D3DXCOLOR(100 / 255.0f, 80 / 255.0f, 70 / 255.0f, 255 / 255.0f);
	g_Dark.FogColor = D3DXCOLOR(139 / 255.0f, 122 / 255.0f, 93 / 255.0f, 255 / 255.0f);

	g_Nice.Color1 = D3DXCOLOR(160 / 255.0f, 130 / 255.0f, 115 / 255.0f, 255 / 255.0f);
	g_Nice.Color2 = D3DXCOLOR(100 / 255.0f, 100 / 255.0f, 100 / 255.0f, 255 / 255.0f);
	g_Nice.SunColor = D3DXCOLOR(255 / 255.0f, 255 / 255.0f, 255 / 255.0f, 255 / 255.0f);
	g_Nice.Density = 230;
	g_Nice.Fluffiness = 0.96f;
	g_Nice.modconst = 0.005f;
	g_Nice.windx = 0.005f;
	g_Nice.windy = 0.005f;
	g_Nice.FogColor = D3DXCOLOR(209 / 255.0f, 192 / 255.0f, 163 / 255.0f, 255 / 255.0f);

	g_FogColor = g_Dark.FogColor;
}

BOOL DrawProgressBar(const VIDEODEVICE &devinfo, IProgressBar *pBar, FLOAT val)
{
	pBar -> SetValue(val);

	InitFrame(devinfo);
	NormalViewport(devinfo);
	devinfo.Device -> Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_ARGB(255, 0, 0, 0), 1.0f, 0);

	devinfo.Device -> BeginScene();
	pBar -> Render();
	devinfo.Device -> EndScene();
	devinfo.Device -> Present(NULL, NULL, NULL, NULL);

	return TRUE;
}

BOOL AddTask(CTask *Task, UINT Param, FLOAT Duration, FLOAT StartTime)
{
	FRACTALTASK		TaskInfo;
	TASKPARAM		TaskParam;

	TaskParam.Param = Param;
	TaskParam.Duration = Duration;
	TaskParam.CurrentTime = 0.0f;
	TaskInfo.StartTime = StartTime;
	TaskInfo.EndTime = StartTime + Duration;
	TaskInfo.Param = TaskParam;
	TaskInfo.Task = Task;
	Task -> Init(TaskParam);
	pTaskManager -> AddTask(TaskInfo);

	return TRUE;
}

BOOL InitTasks(CTask *Task)
{
	// Fade in 0:00 - 3:00 + the ambient ocean/wind sound
	AddTask(Task, 1, 3.0f, 0.0f);

	// "Dark are the days."
	// 5:00 - 10:00
	AddTask(Task, 5, 5.0f, 5.0f);

	// "The air is saturated with fear."
	// 11:00 - 16:00
	AddTask(Task, 6, 5.0f, 11.0f);

	// Camera sliding towards the sun (path 1)
	// 17:00 - 23:00
	AddTask(Task, 2, 5.0f, 17.0f);

	// "The sun can barely be seen"
	// 24:00 - 29:00
	AddTask(Task, 7, 5.0f, 24.0f);

	// Camera sliding down towards the ocean (path 2)
	// 30:00 - 35:00
	AddTask(Task, 3, 5.0f, 30.0f);

	// "Only the ancient oceans are untouched by evil."
	// 36:00 - 41:00
	AddTask(Task, 8, 5.0f, 36.0f);

	// Camera sliding around the island (path 3)
	// 42:00 - 57:00
	AddTask(Task, 4, 15.0f, 42.0f);

	// "No living thing can survive the darkness"
	// 58:00 - 63:00
	AddTask(Task, 9, 5.0f, 58.0f);

	// Wide turn around the island
	// 64:00 - 84:00
	AddTask(Task, 10, 20.0f, 64.0f);

	// "But better days shall come"
	// 85:00 - 90:00
	AddTask(Task, 11, 5.0f, 85.0f);

	// Change the lighting
	// 87:50 - 93:50
	AddTask(Task, 17, 6.0f, 87.5f);

	// "The sky shall be bright again"
	// 91:00 - 96:00
	AddTask(Task, 12, 5.0f, 91.0f);

	// "The sun shall shine once more"
	// 97:00 - 102:00
	AddTask(Task, 13, 5.0f, 97.0f);

	// Turn towards the sun
	// 97:00 - 102:00
	AddTask(Task, 14, 5.0f, 97.0f);

	// "Our children shall live in peace"
	// 102:00 - 107:00
	AddTask(Task, 15, 5.0f, 102.0f);

	// "And we shall remember our heroes"
	// 108:00 - 113:00
	AddTask(Task, 16, 5.0f, 108.0f);
	
	// The camera slides towards the plateau
	// 114:00 - 124:00
	AddTask(Task, 18, 10.0f, 114.0f);
	
	// "An eternal flame shall be lit to honor them"
	// 124:00 - 129:00
	AddTask(Task, 19, 5.0f, 124.0f);

	// Start the flame
	// 124:00 - 129:00
	AddTask(Task, 27, 2.0f, 127.5f);

	// "Sleep in peace"
	// 130:00 - 135:00
	AddTask(Task, 20, 5.0f, 130.0f);

	// "We shall not forget you"
	// 136:00 - 141:00
	AddTask(Task, 21, 5.0f, 136.0f);

	// Spin the camera around the island
	// 142:00 - 172:00
	AddTask(Task, 22, 30.0f, 142.0f);

	// "We shall not forget you"
	// 173:00 - 178:00
	AddTask(Task, 23, 5.0f, 173.0f);

	// Turn the camera towards the sun
	// 173:00 - 178:00
	AddTask(Task, 24, 5.0f, 173.0f);

	// Fade out
	// 183:00 - 193:00
	AddTask(Task, 25, 10.0f, 183.0f);

	// Quit
	// 190:00
	AddTask(Task, 26, 2.0f, 188.0f);

	return TRUE;
}

BOOL ReleaseResources()
{
	// Remove the task manager
	if(pTaskManager != NULL)
	{
		pTaskManager -> Destroy();
		scDeleteComponent(pTaskManager);
		pTaskManager = NULL;
	}

	// Remove the particle system manager
	if(pPSM != NULL)
	{
		pPSM -> Destroy();
		scDeleteComponent(pPSM);
		pPSM = NULL;
	}

	// Remove the skydome
	if(pSkydome != NULL)
	{
		pSkydome -> Destroy();
		scDeleteComponent(pSkydome);
		pSkydome = NULL;
	}

	// Delete the water surface
	if(pWater != NULL)
	{
		pWater -> Destroy();
		scDeleteComponent(pWater);
		pWater = NULL;
	}

	// Delete the fps counter
	if(pCounter != NULL)
	{
		scDeleteComponent(pCounter);
		pCounter = NULL;
	}

	// Remove the terrain
	if(pTerrain != NULL)
	{
		pTerrain -> Destroy();
		scDeleteComponent(pTerrain);
		pTerrain = NULL;
	}

	if(pText != NULL)
	{
		pText -> Destroy();
		scDeleteComponent(pText);
		pText = NULL;
	}

	// Delete the sound
	if(fBass == TRUE)
	{
		BASS_Stop();
		BASS_Free();
	}

	// Delete video
	if(pVideoDevice != NULL)
	{
		pVideoDevice -> Destroy();
		scDeleteComponent(pVideoDevice);
		pVideoDevice = NULL;
	}

	// Delete the window
	if(pNativeWindow != NULL)
	{
		pNativeWindow -> Destroy();
		scDeleteComponent(pNativeWindow);
		pNativeWindow = NULL;
	}

	return TRUE;
}
void VarInit()
{
	// Load the initial camera
	std::ifstream CamInit(".\\Data\\Camera\\cam_init.txt");
	Camera << CamInit;
	CamInit.close();

	srand(time(NULL));
	init_noise();

	ZeroMemory(pCurrentCaption, 255);

	g_Diffuse.a = 1.0f;
	g_Diffuse.r = 0.3f;
	g_Diffuse.g = 0.3f;
	g_Diffuse.b = 0.3f;
	g_Ambient.a = 1.0f;
	g_Ambient.r = 0.125f;
	g_Ambient.g = 0.125f;
	g_Ambient.b = 0.125f;
}

int WINAPI WinMain(	HINSTANCE	hInstance,			// Instance
					HINSTANCE	hPrevInstance,		// Previous Instance
					LPSTR		lpCmdLine,			// Command Line Parameters
					int			nCmdShow)			// Window Show State
{
	// This function will cause VC to dump all memory leaks at program termination
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	
	// This function will cause VC to break where memory leak occurs
	//_CrtSetBreakAlloc(46);

	// Init scom
	scInit(".\\compreg.ini");

	// Quick variables init
	VarInit();
	// Init error handling routines
	IErrorManager *pErrorManager = (IErrorManager*)scCreateComponent("ErrorManager");
	CErrorHandler ErrorHandler;
	if(pErrorManager == NULL)
	{
		FRACTALERROR Error;
		Error.Code = 0;
		Error.Severity = S_FRACTAL_ERROR;
		Error.Message = "Could not load ErrorManager.";
		Error.Line = __LINE__;
		Error.FileName = __FILE__;
		ErrorHandler.OnError(Error);
	}
	pErrorManager -> SetErrorHandler(&ErrorHandler);

	// Load the settings
	LoadSettings();

	// Create the window
	pNativeWindow = (INativeWindow*)scCreateComponent("NativeWindow");
	pNativeWindow -> SetMessageHandler(WndProc);
	pNativeWindow -> SetWindowed(fWindowed);
	//pNativeWindow -> SetWindowed(FALSE);
	pNativeWindow -> SetSize(Width, Height);
	pNativeWindow -> SetTitle("FractalDemo");
	pNativeWindow -> Create();
	ViewHeight = Width / 16 * 9;
	if(ViewHeight > Height)
		ViewHeight = Height;

	NATIVEWINDOW wndinfo;
	pNativeWindow -> GetNative(wndinfo);

	// Create video device
	pVideoDevice = (IVideoDevice*)scCreateComponent("VideoDevice");
	pVideoDevice -> SetAdapter(Adapter);
	pVideoDevice -> SetResolution(Width, Height);
	pVideoDevice -> SetColorDepth(Format);
	pVideoDevice -> SetRefreshRate(RefreshRate);
	pVideoDevice -> GetStencilFormatCount();
	pVideoDevice -> SetStencilDepth(pVideoDevice -> GetStencilFormat(0));	// Pick the best depth-stencil format
	pVideoDevice -> Create(wndinfo);
	
	// Obtain the device pointer
	VIDEODEVICE devinfo;
	pVideoDevice -> GetDevice(devinfo);
	devinfo.Camera = (CCamera*)&Camera;
	devinfo.Width = Width;
	devinfo.Height = Height;

	// Load the progress bar
	pProgressBar = (IProgressBar*)scCreateComponent("ProgressBar");
	pProgressBar -> Create(devinfo, static_cast<IAttributeStack*>(pVideoDevice));
	pProgressBar -> SetColor(D3DCOLOR_ARGB(255, 255, 255, 255));
	pProgressBar -> SetPosition(Width / 2, Height / 2);
	pProgressBar -> SetSize(Width / 8, Height / 30);

	// Update the progress bar
	DrawProgressBar(devinfo, pProgressBar, 0.0f);

	// Init the sound library
	if(!BASS_Init(-1, 44100, 0, wndinfo.Wnd))
	{
		BASS_Init(-2, 44100, BASS_DEVICE_NOTHREAD, wndinfo.Wnd);	// couldn't initialize, use no sound :(
	}
	BASS_Start();
	fBass = TRUE;

	// Update the progress bar
	DrawProgressBar(devinfo, pProgressBar, 12.5f);

	D3DXVECTOR3 pos;
	Camera.GetPosition(pos);
	pos.y += 5000;
	Camera.SetPosition(pos);

	// Update the progress bar
	DrawProgressBar(devinfo, pProgressBar, 25);

	// Create the terrain
	pTerrain = (ITerrain*)scCreateComponent("Terrain");
	pTerrain -> Create(devinfo, static_cast<IAttributeStack*>(pVideoDevice), ".\\Data\\Images\\heightmap.bmp");
	pTerrain -> AddLayer(".\\Data\\Images\\dirt_mottledsand_df_.dds", 5, 70, 0, 20);
	pTerrain -> AddLayer(".\\Data\\Images\\dirt_sandyearth-01_df_.dds", 71, 255, 20, 90);

	// Update the progress bar
	DrawProgressBar(devinfo, pProgressBar, 37.5f);

	// Create water
	pWater = (IWaterSurface*)scCreateComponent("WaterSurface");
	pWater -> Create(devinfo, static_cast<IAttributeStack*>(pVideoDevice));
	pWater -> SetEnvironmentMap(".\\Data\\Images\\cubemap.dds");

	// Update the progress bar
	DrawProgressBar(devinfo, pProgressBar, 50);

	// Create the skydome
	pSkydome = (ISkydome*)scCreateComponent("Skydome");
	pSkydome -> SetGradientTexture(".\\Data\\Images\\gradient.bmp");

	InitSky();
	pSkydome -> SetCloudColors(g_Dark.Color1, g_Dark.Color2);
	pSkydome -> SetSunColor(g_Dark.SunColor);
	pSkydome -> SetCloudDensity(g_Dark.Density, g_Dark.Fluffiness);
	pSkydome -> SetWindVelocity(g_Dark.windx, g_Dark.windy);
	pSkydome -> SetModificationConstant(g_Dark.modconst);

	pSkydome -> SetSunTexture(".\\Data\\Images\\sun.bmp");
	pSkydome -> Create(devinfo, static_cast<IAttributeStack*>(pVideoDevice));

	// Update the progress bar
	DrawProgressBar(devinfo, pProgressBar, 62.5f);

	// Create the particle system manager
	pPSM = (IParticleSystemManager*)scCreateComponent("ParticleSystemManager");
	pPSM -> Create(devinfo, static_cast<IAttributeStack*>(pVideoDevice));

	// Create the fire system
	CParticleFire Fire(devinfo, static_cast<IAttributeStack*>(pVideoDevice));
	Fire.SetWindVector(D3DXVECTOR3(-400, 0, -400));
	pPSM -> AddParticleSystem(&Fire);

	// Update the progress bar
	DrawProgressBar(devinfo, pProgressBar, 75);

	// Load the fps counter
	pCounter = (IFPSCounter*)scCreateComponent("FPSCounter");

	// Update the progress bar
	DrawProgressBar(devinfo, pProgressBar, 87.5f);

	// load the text component
	pText = (IText*)scCreateComponent("Text");
	pText -> Create(devinfo, static_cast<IAttributeStack*>(pVideoDevice));
	pText -> LoadText(".\\Data\\Images\\font.bmp");

	// Update the progress bar
	DrawProgressBar(devinfo, pProgressBar, 100.0f);

	// Create the task manager
	pTaskManager = (ITaskManager*)scCreateComponent("TaskManager");
	pTaskManager -> Create();
	pTaskManager -> SetCurrentTime(0.f);

	// Create the tasks
	UINT tc = (Height - ViewHeight) / 2;
	CTask Task(devinfo, static_cast<IAttributeStack*>(pVideoDevice), 0, tc, Width, ViewHeight, &Camera, pCurrentCaption, &CaptionColor, &g_Ambient, &g_Diffuse, &g_FogColor, pSkydome, g_Nice, g_Dark, &fFire);
//#ifndef DESIGN_PATH
	InitTasks(&Task);
//#endif

	// Remove the progress bar
	scDeleteComponent(pProgressBar);
	pProgressBar = NULL;

	MSG		msg;									// Windows Message Structure

	while(!done)									// Loop That Runs While done=FALSE
	{
		if(PeekMessage(&msg,NULL,0,0,PM_REMOVE))	// Is There A Message Waiting?
		{
			if (msg.message==WM_QUIT)				// Have We Received A Quit Message?
			{
				done = TRUE;						// If So done=TRUE
			}
			else									// If Not, Deal With Window Messages
			{
				TranslateMessage(&msg);				// Translate The Message
				DispatchMessage(&msg);				// Dispatch The Message
			}
		}
		else										// If There Are No Messages
		{
			if(pNativeWindow -> IsActive())
			{
				// Init the scene
				devinfo.Device -> BeginScene();
				InitFrame(devinfo);

				NormalViewport(devinfo);
				// Clear the buffers
				devinfo.Device -> Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_ARGB(255, 0, 0, 0), 1.0f, 0);
				WideViewport(devinfo);

				// Set up the camera to render the sky
				D3DXVECTOR3 pos;
				Camera.GetPosition(pos);
				Camera.SetPosition(D3DXVECTOR3(0, 0, 0));
				Camera.GetCameraMatrix(matView);
				devinfo.Device -> SetTransform(D3DTS_VIEW, &matView);

				// Render the sky
				pSkydome -> Render();

				// Restore the camera
				Camera.SetPosition(pos);
				Camera.GetCameraMatrix(matView);
				devinfo.Device -> SetTransform( D3DTS_VIEW, &matView );

				// Render the water
				// We need to modify the cull planes
				Camera.SetCullPlanes(10.0f, 75000.0f);
				Camera.GetProjMatrix(matProj );
				devinfo.Device->SetTransform( D3DTS_PROJECTION, &matProj );
				pWater -> Render();
				// Get the camera values back
				Camera.SetCullPlanes(10.0f, 100000.0f);
				Camera.GetProjMatrix(matProj );
				devinfo.Device->SetTransform( D3DTS_PROJECTION, &matProj );

				// Render the terrain
				pTerrain -> Render();

				// Render the particle systems
				if(fFire)
				{
					pPSM -> Render();
				}

				// Do the tasks
				pTaskManager -> Tick(pCounter -> GetTimeslice());

				// Render the FPS
				/*char buffer[256];
				float fps = pCounter -> GetFramerate();
				_gcvt((float)fps, 5, buffer);
				pText -> DrawString(buffer, 5, (Height - ViewHeight) / 2 + 5, 10, 10, D3DCOLOR_ARGB(255, 255, 0, 0));*/

				// Render the current caption string
				UINT clen = strlen(pCurrentCaption);
				FLOAT ch = (Height - ViewHeight) / 9;
				FLOAT cw = (Height - ViewHeight) / 11;
				if(clen != 0)
				{
					NormalViewport(devinfo);
					pText -> DrawString(
						pCurrentCaption,
						Width / 2 - clen * cw / 2, (Height - ViewHeight) / 4 - ch / 2,
						cw, ch,
						CaptionColor);
				}

				devinfo.Device -> EndScene();
				devinfo.Device -> Present(NULL, NULL, NULL, NULL);

				// Tick the AI/Physics/Sound
				pCounter -> Tick();
				pSkydome -> Tick(pCounter -> GetTimeslice());
				if(fFire)
				{
					pPSM -> Tick(pCounter -> GetTimeslice());
				}
				pWater -> Tick(pCounter -> GetTimeslice());
			}
			else
				WaitMessage();
		}
	}

	// Release everything we can
	ReleaseResources();

	// Free error handling
	scDeleteComponent(pErrorManager);
	pErrorManager = NULL;

	// Free scom
	scFree();

	return 0;//(msg.wParam);							// Exit The Program
}
