
#include <d3dx8.h>
#include "particlefire.h"
#include "particle.h"
#include "uniform_noise.h"
#include "noise.h"
#include "scom.h"
#include "fractal_errors.h"

#define TEXTURE_SIZE		64

CParticleFire::CParticleFire(const VIDEODEVICE &Device, IAttributeStack *Stack)
{
	m_Device = Device;

	// Load the fire texture
	if(FAILED(D3DXCreateTextureFromFile(
		m_Device.Device,
		".\\Data\\Images\\fire.bmp",
		&m_FireTexture
		)))
	{
		FRACTAL_ERROR(FRACTAL_INVALID_PARAMETER, "Could not load the texture.");
		return;
	}

	m_Wind = D3DXVECTOR3(0, 0, 0);
	m_TimeDimension = 0;
}

CParticleFire::~CParticleFire()
{
	if(m_FireTexture != NULL)
	{
		m_FireTexture -> Release();
		m_FireTexture = NULL;
	}
}

INT CParticleFire::Tick(FLOAT Timeslice)
{
	m_LastTimeslice = Timeslice;
	m_TimeDimension += Timeslice * 1;

	return 3;
}

BOOL CParticleFire::UpdateParticle(PARTICLE *p, FLOAT Timeslice)
{
	// Add wind
	float temp[2];
	temp[0] = m_TimeDimension;

	temp[1] = 0;
	FLOAT windx = noise2(temp) * 100;
	temp[1] = 2;
	FLOAT windz = noise2(temp) * 100;

	// modify the position
	p -> x += p -> dx * Timeslice + m_Wind.x * Timeslice + windx;
	p -> y += p -> dy * Timeslice + m_Wind.y * Timeslice;
	p -> z += p -> dz * Timeslice + m_Wind.z * Timeslice + windz;

	// modify the color
	p -> g += 80 * Timeslice;

	int a = p -> a - 150.0f * Timeslice;
	if(a < 0)
		a = 0;
	p -> a = (BYTE)a;

	// the age...
	p -> age += 1.0f * Timeslice;

	if(p -> age >= p -> maxage)
		return FALSE;

	return TRUE;
}

BOOL CParticleFire::Render(const PARTICLE &Particle)
{
	return FALSE;
}

BOOL CParticleFire::Emit(PARTICLE *p)
{
	for(int i = 0; i < 3; i++)
	{
		p[i].a = 255;
		p[i].r = 255;
		p[i].g = 0;
		p[i].b = 0;

		p[i].Texture.Texture = m_FireTexture;

		p[i].x = NormDist(0, 150) - 4200;
		p[i].y = 600;
		p[i].z = NormDist(0, 150);

		p[i].dx = NormDist(0, 100);
		p[i].dy = NormDist(2000, 200);
		p[i].dz = NormDist(0, 100);

		p[i].size = NormDist(500, 200);

		p[i].age = 0;
		p[i].maxage = NormDist(6, 2);

		p[i].System = this;
	}

	return TRUE;
}

BOOL CParticleFire::SetWindVector(const D3DXVECTOR3 &Wind)
{
	m_Wind = Wind;

	return TRUE;
}
