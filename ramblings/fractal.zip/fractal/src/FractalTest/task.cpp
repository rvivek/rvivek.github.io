
#include "task.h"
#include "scom.h"
#include "uniform_noise.h"

CTask::CTask(
		const VIDEODEVICE &Device, IAttributeStack *Stack,
		UINT x, UINT y, UINT Width, UINT Height,
		CCamera *pCamera,
		LPSTR Caption,
		DWORD *CapColor,
		D3DCOLORVALUE *pAmbient, D3DCOLORVALUE *pDiffuse,
		D3DXCOLOR *pFog,
		ISkydome* pSkydome,
		const SKYDOMEINFO &SkyNice,
		const SKYDOMEINFO &SkyDark,
		BOOL *fFire
		)
{
	m_Device = Device;
	m_pStack = Stack;

	m_pStrBuf = Caption;
	m_pStrColor = CapColor;

	m_IntroFader = (IFader*)scCreateComponent("Fader");
	m_IntroFader -> SetInterval(3.0f, TRUE);
	m_IntroFader -> SetDimensions(x, y, Width, Height);
	m_IntroFader -> Create(Device, Stack);
	m_PostFader = (IFader*)scCreateComponent("Fader");
	m_PostFader -> SetInterval(3.0f, FALSE);
	m_PostFader -> SetDimensions(x, y, Width, Height);
	m_PostFader -> Create(Device, Stack);

	m_Skydome = pSkydome;
	m_SkyDark = SkyDark;
	m_SkyNice = SkyNice;

	m_fFire = fFire;

	m_Slerp = 0.0f;

	m_pCamera = pCamera;

	// Init the lighting
	m_LightDiffuse.a = 1.0f;
	m_LightDiffuse.r = 0.8f;
	m_LightDiffuse.g = 0.8f;
	m_LightDiffuse.b = 0.8f;
	m_LightAmbient.a = 1.0f;
	m_LightAmbient.r = 0.2f;
	m_LightAmbient.g = 0.2f;
	m_LightAmbient.b = 0.2f;

	m_pAmbient = pAmbient;
	m_pDiffuse = pDiffuse;
	m_DarkAmbient = *pAmbient;
	m_DarkDiffuse = *pDiffuse;

	m_pFog = pFog;

	m_sAmbient = BASS_SampleLoad(FALSE, ".\\Data\\Sounds\\gushing_wind.wav", 0, 0, 1, BASS_SAMPLE_LOOP);
	if(m_sAmbient == 0)
		FRACTAL_WARNING(0, "Could not load sound.");
	m_sGentle = BASS_SampleLoad(FALSE, ".\\Data\\Sounds\\gentle_wind.wav", 0, 0, 1, BASS_SAMPLE_LOOP);
	if(m_sGentle == 0)
		FRACTAL_WARNING(0, "Could not load sound.");
}

CTask::~CTask()
{
	BASS_SampleStop(m_sGentle);
	BASS_SampleFree(m_sGentle);
	BASS_SampleStop(m_sAmbient);
	BASS_SampleFree(m_sAmbient);

	scDeleteComponent(m_CameraPath1);
	m_CameraPath1 = NULL;
	scDeleteComponent(m_CameraPath2);
	m_CameraPath2 = NULL;
	scDeleteComponent(m_CameraPath3);
	m_CameraPath3 = NULL;
	scDeleteComponent(m_CameraPath4);
	m_CameraPath4 = NULL;
	scDeleteComponent(m_CameraPath5);
	m_CameraPath5 = NULL;
	scDeleteComponent(m_CameraPath6);
	m_CameraPath6 = NULL;
	scDeleteComponent(m_CameraPath7);
	m_CameraPath7 = NULL;
	scDeleteComponent(m_CameraPath8);
	m_CameraPath8 = NULL;

	scDeleteComponent(m_IntroFader);
	m_IntroFader = NULL;
	scDeleteComponent(m_PostFader);
	m_PostFader = NULL;

	m_Skydome = NULL;

	m_pCamera = NULL;
}

BOOL CTask::Init(const TASKPARAM &Param)
{
	switch(Param.Param)
	{
	case 2:			// Camera path1
		m_CameraPath1 = (ICameraPath*)scCreateComponent("CameraPath");
		m_CameraPath1 -> Create(".\\Data\\Camera\\Path1.txt");
		break;
	case 3:			// Camera path2
		m_CameraPath2 = (ICameraPath*)scCreateComponent("CameraPath");
		m_CameraPath2 -> Create(".\\Data\\Camera\\Path2.txt");
		break;
	case 4:			// Camera path3
		m_CameraPath3 = (ICameraPath*)scCreateComponent("CameraPath");
		m_CameraPath3 -> Create(".\\Data\\Camera\\Path3.txt");
		break;
	case 10:			// Camera path4
		m_CameraPath4 = (ICameraPath*)scCreateComponent("CameraPath");
		m_CameraPath4 -> Create(".\\Data\\Camera\\Path4.txt");
		break;
	case 14:			// Camera path5
		m_CameraPath5 = (ICameraPath*)scCreateComponent("CameraPath");
		m_CameraPath5 -> Create(".\\Data\\Camera\\Path5.txt");
		break;
	case 18:			// Camera path6
		m_CameraPath6 = (ICameraPath*)scCreateComponent("CameraPath");
		m_CameraPath6 -> Create(".\\Data\\Camera\\Path6.txt");
		break;
	case 22:			// Camera path7
		m_CameraPath7 = (ICameraPath*)scCreateComponent("CameraPath");
		m_CameraPath7 -> Create(".\\Data\\Camera\\Path7.txt");
		break;
	case 24:			// Camera path7
		m_CameraPath8 = (ICameraPath*)scCreateComponent("CameraPath");
		m_CameraPath8 -> Create(".\\Data\\Camera\\Path8.txt");
		break;
	}

	return TRUE;
}

BOOL CTask::ExecuteTask(FLOAT Timeslice, const TASKPARAM &Param)
{
	D3DXMATRIX Matrix;
	D3DXVECTOR3 Position;

	D3DXCOLOR Color;

	static BOOL fsAmbient = FALSE;
	static BOOL fsGentle = FALSE;

	switch(Param.Param)
	{
	case 1:			// Fade in
		m_IntroFader -> Tick(Timeslice);
		m_IntroFader -> Render();
		if(!fsAmbient)
		{
			BASS_SamplePlay(m_sAmbient);
			fsAmbient = TRUE;
		}
		break;

	case 2:
		m_CameraPath1 -> Slerp(Param.CurrentTime / Param.Duration);
		m_CameraPath1 -> GetMatrix(Matrix);
		m_CameraPath1 -> GetPosition(Position);
		m_pCamera -> SetCameraMatrix(Matrix);
		m_pCamera -> SetPosition(Position);
		break;

	case 3:
		m_CameraPath2 -> Slerp(Param.CurrentTime / Param.Duration);
		m_CameraPath2 -> GetMatrix(Matrix);
		m_CameraPath2 -> GetPosition(Position);
		m_pCamera -> SetCameraMatrix(Matrix);
		m_pCamera -> SetPosition(Position);
		break;

	case 4:
		m_CameraPath3 -> Slerp(Param.CurrentTime / Param.Duration);
		m_CameraPath3 -> GetMatrix(Matrix);
		m_CameraPath3 -> GetPosition(Position);
		m_pCamera -> SetCameraMatrix(Matrix);
		m_pCamera -> SetPosition(Position);
		break;

	case 5:
		SetCaptionString(Param, "Dark are the days");
		break;

	case 6:
		SetCaptionString(Param, "The air is saturated with fear");
		break;
	
	case 7:
		SetCaptionString(Param, "The sun can barely be seen");
		break;
	
	case 8:
		SetCaptionString(Param, "Only the ancient oceans are untouched by evil");
		break;

	case 9:
		SetCaptionString(Param, "No living thing can survive the darkness");
		break;

	case 10:
		m_CameraPath4 -> Slerp(Param.CurrentTime / Param.Duration);
		m_CameraPath4 -> GetMatrix(Matrix);
		m_CameraPath4 -> GetPosition(Position);
		m_pCamera -> SetCameraMatrix(Matrix);
		m_pCamera -> SetPosition(Position);
		break;

	case 11:
		SetCaptionString(Param, "But better days shall come");
		break;

	case 12:
		SetCaptionString(Param, "The sky shall be bright again");
		break;

	case 13:
		SetCaptionString(Param, "The sun shall shine once more");
		break;

	case 14:
		m_CameraPath5 -> Slerp(Param.CurrentTime / Param.Duration);
		m_CameraPath5 -> GetMatrix(Matrix);
		m_CameraPath5 -> GetPosition(Position);
		m_pCamera -> SetCameraMatrix(Matrix);
		m_pCamera -> SetPosition(Position);
		break;

	case 15:
		SetCaptionString(Param, "Our children shall live in peace");
		break;

	case 16:
		SetCaptionString(Param, "And we shall remember our heroes");
		break;

	case 17:
		// Change the lighting
		D3DXColorLerp(
			&Color,
			&D3DXCOLOR(m_DarkAmbient),
			&D3DXCOLOR(m_LightAmbient),
			Param.CurrentTime / Param.Duration
			);
		*m_pAmbient = Color;
		D3DXColorLerp(
			&Color,
			&D3DXCOLOR(m_DarkDiffuse),
			&D3DXCOLOR(m_LightDiffuse),
			Param.CurrentTime / Param.Duration
			);
		*m_pDiffuse = Color;

		// Change the weather
		LerpSky(Param.CurrentTime / Param.Duration);
		m_Skydome -> SetCloudColors(m_SkyCurrent.Color1, m_SkyCurrent.Color2);
		m_Skydome -> SetCloudDensity(m_SkyCurrent.Density, m_SkyCurrent.Fluffiness);
		m_Skydome -> SetWindVelocity(m_SkyCurrent.windx, m_SkyCurrent.windy);
		m_Skydome -> SetModificationConstant(m_SkyCurrent.modconst);
		m_Skydome -> SetSunColor(m_SkyCurrent.SunColor);

		*m_pFog = m_SkyCurrent.FogColor;
		
		// Change the sounds
		if(!fsGentle)
		{
			BASS_SamplePlay(m_sGentle);
			BASS_ChannelSetAttributes(m_sGentle, -1, 0, -101);
			fsGentle = TRUE;
		}

		BASS_ChannelSetAttributes(m_sAmbient, -1, (INT)Lerp(100.0f, 0.0f, Param.CurrentTime / Param.Duration), -101);
		BASS_ChannelSetAttributes(m_sGentle, -1, (INT)Lerp(0.0f, 50.0f, Param.CurrentTime / Param.Duration), -101);

		break;

	case 18:
		m_CameraPath6 -> Slerp(Param.CurrentTime / Param.Duration);
		m_CameraPath6 -> GetMatrix(Matrix);
		m_CameraPath6 -> GetPosition(Position);
		m_pCamera -> SetCameraMatrix(Matrix);
		m_pCamera -> SetPosition(Position);
		break;

	case 19:
		SetCaptionString(Param, "An eternal flame shall be lit to honor them");
		break;

	case 20:
		SetCaptionString(Param, "Sleep in peace");
		break;

	case 21:
		SetCaptionString(Param, "We shall not forget you");
		break;

	case 22:
		m_CameraPath7 -> Slerp(Param.CurrentTime / Param.Duration);
		m_CameraPath7 -> GetMatrix(Matrix);
		m_CameraPath7 -> GetPosition(Position);
		m_pCamera -> SetCameraMatrix(Matrix);
		m_pCamera -> SetPosition(Position);
		break;

	case 23:
		SetCaptionString(Param, "We shall not forget you");
		break;

	case 24:
		m_CameraPath8 -> Slerp(Param.CurrentTime / Param.Duration);
		m_CameraPath8 -> GetMatrix(Matrix);
		m_CameraPath8 -> GetPosition(Position);
		m_pCamera -> SetCameraMatrix(Matrix);
		m_pCamera -> SetPosition(Position);
		break;

	case 25:			// Fade out
		m_PostFader -> Tick(Timeslice);
		m_PostFader -> Render();
		break;

	case 26:			// Quit
		PostQuitMessage(0);
		break;

	case 27:			// Start the flame
		*m_fFire = TRUE;
		break;
	}

	return TRUE;
}

BOOL CTask::SetCaptionString(const TASKPARAM &Param, LPCSTR String)
{
	FLOAT Alpha;

	if(Param.CurrentTime < (Param.Duration / 3 * 1))
	{
		Alpha = Param.CurrentTime / (Param.Duration / 3);
	}
	else if(Param.CurrentTime < (Param.Duration / 3 * 2))
	{
		Alpha = 1.0f;
	} else
	{
		Alpha = 1 - (Param.CurrentTime - Param.Duration / 3 * 2) / (Param.Duration / 3);
	}
	
	Alpha = Clamp(0.0f, 1.0f, Alpha);

	if(Alpha == 0.0f)
		String = "";

	*m_pStrColor = D3DCOLOR_ARGB((BYTE)(Alpha * 255), 255, 255, 255);
	strcpy(m_pStrBuf, String);

	return TRUE;
}

BOOL CTask::LerpSky(FLOAT lerp)
{
	m_SkyCurrent.windx = Lerp(m_SkyDark.windx, m_SkyNice.windx, lerp);
	m_SkyCurrent.windy = Lerp(m_SkyDark.windy, m_SkyNice.windy, lerp);

	m_SkyCurrent.modconst = Lerp(m_SkyDark.modconst, m_SkyNice.modconst, lerp);

	m_SkyCurrent.Density = Lerp(m_SkyDark.Density, m_SkyNice.Density, lerp);
	m_SkyCurrent.Fluffiness = Lerp(m_SkyDark.Fluffiness, m_SkyNice.Fluffiness, lerp);

	D3DXColorLerp(
		&m_SkyCurrent.Color1,
		&m_SkyDark.Color1,
		&m_SkyNice.Color1,
		lerp
		);
	D3DXColorLerp(
		&m_SkyCurrent.Color2,
		&m_SkyDark.Color2,
		&m_SkyNice.Color2,
		lerp
		);
	D3DXColorLerp(
		&m_SkyCurrent.SunColor,
		&m_SkyDark.SunColor,
		&m_SkyNice.SunColor,
		lerp
		);
	D3DXColorLerp(
		&m_SkyCurrent.FogColor,
		&m_SkyDark.FogColor,
		&m_SkyNice.FogColor,
		lerp
		);

	return TRUE;
}
