---
title: defensible
author: rvivek
layout: post
permalink: /defensible/
categories:
  - Uncategorized
---
there&#8217;s a common notion/fear that if a product doesn&#8217;t have network effects, it&#8217;s hard to defend. the reason being anyone can copy the product and sell. i don&#8217;t agree.

when i was in high school, yahoo messenger had serious network effects and every one of my friends was on it, only to completely migrate to gmail a year later. an exact scenario repeated when i finished college &#8211; orkut to facebook.

even if your product has network effects, it can still become irrelevant. thinking deeply, the only way to make a company defensible is by building a strong team.

&#8211; a strong engg. team means a solid & a stable product where new features can be pushed fast w/o breaking  
&#8211; a strong product team means a great first time user experience and beautifully designed for repeated use  
&#8211; a strong sales team means the ability to understand customer&#8217;s needs and sell to the entire organization (world wide) instead of just one team

all of the above means, you attract smarter people in each of the functions in the company.

this results in unimaginable growth of the company and eventually becoming a leader like how salesforce is in the CRM space. do you think marc even cares about a new CRM that launches in the market?

it doesn&#8217;t matter whether you&#8217;re b2b or b2c. everything boils down to the team you build.

&nbsp;