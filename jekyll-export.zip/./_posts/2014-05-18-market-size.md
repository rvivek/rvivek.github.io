---
title: market size
author: rvivek
layout: post
permalink: /market-size/
categories:
  - Uncategorized
---
i hate this question. how can you possibly determine the market size of a startup when the biggest companies (paypal, apple, google, amazon, etc.) have always created a market?

the market size of a startup is the entrepreneur&#8217;s ambition. kindle wasn&#8217;t on amazon&#8217;s original pitch, iPhone wasn&#8217;t on apple&#8217;s either, maps wasn&#8217;t on Google&#8217;s plan and so on..

the only way then to make a successful investment is to gauge whether the entrepreneur is determined to run her growing company for the long term &#8211; that startup is golden to invest in.

the traditional rule of figuring if the &#8220;market size&#8221; is large and taking x% share gives a $B return doesn&#8217;t necessarily create big wins.