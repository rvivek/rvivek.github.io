---
title: angel vs VC
author: rvivek
layout: post
permalink: /angel-vs-vc/
categories:
  - Uncategorized
---
a VC cares about the percentage ownership more than the money invested;  
an angel investor cares about money invested in a startup &#8211; there&#8217;s an upper cap always.  
now you know what parameter you should negotiate for, in each case.