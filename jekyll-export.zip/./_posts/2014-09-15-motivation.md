---
title: motivation
author: rvivek
layout: post
permalink: /motivation/
categories:
  - Uncategorized
---
whenever we&#8217;re low, listening to an inspiring speech or a motivating blog post can make us feel good. humans are trained to continue to do things that make them feel good. does this mean, humans might forcefully think that their current situation is bad (even though it isn&#8217;t) so that they can listen to an inspiring speech to feel good? are motivating books, etc. fake?