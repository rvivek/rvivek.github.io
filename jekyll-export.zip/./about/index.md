---
title: About
author: rvivek
layout: page
---
I&#8217;m Vivek, co-founder, [HackerRank][1]/Interviewstreet. You can follow me on twitter (@rvivek)

 [1]: http://www.hackerrank.com